export const deliverableStyleMap = {
  'Done': { statusBg: 'var(--green-50)', statusColor: 'var(--green-700)', dotColor: 'var(--green-700)' },
  'In review': { statusBg: 'var(--sk-accent-subtle)', statusColor: 'var(--sk-accent-strong)', dotColor: 'var(--sk-accent)' },
  'Pending': { statusBg: 'var(--orange-100)', statusColor: 'var(--orange-700)', dotColor: 'var(--orange-600)' },
  'Not started': { statusBg: 'var(--neutral-light-solid-100)', statusColor: 'var(--sk-text-secondary)', dotColor: 'var(--sk-text-tertiary)' },
  'Overdue': { statusBg: 'var(--red-50)', statusColor: 'var(--red-600)', dotColor: 'var(--red-600)' },
};

export const creatorStatusStyleMap = {
  'Not contacted': { statusBg: 'var(--neutral-light-solid-100)', statusColor: 'var(--sk-text-secondary)' },
  'In discussion': { statusBg: 'var(--orange-100)', statusColor: 'var(--orange-700)' },
  'Contracted': { statusBg: 'var(--blue-50)', statusColor: 'var(--blue-600)' },
  'Content submitted': { statusBg: 'var(--sk-accent-subtle)', statusColor: 'var(--sk-accent-strong)' },
  'Completed': { statusBg: 'var(--green-50)', statusColor: 'var(--green-700)' },
};

export const paymentStyleMap = {
  'Not started': { paymentBg: 'var(--neutral-light-solid-100)', paymentColor: 'var(--sk-text-secondary)' },
  'Pending': { paymentBg: 'var(--orange-100)', paymentColor: 'var(--orange-700)' },
  'Paid': { paymentBg: 'var(--green-50)', paymentColor: 'var(--green-700)' },
};

export function freshCampaigns() {
  return [
    { id:'c1', name:'Monsoon Glow Launch', brief:'Serum launch campaign built around the new hyaluronic-acid range — Reels-led storytelling across skincare creators to drive trial before the monsoon peak.', status:'Running', timeline:'Jun 1 – Jul 31', startDate:'2026-06-01', endDate:'2026-07-31', budget:1000000,
      cumulativeReach:[0, 2200000, 5100000, 8900000, 13200000, 16800000, 19400000, 21000000],
      creators:[
        { id:'ak', name:'Ananya Kapoor', handle:'@ananya.skincare', initials:'AK', avatarBg:'var(--violet-600)', status:'Content submitted', payment:'Paid', paymentAmount:220000, reach:'68L', reachNum:6800000, roi:'5.6x', roiNum:5.6,
          deliverables:[
            { id:'d1', title:'Reel — Serum launch teaser', due:'2026-06-18', doneLabel:'Completed Jun 18', status:'Done', thumbBg:'var(--violet-100)', thumbIcon:'ph-play', stats:{ likes:9200, comments:310, views:118000, reach:620000 } },
            { id:'d2', title:'Story series — Unboxing', due:'2026-06-22', doneLabel:'Completed Jun 22', status:'Done', thumbBg:'var(--teal-50)', thumbIcon:'ph-image', stats:{ likes:7400, comments:260, views:84000, reach:410000 } },
            { id:'d3', title:'Static post — Before/after', due:'2026-07-27', doneLabel:'Tomorrow', status:'In review', thumbBg:'var(--orange-50)', thumbIcon:'ph-image', stats:{ likes:6100, comments:190, views:96000, reach:380000 } },
          ] },
        { id:'mc', name:'Meher Chhabra', handle:'@glow.with.meher', initials:'MC', avatarBg:'var(--blue-600)', status:'Contracted', payment:'Pending', paymentAmount:180000, reach:'54L', reachNum:5400000, roi:'4.9x', roiNum:4.9,
          deliverables:[
            { id:'d4', title:'Static post — Product review', due:'2026-06-25', doneLabel:'Completed Jun 25', status:'Done', thumbBg:'var(--blue-50)', thumbIcon:'ph-image', stats:{ likes:5300, comments:180, views:71000, reach:290000 } },
            { id:'d5', title:'Reel — Routine walkthrough', due:'2026-07-29', doneLabel:'in 3 days', status:'Pending' },
          ] },
        { id:'rs', name:'Rhea Sundaram', handle:'@thebeautyfile', initials:'RS', avatarBg:'var(--teal-600)', status:'Contracted', payment:'Not started', paymentAmount:150000, reach:'46L', reachNum:4600000, roi:'4.1x', roiNum:4.1,
          deliverables:[ { id:'d6', title:'Story series — Wellness tie-in', due:'2026-08-01', doneLabel:'in 6 days', status:'Not started' }, { id:'d7', title:'Reel — Ingredient deep-dive', due:'2026-08-05', doneLabel:'in 10 days', status:'Not started' } ] },
        { id:'zf', name:'Zara Fernandes', handle:'@zara.beautyedit', initials:'ZF', avatarBg:'var(--pink-600)', status:'In discussion', payment:'Not started', paymentAmount:120000, reach:'42L', reachNum:4200000, roi:'4.3x', roiNum:4.3,
          deliverables:[ { id:'d8', title:'Reel — Festive edit teaser', due:'2026-08-04', doneLabel:'in 9 days', status:'Not started' } ] },
      ], reach:'2.1Cr', roi:'4.8x' },
    { id:'c2', name:'Diwali Radiance Edit', brief:'Gifting-season bundle push for the Diwali combo sets — carousel storytelling plus Reels aimed at gifting intent in the two weeks before Diwali.', status:'Draft', timeline:'Starts Sep 15', startDate:'2026-09-15', endDate:'2026-10-15', budget:0,
      creators:[
        { id:'sk', name:'Simran Kaur', handle:'@simran.beauty', initials:'SK', avatarBg:'var(--blue-600)', status:'Not contacted', payment:'Not started', paymentAmount:0, deliverables:[] },
        { id:'pn', name:'Priya Nair', handle:'@priya.glowup', initials:'PN', avatarBg:'var(--violet-600)', status:'Not contacted', payment:'Not started', paymentAmount:0, deliverables:[] },
      ], reach:'—', roi:'—' },
    { id:'c3', name:'Summer Skin Reset', brief:'SPF range relaunch anchored in authentic UGC reviews — proof-led content from skincare and wellness creators to rebuild trust after the last formulation change.', status:'Completed', timeline:'Mar 1 – May 30', startDate:'2026-03-01', endDate:'2026-05-30', budget:650000,
      creators:[
        { id:'dm', name:'Divya Menon', handle:'@divya.skindiaries', initials:'DM', avatarBg:'var(--pink-600)', status:'Completed', payment:'Paid', paymentAmount:210000,
          deliverables:[ { id:'d9', title:'Reel — SPF demo', due:'2026-05-12', doneLabel:'Completed May 12', status:'Done' }, { id:'d10', title:'Static post — 30-day results', due:'2026-05-20', doneLabel:'Completed May 20', status:'Done' }, { id:'d11', title:'Story — Q&A', due:'2026-05-25', doneLabel:'Completed May 25', status:'Done' } ] },
        { id:'tj', name:'Tara Joshi', handle:'@tara.naturals', initials:'TJ', avatarBg:'var(--green-700)', status:'Completed', payment:'Paid', paymentAmount:200000,
          deliverables:[ { id:'d12', title:'Carousel — Ingredient story', due:'2026-05-20', doneLabel:'Completed May 20', status:'Done' }, { id:'d13', title:'Reel — Application routine', due:'2026-05-28', doneLabel:'Completed May 28', status:'Done' } ] },
        { id:'iv', name:'Ishaan Verma', handle:'@ishaan.grooms', initials:'IV', avatarBg:'var(--pink-600)', status:'Completed', payment:'Paid', paymentAmount:200000,
          deliverables:[ { id:'d14', title:'Reel — Grooming + SPF combo', due:'2026-05-22', doneLabel:'Completed May 22', status:'Done' }, { id:'d15', title:'Static post — Review', due:'2026-05-29', doneLabel:'Completed May 29', status:'Done' } ] },
      ], reach:'1.8Cr', roi:'5.2x' },
    { id:'c5', name:'New Mom Skincare Push', brief:'Postpartum-safe skincare line introduced through relatable new-mom voices — a mix of static reviews and Reels focused on gentle, dermat-approved routines.', status:'Running', timeline:'Jun 15 – Aug 15', startDate:'2026-06-15', endDate:'2026-08-15', budget:450000,
      creators:[
        { id:'ki', name:'Kavya Iyer', handle:'@kavya.newmom', initials:'KI', avatarBg:'var(--violet-600)', status:'Content submitted', payment:'Pending', paymentAmount:170000,
          deliverables:[ { id:'d16', title:'Static post — Stretch mark cream', due:'2026-07-10', doneLabel:'Completed Jul 10', status:'Done' }, { id:'d17', title:'Reel — Nighttime routine', due:'2026-07-30', doneLabel:'in 4 days', status:'In review' } ] },
        { id:'rm', name:'Ritu Malhotra', handle:'@ritu.postpartum', initials:'RM', avatarBg:'var(--blue-600)', status:'Contracted', payment:'Not started', paymentAmount:140000,
          deliverables:[ { id:'d18', title:'Reel — Postpartum skin story', due:'2026-08-02', doneLabel:'in 7 days', status:'Not started' }, { id:'d19', title:'Static post — Ingredient safety', due:'2026-08-09', doneLabel:'in 14 days', status:'Not started' } ] },
        { id:'fs', name:'Fatima Sheikh', handle:'@fatima.mombeauty', initials:'FS', avatarBg:'var(--pink-600)', status:'Completed', payment:'Paid', paymentAmount:140000,
          deliverables:[ { id:'d20', title:'Reel — Morning routine', due:'2026-07-05', doneLabel:'Completed Jul 5', status:'Done' }, { id:'d21', title:'Story — Product reveal', due:'2026-07-08', doneLabel:'Completed Jul 8', status:'Done' } ] },
      ], reach:'94L', roi:'3.7x' },
    { id:'c6', name:'Festive Combo Sets', brief:'Mid-funnel bundle campaign pairing hero products into gifting-ready combos — creator storytelling built around value and festive occasions.', status:'Running', timeline:'Jul 1 – Aug 31', startDate:'2026-07-01', endDate:'2026-08-31', budget:600000,
      creators:[
        { id:'ab', name:'Aisha Bhatt', handle:'@aisha.festivelooks', initials:'AB', avatarBg:'var(--teal-600)', status:'Contracted', payment:'Pending', paymentAmount:210000,
          deliverables:[ { id:'d22', title:'Reel — Festive gifting guide', due:'2026-08-01', doneLabel:'in 5 days', status:'Pending' }, { id:'d23', title:'Static post — Combo flatlay', due:'2026-08-05', doneLabel:'in 9 days', status:'Not started' } ] },
        { id:'km', name:'Karan Mehta', handle:'@karan.grooming', initials:'KM', avatarBg:'var(--orange-600)', status:'Content submitted', payment:'Paid', paymentAmount:180000,
          deliverables:[ { id:'d24', title:'Carousel — Combo unboxing', due:'2026-07-18', doneLabel:'Completed Jul 18', status:'Done' } ] },
        { id:'sp', name:'Sneha Pillai', handle:'@sneha.combolove', initials:'SP', avatarBg:'var(--violet-600)', status:'In discussion', payment:'Not started', paymentAmount:130000,
          deliverables:[ { id:'d25', title:'Reel — Gifting for him/her', due:'2026-08-07', doneLabel:'in 11 days', status:'Not started' } ] },
      ], reach:'1.2Cr', roi:'4.1x' },
  ];
}
