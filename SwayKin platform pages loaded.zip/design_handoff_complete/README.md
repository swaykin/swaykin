# Handoff: SwayKin — Complete Design (All Screens)

## Overview
SwayKin is an AI-native influencer-marketing SaaS platform for D2C brands: discover and vet Instagram creators, save/track them in a CRM, run and manage paid campaigns end-to-end (briefs → deliverables → payments → ROI), monitor competitors, and handle outreach — all from one workspace.

## About the Design Files
The bundled `.dc.html` files are **design references built in an internal HTML prototyping format** — a custom `{{ }}` template syntax, `<sc-for>`/`<sc-if>` control-flow tags, `<dc-import>` for shared components, and a `DCLogic` class per file holding state/handlers. They are **prototypes, not production code** — do not copy them as-is. The task is to **recreate this design in the target codebase's real environment** (React/Vue/etc., or the most appropriate framework if none exists yet), using its own component patterns, routing, and state management.

## Fidelity
**High-fidelity.** Colors, typography, spacing, icons, copy, and interaction patterns are all final and intended to ship as shown. Recreate pixel-for-pixel using the design tokens below (or the codebase's equivalent tokens, if it already has one).

## Design tokens
Defined in `sk-theme.css` as CSS custom properties, layered on top of an existing "Flipkart Design System" base token set (`_ds_bundle` — not included in this bundle; color-ramp tokens like `var(--blue-600)`, `var(--green-50)`, `var(--red-600)`, `var(--violet-600)`, `var(--orange-600)`, `var(--teal-600)`, `var(--pink-600)` come from that system — recreate as a standard 50–900 ramp per hue if unavailable).

Key SwayKin tokens (light theme):
- Accent (single teal/emerald, used sparingly): `--sk-accent: #0D9488`, `--sk-accent-strong: #0F766E`, `--sk-accent-subtle: #EBFAF7`, `--sk-accent-subtle-strong: #CCEEE8`, `--sk-accent-on: #ffffff`
- Link: `--sk-link: #0F766E`, hover `#0B5D57`
- Surfaces: `--sk-page-bg: #F8FAFC`, `--sk-surface: #ffffff`, `--sk-surface-sunken: #F1F5F9`
- Borders: `--sk-border: #E2E8F0`, `--sk-border-strong: #CBD5E1`
- Text: `--sk-text: #0F172A`, `--sk-text-secondary: #475569`, `--sk-text-tertiary: #94A3B8`
- Sidebar: `--sk-sidebar-bg: #ffffff`, `--sk-sidebar-bg-active: #EBFAF7`, `--sk-sidebar-text: #64748B`, `--sk-sidebar-text-active: #0F766E`, `--sk-sidebar-border: #E2E8F0`
- Shadows: card `0 1px 2px rgba(16,24,40,0.04), 0 1px 1px rgba(16,24,40,0.03)`; raised `0 6px 20px rgba(16,24,40,0.09), 0 1px 2px rgba(16,24,40,0.04)`; overlay `0 18px 44px rgba(16,24,40,0.14), 0 2px 8px rgba(16,24,40,0.05)`

A full parallel **dark theme** (`:root[data-theme="dark"]`) is defined in `sk-theme.css` with the same variable names (accent brightens to `#2DD4BF`, page bg `#0B1220`, etc.) — recreate as a theme toggle if the app supports dark mode.

Font: `var(--font-sans)` (from the Flipkart DS font tokens; substitute Inter or the codebase default if unavailable). Radius scale: 6–9px for buttons/inputs/chips/pills, 12–16px for cards. Icons: Phosphor Icons (`ph`, `ph-bold`, `ph-fill` classes) — swap for the codebase's icon set, matching icon concepts by name.

## App shell (shared across every screen)
- **`AppSidebar.dc.html`** — fixed 248px left nav. Logo row, workspace-switcher card (avatar + name + type, static in mock), primary nav (Dashboard, Discovery, Saved Influencers, Campaigns, Competitors — active item gets tinted bg, bold text/icon, and a 2.5px accent bar on the left edge), and a separated "Outreach" item pinned to the bottom. Driven by a single `activePage` prop.
- **`AppTopBar.dc.html`** — sticky 56px header. Global search (typeahead dropdown grouped by entity type: campaigns / saved influencers / competitor analyses), credits pill, "Contact us" button (`mailto:`), notifications bell with unread dot + dropdown, profile avatar + dropdown (Profile / Workspace Settings / Sign out).
- **`PageHeader.dc.html`** — reusable page-header component (breadcrumb, title, subtitle, primary CTA button, AI-copilot trigger, export action, toast surface) used by several list-style pages (e.g. Campaigns).
- **`AICopilotDrawer.dc.html`** — slide-in right-side AI assistant drawer, opened from the page header's AI trigger.

Every top-level page composes `<dc-import name="AppSidebar">` + `<dc-import name="AppTopBar">` around its own scrollable content area — recreate as a persistent app shell/layout wrapping all routes.

## Screens

### Dashboard (`Dashboard.dc.html`)
Home screen. "Welcome back, {name}" header + one-line status narrative (no stat repetition). 5-metric airy KPI strip (active campaigns, active creators, budget spent, total reach, blended ROI) — large numbers, minimal chrome, vertical dividers instead of bordered cards. Two-column body: left (wider) has a "Needs attention" feed (payments overdue/pending, deliverables due, follow-up reminders, campaigns ending soon — colored dot + tag, most urgent first, links into the relevant detail page) and a "Running campaigns" snapshot (deliverables ratio, days left, budget progress bar, reach, ROI, links to Campaign Detail); right (narrower) has an "Alerts" panel (competitor + saved-influencer intelligence, distinct from actionable Needs Attention) and a "Quick access" block (saved lists shortcuts, recently-viewed row) — deliberately has NO on-page search (global search lives in the top bar) and no repeated nav shortcuts (sidebar handles that).

### Influencer Discovery (`InfluencerDiscovery.dc.html`)
Search/filter/browse creators (list view) plus a **Detail View** reached by clicking a card or direct lookup — public-Instagram-data only, no manual data entry, no benchmark comparisons, no "similar creators" module (removed by design decision). Detail View order of priority, top to bottom: top action bar (Save, Export Report, Start Outreach — visible without scrolling); compact header (photo, name, verified badge, bio, public contact info with copy-to-clipboard, follower/engagement as plain inline numbers, following/post-count as small secondary text only); **Brand Collaborations** (centerpiece — aggregate total reach/EMV, then a compact clickable list per collab: brand, date, detected-via tag, per-item reach/EMV, click jumps to/highlights the matching post below); **Themes** (short tag list); **Hashtags** (ranked list with usage counts); **Recent Posts grid** (3/row, thumbnail + type icon + likes/comments/views/date, "Paid Partnership" badge on collab posts, click opens a full post modal, "Load More" — never full pagination or load-all); a dimmed "Save teaser" panel below the grid promoting the save-to-unlock CRM features.

### Saved Influencers (`SavedInfluencers.dc.html`)
**Landing (list) page**: search, "Lists" (custom folders — create/select), status/sort filters, bulk-select action bar (Add to Campaign / Update Status / Export / Remove), and a card grid per saved creator (avatar, name, verified, niche/location, follower & engagement counts WITH trend-since-saved deltas, "new activity" indicator, inline-editable outreach-status pill, campaign tag, list tag, "saved {time} ago").
**Detail page**: extends the Discovery Detail View's base sections (header, Brand Collaborations, Themes, Hashtags, Recent Posts w/ modal + Load More) but adds three save-only sections between the header and Brand Collaborations: (A) **Growth & Engagement Trends** — follower/engagement bar-trend charts since the save date, a "what's changed since last viewed" callout, and posting-frequency as a small supporting stat; (B) **Outreach/CRM panel** — editable status pipeline, dated notes timeline with an add-note input, next-follow-up date picker, assigned-team-member; (C) **Campaign Associations** — list of campaigns this creator is/was part of with role/status, Spend, EMV, and ROI% per campaign (ROI is only ever shown here, since it needs the brand's actual entered budget — private, not public data), plus an "add to campaign" action.
**Manual email entry** (Saved detail page ONLY, never Discovery): if no public email was found, show "No public email found" + an "Add manually" control that opens an inline input; once saved it renders in the same contact-info slot with copy-to-clipboard and a small "Added manually" tag distinguishing it from publicly-sourced data. This manually-entered email should count toward any "has email" filter/badge logic (i.e. those should mean "has any email on file", not just scraped ones).

### Campaigns — Landing (`Campaigns.dc.html`)
List/summary page only (no inline expansion). Breadcrumb + title + subtitle, Export + "+ New Campaign" actions. Summary stat cards (active campaigns, active creators, total budget, deliverables done). Status filter tabs (All/Running/Draft/Completed with counts). One collapsed summary card per campaign — name, status pill, one-line brief, a stats row (creators count, timeline, budget-with-progress-bar, reach, ROI), and a three-dot menu (Edit/Duplicate/Archive). Clicking anywhere on a card (outside the menu) navigates to Campaign Detail via a query-param URL (`CampaignDetail.dc.html?id=...`).

### Campaign Detail (`CampaignDetail.dc.html`)
Full management view for one campaign (new page, not an accordion). Breadcrumb + back link. Header: editable status (dropdown), inline brief, "Edit Campaign" modal (name/description/timeline/budget), Export, three-dot menu (Duplicate/Archive). Stats row mirrors the landing card's metrics but is the computed source of truth (creators count and budget-spent are derived from the data below, not manually set). **Collapsible performance-chart section** (cumulative reach-over-time bar chart, per-creator reach-vs-ROI comparison bars) sits between the stats row and the tabs, collapsed by default sizing so it doesn't push content down. Two tabs: **Influencers** (sub-status filter pills, Filter/Import CSV/"Add Creator" actions, table with per-row editable status pill, deliverables-count that jumps to the Timeline tab, editable payment pill + amount, per-creator Reach and ROI columns, and a chat-thread icon opening a scoped message panel) and **Timeline & Deliverables** (grouped by creator — avatar/name/handle header, list of deliverables each with editable title/date/status, "+ Add Deliverable" per creator; any deliverable already posted (Done/In review/Content submitted) shows an inline content thumbnail plus its likes/comments/views/reach — not-yet-posted deliverables show no stats). Modals: Edit Campaign, Add Creator (pulls from a saved-influencers pool), Thread (per-creator chat).

### Competitive Analysis (`CompetitiveAnalysis.dc.html`)
Tracks competitor brands' public social activity — read this file directly for full layout; feeds the Dashboard's "Alerts" panel (new collabs detected, unusually high-performing posts, new hashtag pushes) and the app-wide search index.

### Outreach (`Outreach.dc.html`)
Messaging/outreach workspace — read this file directly for full layout; linked from the sidebar as a bottom-pinned item separate from the core 5-item nav, and from "Start Outreach" actions across Discovery/Saved/Campaigns.

### Analytics (`Analytics.dc.html`)
Cross-campaign/creator analytics view — read this file directly for full layout.

### Account/system pages
`Login.dc.html`, `Profile.dc.html`, `Settings.dc.html`, `Privacy.dc.html` — standard auth/account/legal screens, styled with the same design tokens; read each directly for exact layout and copy.

## Interactions & Behavior (patterns repeated across screens)
- **Dropdowns/menus** (search results, notifications, profile, list/status/sort filters, per-row status/payment menus): simple absolutely-positioned popovers toggled by boolean state, closed by re-clicking the trigger or selecting an option. None have outside-click-to-close wired in the mocks — add that as standard menu/popover behavior in the real build.
- **Hover states**: subtle background-tint shift only (`var(--sk-surface-sunken)` or `var(--sk-accent-subtle)`), no scale/shadow hover effects anywhere.
- **Toasts**: a single bottom-center toast (dark pill, checkmark icon) confirms actions (save, status change, export, note added, etc.) across every page — implement as one global toast/snackbar system.
- **Load more** patterns (Recent Posts grids) intentionally avoid numbered pagination or loading everything at once — fetch-more-on-click, batch size ~6.
- **Jump-and-highlight**: clicking a Brand Collaboration row scrolls to and briefly highlights (colored border, ~2.2s) the matching tile in the Recent Posts grid below — same pattern used for jumping from the Campaign Detail Influencers table to a creator's section in the Timeline tab.
- No loading/error/empty states are modeled beyond a couple of literal "No X yet" text lines — the real implementation needs proper skeleton/loading and error states for all data-fetching surfaces.
- Not responsive in the mocks (fixed 248px sidebar, multi-column grids with no breakpoints) — define a mobile/tablet strategy (collapsible sidebar, single-column stacking) for the real build.

## State Management
Each `.dc.html` currently holds its own local component state (filters, menu-open booleans, selected items, draft form values, in-memory mock data arrays). For the real app, this should become:
- Global: current user/workspace, auth session, theme (light/dark), global search index, notification feed, toast/snackbar.
- Per-domain data services: Campaigns (+ nested creators/deliverables/payments), Saved Influencers (+ lists, CRM notes/status/follow-ups, campaign associations), Discovery results (+ Instagram-derived public profile/collab/hashtag data), Competitors (+ alerts), Outreach threads.
- Cross-cutting derived data: Dashboard's KPIs/Needs-Attention/Alerts/Campaigns-Snapshot are all computed by aggregating across the domain services above — model them as selectors/derived queries, not their own source of truth.

## Assets
- Icons: Phosphor Icons web font (CDN in this mock: `unpkg.com/@phosphor-icons/web@2.1.1`), classes `ph` / `ph-bold` / `ph-fill` + icon name.
- No raster photography/logos on any screen — all avatars are colored-initial tiles; brand "logos" in Brand Collaborations are colored-initial tiles too (real build should swap in actual creator/brand imagery once available).
- Base font/tokens are loaded from an external "Flipkart Design System" bundle (`fonts.css`, `fig-tokens.css`, `typography.css`, `styles.css`, `_ds_bundle.js`) not included here — substitute the target codebase's own base type/token system, keeping the SwayKin-specific tokens in `sk-theme.css` layered on top.

## Files in this bundle
- `AppSidebar.dc.html`, `AppTopBar.dc.html`, `PageHeader.dc.html`, `AICopilotDrawer.dc.html` — shared shell/components
- `Dashboard.dc.html` — home screen
- `InfluencerDiscovery.dc.html` — discovery list + public detail view
- `SavedInfluencers.dc.html` — saved list + CRM detail view
- `Campaigns.dc.html`, `CampaignDetail.dc.html`, `CampaignsData.js` — campaigns landing, detail, and shared mock data module
- `CompetitiveAnalysis.dc.html` — competitor tracking
- `Outreach.dc.html` — outreach/messaging workspace
- `Analytics.dc.html` — analytics view
- `Login.dc.html`, `Profile.dc.html`, `Settings.dc.html`, `Privacy.dc.html` — account/system pages
- `sk-theme.css` — design tokens referenced by every screen
