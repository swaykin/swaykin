# Handoff: SwayKin AI — Influencer Marketing Platform

## Overview
SwayKin AI is a B2B SaaS platform for D2C brands to discover Instagram creators, shortlist/track them across campaigns, benchmark against competitors, and manage email outreach.

## About the Design Files
The `.dc.html` files in this bundle are **design references** built in a prototyping tool — not production code to copy directly. They show intended layout, copy, interaction, and visual style. Recreate these designs in your target codebase's environment (React recommended, or whatever framework the codebase already uses) using its own components/patterns — do not ship the HTML as-is. Ignore any `support.js` script tag or `<script type="text/x-dc">` runtime wrapper; treat the markup structure, inline styles, and the `class Component` logic below each file as the spec for layout, state, and copy.

## Fidelity
**High-fidelity.** Colors, spacing, type sizes, radii, and shadows are final — recreate pixel-accurately. Icons are Phosphor Icons (`@phosphor-icons/react`, Regular/Bold/Fill weights, loaded via `ph`, `ph-bold`, `ph-fill` classes in the prototype). Font is Inter via the underlying design-system token file — use Inter with system-ui fallback.

## Scope — 6 screens
Dashboard, Influencer Discovery, Influencer Profile, Saved Influencers, Competitive Analysis, Outreach. Earlier explorations (Brand Mentions, Analytics, Campaigns list, Connect Instagram, Connect Shopify, AI Copilot drawer) were cut and are **not** part of this handoff — ignore any link in the files pointing to `Campaigns.dc.html` (it's a stub target, not a built screen; route it to a placeholder or omit the link until that screen is designed).

**Explicitly out of scope, cut deliberately — do not add back:**
- All AI features (AI summaries, AI search, AI insights cards, AI copilot chat) — no backend available for these yet.
- Audience data: geography breakdowns, follower-authenticity/fake-follower detection, CPE/CPM/CPV, follower growth trend charts.
- Instagram OAuth / Shopify OAuth connection flows — Instagram is referenced only as a plain outbound link (`instagram.com/<handle>`); Outreach opens straight into a Gmail-style inbox with no connect step assumed.
- Pricing/rate-card data on creators.
- "Similar creators" recommendations.

---

## Design Tokens (sk-theme.css)
Full source in `sk-theme.css` — implement as CSS custom properties on `:root` (values below are light mode; the file also has a `data-theme="dark"` block).

| Token | Value | Usage |
|---|---|---|
| --sk-accent | #0D9488 | primary accent (buttons, active states) |
| --sk-accent-strong | #0F766E | accent text/icons on tinted bg |
| --sk-accent-subtle | #EBFAF7 | tinted backgrounds |
| --sk-accent-subtle-strong | #CCEEE8 | tinted border/selection |
| --sk-accent-on | #ffffff | text on solid accent |
| --sk-link / --sk-link-hover | #0F766E / #0B5D57 | links |
| --sk-page-bg | #F8FAFC | page background |
| --sk-surface | #ffffff | card/panel background |
| --sk-surface-sunken | #F1F5F9 | inset chips, stat tiles, table hover |
| --sk-border / --sk-border-strong | #E2E8F0 / #CBD5E1 | hairlines |
| --sk-text | #0F172A | primary text |
| --sk-text-secondary | #475569 | secondary text |
| --sk-text-tertiary | #94A3B8 | captions, placeholders |
| --sk-sidebar-bg-active | #EBFAF7 | active nav item bg |
| --sk-sidebar-text-active | #0F766E | active nav item text/icon |
| --sk-shadow-card | 0 1px 2px rgba(16,24,40,.04), 0 1px 1px rgba(16,24,40,.03) | resting card |
| --sk-shadow-raised | 0 6px 20px rgba(16,24,40,.09), 0 1px 2px rgba(16,24,40,.04) | hover/primary CTA |
| --sk-shadow-overlay | 0 18px 44px rgba(16,24,40,.14), 0 2px 8px rgba(16,24,40,.05) | dropdowns, modals, toast |

Status colors (from the underlying design-system palette, used directly — not remapped to sk- tokens): `--green-50/600/700` (positive/success), `--orange-100/600/700` (warning/paused/negotiating), `--blue-50/600` (info/in-progress), `--red-600` (destructive/error), `--violet/pink/teal-*` (avatar tint variety only, no semantic meaning).

**Typography:** Inter. Page title 22–24px/700/-0.015em letter-spacing. Section headers 14px/700. KPI values 18–22px/700/-0.02em. Table headers 11px/600/uppercase/0.04em letter-spacing. Body/table cells 12–13.5px. Captions/tertiary 11–11.5px.

**Spacing/radius:** Cards 14–16px radius, 16–20px padding, 1px `--sk-border`, `--sk-shadow-card`. Buttons/inputs 9px radius, 32–46px height depending on context. Pills/badges 6–8px radius. Avatars: circle, colored background + white initials (no photo assets in the prototype — brief expects real profile photos in production, avatar-with-initials is a design-time placeholder only). Page content padding `16–20px 28px 36–48px`. Grid/list gaps 12–16px.

---

## App Shell (every page)

**AppSidebar** — 248px fixed-width, full height, sticky left, white bg, right hairline border.
- Top: 18px teal rounded-square logo mark (sparkle icon) + "SwayKin AI" wordmark, 700 weight.
- Workspace card below logo: 28px rounded-square with 2-letter initials (accent bg) + workspace name (e.g. "Nova Beauty Co.") + subtext ("D2C Brand · 1 workspace"). Static in this build — no workspace switcher/dropdown behavior yet.
- Nav (flat list, one active at a time): Dashboard, Discovery, Saved Influencers, Competitors, Outreach — icon (Phosphor, Bold weight inactive / Fill weight active) + label. Active item: 2.5px teal left-bar (absolute, rounded), `--sk-sidebar-bg-active` background, `--sk-sidebar-text-active` text/icon, 700 weight. Inactive: `--sk-text` @ 600 weight, `--sk-text-secondary` icon. Hover: `--sk-surface-sunken` bg.
- Bottom: single "Settings" link above the border, no active/inactive state logic needed (static).

**AppTopBar** — 56px height, sticky top, white bg, bottom hairline, `z-index:20`.
- Left: empty flex spacer (no global search in current build).
- Credits chip: coin icon + numeric balance ("1,240") + "credits" label, pill, `--sk-surface-sunken` bg.
- Notification bell: icon button with small red unread dot; click opens a 320px dropdown (right-aligned, absolute) listing 3 recent notifications (icon chip + text + relative timestamp). Click-to-toggle, not hover.
- Vertical divider, then profile avatar (30px circle, initials, `--sk-accent-strong` bg) + caret; click opens a 210px dropdown: name + email, divider, "Workspace settings", "Team members", divider, "Sign out" (red text/hover).
- Both dropdowns are mutually exclusive (opening one closes the other) and close on outside click in production (the prototype toggles via state only).

**Per-page header** (built inline on each page, not yet a shared component): thin breadcrumb line ("SwayKin AI · <Page>"), then a row with page `<h1>` (22px/700) + one-line subtitle (13px, `--sk-text-secondary`) on the left, and 1–2 right-aligned action buttons (secondary "Export"/outline style + primary accent-filled CTA with icon). A bottom-center toast (dark pill, white text, green check icon) appears for 2.4s after actions like "add to campaign" or "save search" — implement as a global toast/snackbar utility.

---

## Screens

### 1. Dashboard
**Purpose:** Top-level health check across influencers, campaigns, spend, and content performance.
**Layout (single scroll column, gap 16px):**
1. KPI strip — 5 equal-width cards: Total influencers (1,284), Active campaigns (14), Total spend (₹42.6L), Revenue generated (₹1.94Cr), Blended ROI (4.6x). Each card: 28px icon chip (tinted per metric), value (22px/700), label (12px tertiary).
2. Two-column row (2fr/1fr): left = "Active campaigns" table (Campaign, Status badge, Spend, ROI, Creators count) with a "View all" link; right = "Upcoming deliverables" list (colored due-date dot + title + creator handle + relative due date), one row per deliverable.
3. Two-column row (1fr/1fr): left = "Content mix" — 3 horizontal progress bars (Reels 41%, Static posts 35%, Stories 24%) each with icon + label + %; right = "Campaign comparison" table (Campaign, Eng. rate, CPM, ROI).
4. Full-width "Top performing creators" table: avatar+name+niche, Followers, Engagement, Revenue driven (right-aligned, green).
**Data shape per row type:** campaign `{name, status, statusBg/Color, spend, roi, creators}`; deliverable `{title, creator, due, dotColor}`; contentMix `{label, pct, icon, color}`; comparison `{name, er, cpm, roi}`; creator `{name, initials, avatarBg, niche, followers, er, revenue}`.
**State:** `toast` (string, auto-clears), button handlers for Export/New Campaign only show a toast in this prototype — wire to real actions.

### 2. Influencer Discovery
**Purpose:** Search/filter the creator database and shortlist creators.
**Layout:**
- Header: title + subtitle ("Search 2.1M+ Instagram creators with filters") + primary "Add to Campaign" CTA.
- Full-width search input (52px tall, rounded 14px, magnifier icon) — placeholder text implies natural-language search but this build has no backend hookup; treat as a plain text filter field.
- Filter bar (card): 4 toggle chips (Followers 50K–500K, India, Engagement 4%+, Beauty & Skincare) — active state = accent border + tinted bg; a dashed "+8 more filters" button expands a 5-column detail panel (Price range, Creator type, Growth rate, Account type, Brand affinity — **note:** price range/creator-type here are leftover copy from an earlier draft; since pricing data was cut, either remove that specific field or confirm with design before implementing); "Clear" appears only when a filter is active; a "Save this search" button; a "saved searches" dropdown-button showing count, opening a list of named saved searches (name + description + delete "x" per row, empty state when none) — apply-on-click; grid/table view toggle (two icon buttons).
- Result count line: "Showing N of 18,204 matching creators".
- Bulk-selection bar (appears only when ≥1 selected): "N selected" + Add to campaign / Compare / Clear.
- **Grid view** (3-col cards): checkbox + 46px avatar (accent ring when selected) + name + verified seal + @handle + niche pill + bookmark icon button; 4 stat tiles (Followers, Engagement, Avg. views, Posts/week) in a 2x2 grid; footer row = square Instagram-link icon button + full-width "View full profile →" button.
- **Table view:** same fields as flat columns, checkbox column, "View →" link column.
- **Compare modal:** overlay + centered panel, N side-by-side cards (avatar, name, handle, Followers/Engagement/Avg. views/Posts-per-week rows, "View profile" link).
**Data shape (`influencers[]`):** `{id, name, handle, igUrl, initials, avatarBg, niche, verified, followers, er, avgViews, postsWeek, selected, href}`. Saved search: `{id, name, desc, filters}`.
**State:** `view` ('grid'|'table'), `searchQuery`, `filters{followers,country,engagement,category}` (booleans), `moreFiltersOpen`, `savedSearchesOpen`, `savedSearches[]`, `influencers[]` (with per-item `selected`), `compareOpen`, `toast`.

### 3. Influencer Profile
**Purpose:** Deep dive on one creator — used for campaign fit and outreach decisions.
**Layout:**
- Header: breadcrumb "SwayKin AI · Influencer Discovery · <Name>" + title (creator name) + subtitle (@handle · niche, location). Right actions: outline "View Instagram" link button (single Instagram link — no other socials) + primary "Add to Campaign".
- **Campaign relationship strip** (full width, above the 2-col body): header "Campaigns with <Name>" (flag icon), then a **3-column row, no wrapper cards, thin vertical dividers between columns**: Active / Upcoming / Completed. Each column: colored status dot + label + count (right-aligned), then a list of campaign name links (or "None" if empty).
- **2-column body** (280px sidebar + flexible main):
  - Left profile card: 56px avatar + name + verified seal + @handle; 2x2 core-stats grid (Followers, Engagement, Avg. views, Posts/week); divider; single email row (icon + mailto link — **email is optional per-creator**, omit the row entirely when absent, don't show "N/A"); "Brand affinity" tag row; "Hashtags & mentions" tag row (hashtags in accent tint, @mentions in neutral tint).
  - Right: "Past collaborations & sponsored posts" table — Brand, Format, Reach (est.), Engagement — 4 columns, fixed layout, truncating overflow.
- **Content grid** (full width, below the 2-col body): header "Recent collaborations & posts (N)" + "Open Instagram" link. **2-per-row grid, cards capped at 420px width, 4:5 aspect ratio**, each tile = tinted bg + centered play/image icon; Reels additionally show a film-strip badge (top-right) and a view-count overlay (bottom-left, e.g. "92K views"). Scrollable container (max-height ~640px) showing 4 items initially with a "Load more (N more)" button appending 4 at a time.
**Data shape:** campaign groups built from `[{name, status: 'Active'|'Upcoming'|'Completed', href}]`; collaboration rows `[{brand, format, reach, engagement}]`; feed items `[{bg, icon, isReel, views}]`; `hashtags[]`, `mentions[]`, `brandAffinity[]` string arrays; `email` (string or omitted).
**State:** `feedShown` (int, +4 per "Load more" click, starts at 4), `toast`.

### 4. Saved Influencers
**Purpose:** Cross-campaign tracker for every creator a brand user has shortlisted — status, active conversation, and (once a campaign concludes) the outcome.
**Layout:**
- Header: title + subtitle ("Track shortlisted creators, conversation progress and campaign outcomes") + primary "Save influencer" CTA (routes to Discovery in practice).
- KPI strip (4 cards, icon+value+label side-by-side layout, not stacked): Shortlisted, In discussion, Contracted, Campaign ended — each count derived live from the list below.
- Status filter chips: All / Shortlisted / In discussion / Contracted / Campaign ended — single-select.
- Table columns: Creator (avatar+name+handle+niche), Followers, Engagement, Status (colored badge), Conversation (free-text status colored by keyword — green if "Completed"/"closed", orange if "Replied"/"Negotiating", else neutral), Campaign (name or "—"), Outcome (₹ amount + ROI when a campaign ended, "Negotiating"/"In progress" mid-flight, "—" if not yet engaged), Links (Instagram icon button + remove "x" icon button).
- Empty state (icon + message) when a filter yields zero rows.
**Data shape (`influencers[]`):** `{id, name, handle, initials, avatarBg, niche, followers, er, status, convo, campaign, outcome, igUrl}`. Status enum: `Shortlisted | In discussion | Contracted | Campaign ended`.
**State:** `filter` (enum above, default 'All'), `toast`.

### 5. Competitive Analysis
**Purpose:** Benchmark the brand's own influencer activity against named competitor brands — content and cadence only, no spend/AI.
**Layout:**
- Header: title + subtitle + primary "Add Competitor" CTA.
- "Comparing:" row of brand toggle-chips (colored dot + name, one of which is always "<Brand> (you)"), each independently togglable, plus a dashed "Add brand" button.
- "Average engagement rate" card: one horizontal bar per active brand (label+dot, value, progress bar).
- "Recent competitor Reels & Posts" card: 6-col grid of square tiles — tinted bg, centered type icon, top-left brand-name tag overlay, bottom row = like count + content type (Reel/Post) overlay.
- Two-column row: left = "Top hashtags & content themes" (hashtag pill row + separate content-theme pill row); right = "Posting pattern (posts/day)" — 7-col × 4-row heatmap grid (Mon–Sun columns) shaded by intensity, day labels below.
- "Competitor timeline" card: vertical list of dated events (colored dot + "**Brand** did X" + date), newest first.
**Data shape:** `brands[]` `{key, name, color, tint, active}`; `engagementCompare[]` `{name, value, pct, color}`; `competitorContent[]` `{brand, bg, icon, iconColor, likes, type}`; `hashtags[]`, `themes[]` string arrays; `heatmap[]` (28 cells, intensity 0–4 mapped to color); `timeline[]` `{brand, event, date, color}`.
**State:** `brands` (per-key boolean toggle), `toast`. Explicitly no AI summary, no spend graph, no share-of-voice widget, no influencer-count/frequency stat cards on this page — keep it to content/cadence comparison only.

### 6. Outreach
**Purpose:** Gmail-style inbox for managing creator outreach threads. Wired to *look like* a connected Gmail inbox — **no OAuth flow is modeled**; assume the brand's Gmail is already connected and just render the inbox UI.
**Layout — 3-pane Gmail-style layout, distinct visual skin from the rest of the app** (uses Gmail's own palette: white bg, `#e3e3e3` hairlines, `#C2E7FF` compose/reply pill buttons, `#0B57D0` send button, `#202124`/`#5f6368` text — do not apply `sk-` tokens inside this page's Gmail chrome):
  - Left rail (210px): "Compose" pill button; folder list (Inbox/Starred/Sent/Drafts, with unread counts); "SwayKin Labels" section (Replied/Opened/Follow-up needed, colored dots, decorative only — no filtering behavior in this build); connected-account footer (Gmail icon + brand inbox address + green "Connected" status, static).
  - Middle list (360px): search bar (decorative, no live search wired), status filter chip row (All/Sent/Opened/Replied), thread rows — avatar, name (bold if unread), subject, preview snippet, relative timestamp, status badge; selected row highlighted; unread rows bold per Gmail convention.
  - Right preview pane: subject + status badge + handle + "View on Instagram" link + Reply button; sender block (avatar, name, email, "to <brand inbox> · timestamp"); email body (`white-space:pre-wrap`); optional threaded reply-from-brand block; inline reply composer (textarea + Send button) at the bottom. Empty state ("Select an email to read") when nothing selected.
**Data shape (`threads[]`):** `{id, name, handle, email, initials, avatarBg, subject, preview, status, statusBg, statusColor, lastActivity, unread, igUrl, body, hasReply, replyTime?, replyBody?}`. Status enum: `Sent | Opened | Replied` (a `Bounced` state was discussed but has no example row yet — add if backend supports it).
**State:** `statusFilter`, `selectedId`, `activeFolder`.

---

## Interactions & Behavior (cross-cutting)
- All "toast" confirmations: bottom-center, dark pill, 2.4s auto-dismiss, no manual close.
- All dropdowns/panels (notifications, profile, saved searches) toggle on click and should close on outside-click and on opening a sibling dropdown (only the outside-click behavior is stubbed in the prototype — implement it for real).
- Row/card hover: background shifts to `--sk-surface-sunken` (or raised shadow for Discovery cards); no other motion/transition beyond simple `box-shadow`/`background` transitions (~150ms ease).
- No page uses skeleton/loading/error states in the current build — add standard loading/empty/error handling per your app's conventions when wiring real data; there is no dictated pattern to copy from these files.

## State Management
Each screen is currently self-contained local component state (see the `state = {...}` block and `renderVals()` method at the bottom of each `.dc.html` — that's the authoritative list of state fields and derived values for that screen, referenced per-screen above). None of the screens share state with each other; cross-page relationships (e.g. a "Saved Influencer" also appearing in the Dashboard's "Top performing creators" list, or an Influencer Profile's campaign strip) are currently independent mock datasets with matching names — in production these should be joined through a real influencer/campaign ID rather than name-matching.

## Data Attribution Notes (for backend binding)
- Followers, engagement rate, avg. views, posts/week: intended to come from publicly available Instagram data (scraping/vendor). Engagement rate is a proxy — flag it as "estimated" in the UI if the real pipeline can't guarantee precision.
- Past collaborations / sponsored-post detection (Influencer Profile): implies detecting #ad/#sponsored tags on public posts — confirm this is feasible before committing to the table's "Reach (est.)" column.
- Saved-search persistence (Discovery): needs a per-user store keyed by filter object — no backend contract defined yet, this is the primary open question flagged for next steps.
- Campaign history / past performance / conversation status (Influencer Profile, Saved Influencers, Dashboard "Top performing creators"): needs a real join between influencer records and campaign records; exact shape (which fields, what "conversation status" values are canonical) is still open — resolve with backend before building the data layer.

## Assets & Icons
- Icons: Phosphor Icons v2.1.1 (`@phosphor-icons/react`), Regular/Bold/Fill weights.
- No photographic assets — all avatars are colored-initial circles, all post/reel tiles are tinted-color placeholders with an icon overlay. Production should swap these for real profile photos and real post thumbnails (likely proxied from Instagram's CDN, since hot-linking IG image URLs directly is unreliable).

## Files in This Bundle
| File | Contents |
|---|---|
| sk-theme.css | Design tokens — implement these as your app's CSS variables |
| AppSidebar.dc.html | Left nav shell |
| AppTopBar.dc.html | Top bar shell (credits, notifications, profile) |
| Dashboard.dc.html | Screen 1 |
| InfluencerDiscovery.dc.html | Screen 2 |
| InfluencerProfile.dc.html | Screen 3 |
| SavedInfluencers.dc.html | Screen 4 |
| CompetitiveAnalysis.dc.html | Screen 5 |
| Outreach.dc.html | Screen 6 |

Open each `.dc.html` in a browser to see the live prototype. Layout/copy is in the markup near the top of the file; state, mock data shapes, and event handlers are in the `class Component extends DCLogic { ... }` block near the bottom of each file (specifically the `state = {...}` and `renderVals()` — that pairing is the closest thing to a data contract for each screen).
