# CoachMe — Design System

> **CoachMe** is a mobile coaching app. It plays the role of an ICF-level coach: it *listens*, asks the right questions, helps you draft your **Future Version**, and keeps you gently accountable to the plan that gets you there.

This repository is the brand + product design system: design tokens, brand assets, reusable React components, and a high-fidelity recreation of the mobile app. A compiler reads the project and ships the tokens + components to consuming projects.

---

## Sources

This system was designed **from scratch** — no prior codebase, Figma, or brand assets were provided. Direction was set with the product owner:

- **Vibe:** calm + warm + reflective (explored across a few moods, landed on serene/editorial).
- **Palette:** deep forest-teal base, growth-green accent, warm sand neutrals (chosen from a swatch set).
- **Type:** editorial serif headlines + humanist sans body.
- **Imagery:** soft organic blob shapes.
- **Theming:** full light + dark.
- **Voice:** gentle & inquisitive — asks more than it tells.
- **Name treatment:** "CoachMe" (one word).

Reference points (for tone/feel only, nothing copied): the warmth of Headspace, the serenity of Calm, the reflective journaling of Stoic/Reflectly, and the clean component discipline of Notion.

> ⚠️ **Fonts are loaded from Google Fonts CDN**, not self-hosted binaries (none were provided). See "Fonts" below — drop `.woff2` files into `assets/fonts/` and swap the `@import` for `@font-face` rules to self-host.

---

## Content Fundamentals — how CoachMe writes

The voice is the product. CoachMe is a coach, not an app barking tasks.

- **Second person, present tense.** We talk to *you* ("What would make this week feel like a win **for you**?"). The coach rarely says "I".
- **Questions over instructions.** The default sentence is a question. We surface options, never demands. ✅ "What's the smallest first step?" ❌ "Complete 3 tasks to hit your target."
- **Gentle & unhurried.** Placeholders say "Take your time…"; empty states reassure ("No pressure."). We affirm effort, not just outcomes ("That counts for a lot.").
- **Warm, plain language.** Short words. Contractions ("you're", "let's", "honestly"). No jargon, no hustle-culture, no streak-shaming.
- **Meaning before metrics.** Goals always carry a *why* ("Move my body daily — *so I feel clear-headed*"). Numbers serve the story, never lead it.
- **Sentence case everywhere** except mono eyebrows/labels, which are `UPPERCASE` with wide tracking (e.g. `TODAY'S REFLECTION`, `DAILY`).
- **No emoji** in product copy. The sprout mark and soft shapes carry warmth instead.
- **Reflective moments use the serif voice** (see `ChatBubble serif`, reflection cards) — big questions deserve editorial weight.

Example coach turn:
> *"Good to see you. What would make this week feel like a win for you?"* → user replies → *"That counts. What's the one thing — and what's the smallest first step?"*

---

## Visual Foundations

**Color.** A deep **forest-teal** (`--forest-800 #0F2A2E`) grounds the brand; **growth green** (`--green-500 #3FB68B`) is the single accent (progress, affirmation, primary actions); **sand** (`--sand-200 #E8E0D0`) gives warm, papery neutrals; **clay** (`--clay-500 #D98E5F`) is a warm secondary for encouragement/celebration. Semantic colors (success/warning/danger/info) are tuned to sit in the palette — danger is a warm rust, not a fire-engine red. Everything routes through **semantic tokens** in `tokens/themes.css`; components never touch raw primitives. Full **light + dark** themes via `[data-theme]`.

**Type.** Headlines and reflective prompts are **Newsreader** (`--font-display`) — a warm literary serif, weights 400–500, tight tracking. UI and reading text are **Hanken Grotesk** (`--font-body`), a friendly humanist sans. **JetBrains Mono** (`--font-mono`) is used *only* for eyebrows, labels, timestamps, and data, always uppercase with `0.12em` tracking. Scale runs 11→72px on a 16px base.

**Spacing & layout.** 4px base rhythm (`--space-*`). Mobile screens use a 20–24px side gutter. Generous vertical breathing room — calm means space. Layouts are single-column, content-led; the bottom tab bar is the only fixed chrome.

**Corners.** Soft, not pill-everything. Cards = `--radius-lg` (20px). Inputs = `--radius-md` (14px). Buttons, chips, badges, switches = full pill. Icon containers = `--radius-md`.

**Elevation.** Shadows are **soft, diffuse, low-opacity and forest-tinted** (never hard/gray). Five steps (`--shadow-xs`→`xl`). Cards rest at `sm`, lift to `md` on hover. Dark theme deepens shadows. No harsh borders — dividers and borders are low-alpha ink (`--border`).

**Backgrounds.** Calm sand (light) / deep forest (dark). Depth comes from **soft organic blobs** (`assets/blob-*.svg`) bled off-edge at low opacity in brand tints — never sharp geometry, never busy gradients. Hero/reflection cards use the inverse forest surface with a faint blob.

**Motion.** Gentle and brief. `--ease-soft` / `--ease-out` for settles; `--duration-fast` (140ms) for press feedback, `--duration-base` (240ms) for transitions, `--duration-slow` (420ms) for progress fills. Press = subtle **scale down** (0.92–0.97), never bounce. Hover = lift + shadow, or a small color shift. No infinite decorative loops on content. An ambient `--duration-breath` (4s) exists for coaching/listening states.

**Imagery vibe.** Warm, natural, unhurried; greens and sands; soft and rounded. Avoid cold, clinical, high-contrast, or corporate stock energy.

---

## Iconography

- **System:** [**Lucide**](https://lucide.dev) at **stroke-width 1.75** (calm, rounded, consistent). Loaded from CDN: `<script src="https://unpkg.com/lucide@latest"></script>`.
- **Usage:** the `Icon` component (`components/core/Icon.jsx`) wraps Lucide — pass a `name` (e.g. `"sun"`, `"target"`, `"message-circle"`, `"footprints"`, `"sprout"`, `"compass"`, `"flame"`, `"sparkles"`). It requires the Lucide script on the page. Most components (`Button`, `IconButton`, `Badge`, `BottomNav`, `GoalCard`) accept icon names directly.
- **Brand mark:** the **sprout** (growth + listening) is a hand-built SVG, not a Lucide icon — see `assets/logo-mark*.svg`, `logo-badge.svg`, `wordmark*.svg`. It also appears inline as the coach's `Avatar coach` identity.
- **No emoji** as iconography. No unicode-glyph icons. Decorative shapes are the `blob-*.svg` set, used as ambient background art (tinted via `color` + `opacity`), never as content.

> Substitution flag: Lucide is a CDN substitution for a bespoke icon set (none existed). If you commission custom icons, replace the `Icon` wrapper's source and keep stroke-width ~1.75.

---

## Index / Manifest

**Root**
- `styles.css` — global entry point (import list only; consumers link this).
- `readme.md` — this file.
- `SKILL.md` — Agent-Skill front-matter for use in Claude Code.

**`tokens/`** — `colors.css`, `typography.css`, `spacing.css`, `radius.css`, `elevation.css` (shadows + motion), `themes.css` (light/dark semantic aliases), `fonts.css` (`@import` Google Fonts), `base.css` (reset + defaults).

**`assets/`** — `logo-mark.svg`, `logo-mark-mono.svg`, `logo-badge.svg`, `wordmark.svg`, `wordmark-light.svg`, `blob-1/2/3.svg`.

**`guidelines/`** — foundation specimen cards (Design System tab): colors (forest/green/sand/clay/semantic/themes), type (display/body/mono/scale), spacing (scale/radius/elevation), brand (logo/shapes/voice).

**`components/`** — reusable React primitives (each: `.jsx` + `.d.ts` + `.prompt.md`):
- `core/` — `Button`, `IconButton`, `Icon`, `Input`, `Textarea`, `Switch`, `Checkbox`, `Card`, `Badge`, `Avatar`, `ProgressBar`, `SegmentedControl`.
- `coaching/` — `ChatBubble`, `OptionChip`, `GoalCard` (the conversation primitives).
- `navigation/` — `BottomNav`.
- Consume via `const { Button } = window.CoachMeDesignSystem_e4f5b2` after loading `_ds_bundle.js`.

**`ui_kits/app/`** — interactive recreation of the CoachMe mobile app. `index.html` runs the full flow: onboarding intake → Today, Plan, Coach chat, Future Version, You (with live light/dark toggle). Screens in `screens-onboarding.jsx` + `screens-main.jsx`; phone chrome in `chrome.jsx`. `kit-components.jsx` is **auto-generated** from `components/**` so the kit renders without the runtime bundle — regenerate it if you edit a component.

---

## Using this system

1. Link `styles.css`.
2. Add the Lucide script (for icons) and, for components, load `_ds_bundle.js` and read from `window.CoachMeDesignSystem_e4f5b2`.
3. Build with **semantic tokens** (`--text-primary`, `--surface-card`, `--accent`), never raw primitives, so light/dark theming works for free.
4. Wrap a region in `[data-theme="dark"]` (or `"light"`) to scope a theme.
