/* @ds-bundle: {"format":3,"namespace":"CoachMeDesignSystem_e4f5b2","components":[{"name":"ChatBubble","sourcePath":"components/coaching/ChatBubble.jsx"},{"name":"GoalCard","sourcePath":"components/coaching/GoalCard.jsx"},{"name":"OptionChip","sourcePath":"components/coaching/OptionChip.jsx"},{"name":"Avatar","sourcePath":"components/core/Avatar.jsx"},{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Card","sourcePath":"components/core/Card.jsx"},{"name":"Checkbox","sourcePath":"components/core/Checkbox.jsx"},{"name":"Icon","sourcePath":"components/core/Icon.jsx"},{"name":"IconButton","sourcePath":"components/core/IconButton.jsx"},{"name":"Input","sourcePath":"components/core/Input.jsx"},{"name":"ProgressBar","sourcePath":"components/core/ProgressBar.jsx"},{"name":"SegmentedControl","sourcePath":"components/core/SegmentedControl.jsx"},{"name":"Switch","sourcePath":"components/core/Switch.jsx"},{"name":"Textarea","sourcePath":"components/core/Textarea.jsx"},{"name":"BottomNav","sourcePath":"components/navigation/BottomNav.jsx"}],"sourceHashes":{"components/coaching/ChatBubble.jsx":"17741b88e23a","components/coaching/GoalCard.jsx":"6a81e7c06227","components/coaching/OptionChip.jsx":"31bf6ecaa0a8","components/core/Avatar.jsx":"b4943dd964a2","components/core/Badge.jsx":"172440a6a740","components/core/Button.jsx":"e4c721660bbd","components/core/Card.jsx":"0659c50bca94","components/core/Checkbox.jsx":"5d7b73dcdcf9","components/core/Icon.jsx":"15645d2f7562","components/core/IconButton.jsx":"3351dd909d02","components/core/Input.jsx":"0792ccfc0ea4","components/core/ProgressBar.jsx":"5e0235ea3b95","components/core/SegmentedControl.jsx":"904f6879f30d","components/core/Switch.jsx":"110c269da28e","components/core/Textarea.jsx":"02134fd24bad","components/navigation/BottomNav.jsx":"a042e546a2be","ui_kits/app/chrome.jsx":"6d4ef67f2524","ui_kits/app/kit-components.jsx":"e946aa1a673a","ui_kits/app/screens-main.jsx":"11e171500637","ui_kits/app/screens-onboarding.jsx":"271bcfe096d3"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.CoachMeDesignSystem_e4f5b2 = window.CoachMeDesignSystem_e4f5b2 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/coaching/ChatBubble.jsx
try { (() => {
/**
 * ChatBubble — a single turn in the coaching conversation.
 * `from="coach"` is the deep forest bubble (the AI/coach voice);
 * `from="user"` is the soft/green bubble. Coach questions can use the
 * serif voice via `serif` for reflective prompts.
 */
function ChatBubble({
  from = 'coach',
  children,
  serif = false,
  time,
  style = {}
}) {
  const isCoach = from === 'coach';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: isCoach ? 'flex-start' : 'flex-end',
      gap: 'var(--space-1)',
      maxWidth: '86%',
      alignSelf: isCoach ? 'flex-start' : 'flex-end',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '12px 16px',
      borderRadius: 'var(--radius-lg)',
      borderBottomLeftRadius: isCoach ? 'var(--radius-xs)' : 'var(--radius-lg)',
      borderBottomRightRadius: isCoach ? 'var(--radius-lg)' : 'var(--radius-xs)',
      background: isCoach ? 'var(--coach-bubble)' : 'var(--user-bubble)',
      color: isCoach ? 'var(--coach-bubble-text)' : 'var(--user-bubble-text)',
      fontFamily: serif ? 'var(--font-display)' : 'var(--font-body)',
      fontSize: serif ? 'var(--text-lg)' : 'var(--text-base)',
      lineHeight: serif ? 'var(--leading-snug)' : 'var(--leading-normal)',
      fontWeight: 'var(--weight-regular)',
      boxShadow: 'var(--shadow-xs)'
    }
  }, children), time && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-2xs)',
      color: 'var(--text-faint)',
      padding: '0 6px'
    }
  }, time));
}
Object.assign(__ds_scope, { ChatBubble });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/coaching/ChatBubble.jsx", error: String((e && e.message) || e) }); }

// components/coaching/OptionChip.jsx
try { (() => {
/**
 * OptionChip — a tappable suggested reply. CoachMe offers gentle prompts
 * so users never face a blank box. Selectable (radio-like) or one-shot.
 */
function OptionChip({
  children,
  selected = false,
  onClick,
  icon,
  style = {}
}) {
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onClick,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 'var(--space-2)',
      padding: '10px 16px',
      borderRadius: 'var(--radius-pill)',
      border: `1.5px solid ${selected ? 'var(--accent)' : 'var(--border-strong)'}`,
      background: selected ? 'var(--surface-accent-soft)' : 'var(--surface)',
      color: selected ? 'var(--accent-press)' : 'var(--text-primary)',
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--text-sm)',
      fontWeight: 'var(--weight-medium)',
      whiteSpace: 'nowrap',
      cursor: 'pointer',
      transition: 'all var(--duration-fast) var(--ease-out)',
      ...style
    },
    onMouseDown: e => {
      e.currentTarget.style.transform = 'scale(0.97)';
    },
    onMouseUp: e => {
      e.currentTarget.style.transform = 'scale(1)';
    },
    onMouseLeave: e => {
      e.currentTarget.style.transform = 'scale(1)';
    }
  }, children);
}
Object.assign(__ds_scope, { OptionChip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/coaching/OptionChip.jsx", error: String((e && e.message) || e) }); }

// components/core/Avatar.jsx
try { (() => {
/**
 * Avatar — user or coach identity. Image, initials, or the CoachMe sprout.
 */
function Avatar({
  src,
  name = '',
  size = 44,
  coach = false,
  style = {}
}) {
  const initials = name.split(' ').map(p => p[0]).filter(Boolean).slice(0, 2).join('').toUpperCase();
  const base = {
    width: size,
    height: size,
    flex: 'none',
    borderRadius: 'var(--radius-circle)',
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
    fontFamily: 'var(--font-body)',
    fontWeight: 'var(--weight-semibold)',
    fontSize: size * 0.38,
    ...style
  };
  if (coach) {
    return /*#__PURE__*/React.createElement("span", {
      style: {
        ...base,
        background: 'var(--forest-800)'
      }
    }, /*#__PURE__*/React.createElement("svg", {
      viewBox: "0 0 48 48",
      width: size * 0.62,
      height: size * 0.62,
      "aria-hidden": "true"
    }, /*#__PURE__*/React.createElement("g", {
      fill: "#5FCBA3"
    }, /*#__PURE__*/React.createElement("path", {
      d: "M24 43c-.9 0-1.6-.7-1.6-1.6V22.5c0-.9.7-1.6 1.6-1.6s1.6.7 1.6 1.6v18.9c0 .9-.7 1.6-1.6 1.6z"
    }), /*#__PURE__*/React.createElement("path", {
      d: "M23 25.5c-.6-7.2-5.3-12.4-13.2-13.4-1 7.9 3.6 13.6 13.2 13.4z"
    }), /*#__PURE__*/React.createElement("path", {
      d: "M25 21.5c.6-8 6-13.8 14.7-14.9 1.1 8.8-4.1 15.1-14.7 14.9z",
      opacity: "0.78"
    }))));
  }
  if (src) {
    return /*#__PURE__*/React.createElement("img", {
      src: src,
      alt: name,
      style: {
        ...base,
        objectFit: 'cover'
      }
    });
  }
  return /*#__PURE__*/React.createElement("span", {
    style: {
      ...base,
      background: 'var(--clay-300)',
      color: 'var(--forest-900)'
    }
  }, initials || '·');
}
Object.assign(__ds_scope, { Avatar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Avatar.jsx", error: String((e && e.message) || e) }); }

// components/core/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Card — the primary surface container. Soft radius, gentle shadow.
 * Variants: default (surface + shadow), soft (sunken, no shadow),
 * outline (border only), inverse (forest fill), accent (green tint).
 */
function Card({
  children,
  variant = 'default',
  padding = 'var(--space-5)',
  interactive = false,
  style = {},
  ...rest
}) {
  const variants = {
    default: {
      background: 'var(--surface-card)',
      border: '1px solid var(--border)',
      boxShadow: 'var(--shadow-sm)'
    },
    soft: {
      background: 'var(--surface-sunken)',
      border: '1px solid transparent'
    },
    outline: {
      background: 'transparent',
      border: '1px solid var(--border-strong)'
    },
    inverse: {
      background: 'var(--surface-inverse)',
      color: 'var(--text-on-inverse)',
      border: '1px solid transparent',
      boxShadow: 'var(--shadow-md)'
    },
    accent: {
      background: 'var(--surface-accent-soft)',
      border: '1px solid transparent'
    }
  };
  const v = variants[variant] || variants.default;
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      borderRadius: 'var(--radius-lg)',
      padding,
      transition: interactive ? 'transform var(--duration-base) var(--ease-out), box-shadow var(--duration-base) var(--ease-standard)' : 'none',
      cursor: interactive ? 'pointer' : 'default',
      ...v,
      ...style
    },
    onMouseEnter: interactive ? e => {
      e.currentTarget.style.transform = 'translateY(-2px)';
      e.currentTarget.style.boxShadow = 'var(--shadow-md)';
    } : undefined,
    onMouseLeave: interactive ? e => {
      e.currentTarget.style.transform = 'translateY(0)';
      e.currentTarget.style.boxShadow = v.boxShadow || 'none';
    } : undefined
  }, rest), children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Card.jsx", error: String((e && e.message) || e) }); }

// components/core/Icon.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const {
  useEffect,
  useRef
} = React;
/**
 * Icon — thin wrapper over Lucide. Requires the Lucide UMD script on the page:
 * <script src="https://unpkg.com/lucide@latest"></script>
 * CoachMe uses Lucide at stroke-width 1.75 for a calm, rounded feel.
 */
function Icon({
  name,
  size = 20,
  strokeWidth = 1.75,
  color = 'currentColor',
  style = {},
  ...rest
}) {
  const ref = useRef(null);
  useEffect(() => {
    if (typeof window !== 'undefined' && window.lucide && ref.current) {
      window.lucide.createIcons({
        attrs: {
          'stroke-width': strokeWidth,
          width: size,
          height: size
        },
        nameAttr: 'data-lucide'
      });
    }
  });
  return /*#__PURE__*/React.createElement("span", _extends({
    ref: ref,
    style: {
      display: 'inline-flex',
      width: size,
      height: size,
      color,
      flex: 'none',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("i", {
    "data-lucide": name,
    style: {
      width: size,
      height: size
    }
  }));
}
Object.assign(__ds_scope, { Icon });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Icon.jsx", error: String((e && e.message) || e) }); }

// components/core/Badge.jsx
try { (() => {
/**
 * Badge — small status / count pill. Tones map to semantic colors.
 */
function Badge({
  children,
  tone = 'neutral',
  icon,
  size = 'md',
  style = {}
}) {
  const tones = {
    neutral: {
      background: 'var(--surface-sunken)',
      color: 'var(--text-secondary)'
    },
    accent: {
      background: 'var(--surface-accent-soft)',
      color: 'var(--accent-press)'
    },
    success: {
      background: 'var(--success-soft)',
      color: 'var(--success)'
    },
    warning: {
      background: 'var(--warning-soft)',
      color: '#9A6A14'
    },
    danger: {
      background: 'var(--danger-soft)',
      color: 'var(--danger)'
    },
    warm: {
      background: 'var(--surface-warm-soft)',
      color: 'var(--warm-hover)'
    }
  };
  const sizes = {
    sm: {
      font: 'var(--text-2xs)',
      pad: '2px 8px',
      icon: 12
    },
    md: {
      font: 'var(--text-xs)',
      pad: '4px 10px',
      icon: 13
    }
  };
  const t = tones[tone] || tones.neutral;
  const s = sizes[size] || sizes.md;
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 'var(--space-1)',
      padding: s.pad,
      fontSize: s.font,
      fontWeight: 'var(--weight-semibold)',
      lineHeight: 1,
      whiteSpace: 'nowrap',
      borderRadius: 'var(--radius-pill)',
      ...t,
      ...style
    }
  }, icon && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: s.icon
  }), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Button — CoachMe's primary action element.
 * Variants: primary (green), secondary (soft surface), ghost (text only),
 * warm (clay), inverse (forest on light). Sizes: sm, md, lg. Optional icons.
 */
function Button({
  children,
  variant = 'primary',
  size = 'md',
  iconLeft,
  iconRight,
  fullWidth = false,
  disabled = false,
  type = 'button',
  style = {},
  ...rest
}) {
  const sizes = {
    sm: {
      padding: '0 14px',
      height: 36,
      font: 'var(--text-sm)',
      icon: 16,
      radius: 'var(--radius-pill)'
    },
    md: {
      padding: '0 20px',
      height: 46,
      font: 'var(--text-base)',
      icon: 18,
      radius: 'var(--radius-pill)'
    },
    lg: {
      padding: '0 28px',
      height: 56,
      font: 'var(--text-md)',
      icon: 20,
      radius: 'var(--radius-pill)'
    }
  };
  const variants = {
    primary: {
      background: 'var(--accent)',
      color: 'var(--accent-contrast)',
      border: '1px solid transparent',
      boxShadow: 'var(--shadow-sm)'
    },
    secondary: {
      background: 'var(--surface-sunken)',
      color: 'var(--text-primary)',
      border: '1px solid var(--border)'
    },
    ghost: {
      background: 'transparent',
      color: 'var(--text-primary)',
      border: '1px solid transparent'
    },
    warm: {
      background: 'var(--warm)',
      color: 'var(--forest-950)',
      border: '1px solid transparent',
      boxShadow: 'var(--shadow-sm)'
    },
    inverse: {
      background: 'var(--surface-inverse)',
      color: 'var(--text-on-inverse)',
      border: '1px solid transparent',
      boxShadow: 'var(--shadow-sm)'
    }
  };
  const s = sizes[size] || sizes.md;
  const v = variants[variant] || variants.primary;
  return /*#__PURE__*/React.createElement("button", _extends({
    type: type,
    disabled: disabled,
    className: `cm-btn cm-btn--${variant}`,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 'var(--space-2)',
      height: s.height,
      padding: s.padding,
      width: fullWidth ? '100%' : 'auto',
      fontFamily: 'var(--font-body)',
      fontSize: s.font,
      fontWeight: 'var(--weight-semibold)',
      letterSpacing: '0.005em',
      whiteSpace: 'nowrap',
      borderRadius: s.radius,
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.45 : 1,
      transition: 'transform var(--duration-fast) var(--ease-out), background var(--duration-fast) var(--ease-standard), box-shadow var(--duration-fast) var(--ease-standard)',
      ...v,
      ...style
    },
    onMouseDown: e => {
      if (!disabled) e.currentTarget.style.transform = 'scale(0.97)';
    },
    onMouseUp: e => {
      e.currentTarget.style.transform = 'scale(1)';
    },
    onMouseLeave: e => {
      e.currentTarget.style.transform = 'scale(1)';
    }
  }, rest), iconLeft && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: iconLeft,
    size: s.icon
  }), children, iconRight && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: iconRight,
    size: s.icon
  }));
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Checkbox.jsx
try { (() => {
/**
 * Checkbox — used for plan steps & task lists. Green fill + check when done.
 */
function Checkbox({
  checked = false,
  onChange,
  disabled = false,
  label,
  style = {}
}) {
  const handle = () => {
    if (!disabled && onChange) onChange(!checked);
  };
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 'var(--space-3)',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.5 : 1,
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    onClick: handle,
    role: "checkbox",
    "aria-checked": checked,
    style: {
      width: 24,
      height: 24,
      flex: 'none',
      borderRadius: 'var(--radius-sm)',
      border: `1.5px solid ${checked ? 'var(--accent)' : 'var(--field-border)'}`,
      background: checked ? 'var(--accent)' : 'var(--field-bg)',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      transition: 'all var(--duration-fast) var(--ease-out)'
    }
  }, checked && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "check",
    size: 16,
    color: "var(--accent-contrast)"
  })), label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-base)',
      color: 'var(--text-primary)',
      textDecoration: checked ? 'line-through' : 'none',
      textDecorationColor: 'var(--text-faint)'
    }
  }, label));
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/core/IconButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * IconButton — square/circular tap target for a single icon action.
 * Variants: solid, soft, ghost. Always >= 44px hit area at md+.
 */
function IconButton({
  icon,
  variant = 'ghost',
  size = 'md',
  shape = 'circle',
  disabled = false,
  label,
  style = {},
  ...rest
}) {
  const sizes = {
    sm: 36,
    md: 44,
    lg: 52
  };
  const iconSizes = {
    sm: 18,
    md: 20,
    lg: 24
  };
  const variants = {
    solid: {
      background: 'var(--accent)',
      color: 'var(--accent-contrast)',
      border: '1px solid transparent'
    },
    soft: {
      background: 'var(--surface-sunken)',
      color: 'var(--text-primary)',
      border: '1px solid var(--border)'
    },
    ghost: {
      background: 'transparent',
      color: 'var(--text-secondary)',
      border: '1px solid transparent'
    }
  };
  const dim = sizes[size] || sizes.md;
  const v = variants[variant] || variants.ghost;
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    "aria-label": label,
    disabled: disabled,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      width: dim,
      height: dim,
      borderRadius: shape === 'circle' ? 'var(--radius-circle)' : 'var(--radius-md)',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.45 : 1,
      transition: 'transform var(--duration-fast) var(--ease-out), background var(--duration-fast) var(--ease-standard)',
      ...v,
      ...style
    },
    onMouseDown: e => {
      if (!disabled) e.currentTarget.style.transform = 'scale(0.92)';
    },
    onMouseUp: e => {
      e.currentTarget.style.transform = 'scale(1)';
    },
    onMouseLeave: e => {
      e.currentTarget.style.transform = 'scale(1)';
    }
  }, rest), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: iconSizes[size] || 20
  }));
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/core/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Input — labelled text field. Calm focus ring, generous height.
 */
function Input({
  label,
  hint,
  error,
  iconLeft,
  id,
  style = {},
  ...rest
}) {
  const inputId = id || (label ? `cm-${label.replace(/\s+/g, '-').toLowerCase()}` : undefined);
  const [focused, setFocused] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-2)',
      width: '100%',
      ...style
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    htmlFor: inputId,
    style: {
      fontSize: 'var(--text-sm)',
      fontWeight: 'var(--weight-semibold)',
      color: 'var(--text-primary)'
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-2)',
      height: 50,
      padding: '0 16px',
      background: 'var(--field-bg)',
      border: `1.5px solid ${error ? 'var(--danger)' : focused ? 'var(--accent)' : 'var(--field-border)'}`,
      borderRadius: 'var(--radius-md)',
      boxShadow: focused ? 'var(--ring-focus)' : 'none',
      transition: 'border-color var(--duration-fast) var(--ease-standard), box-shadow var(--duration-fast) var(--ease-standard)'
    }
  }, iconLeft && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: iconLeft,
    size: 18,
    color: "var(--text-muted)"
  }), /*#__PURE__*/React.createElement("input", _extends({
    id: inputId,
    onFocus: e => {
      setFocused(true);
      rest.onFocus && rest.onFocus(e);
    },
    onBlur: e => {
      setFocused(false);
      rest.onBlur && rest.onBlur(e);
    }
  }, rest, {
    style: {
      flex: 1,
      border: 'none',
      outline: 'none',
      background: 'transparent',
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--text-base)',
      color: 'var(--text-primary)',
      minWidth: 0
    }
  }))), (hint || error) && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-xs)',
      color: error ? 'var(--danger)' : 'var(--text-muted)'
    }
  }, error || hint));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Input.jsx", error: String((e && e.message) || e) }); }

// components/core/ProgressBar.jsx
try { (() => {
/**
 * ProgressBar — calm horizontal progress for goals & plans.
 */
function ProgressBar({
  value = 0,
  max = 100,
  tone = 'accent',
  showLabel = false,
  label,
  height = 8,
  style = {}
}) {
  const pct = Math.max(0, Math.min(100, value / max * 100));
  const tones = {
    accent: 'var(--accent)',
    warm: 'var(--warm)',
    success: 'var(--success)'
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      width: '100%',
      ...style
    }
  }, (showLabel || label) && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      marginBottom: 'var(--space-2)',
      fontSize: 'var(--text-sm)',
      color: 'var(--text-secondary)'
    }
  }, /*#__PURE__*/React.createElement("span", null, label), showLabel && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-xs)',
      color: 'var(--text-muted)'
    }
  }, Math.round(pct), "%")), /*#__PURE__*/React.createElement("div", {
    style: {
      width: '100%',
      height,
      background: 'var(--surface-sunken)',
      borderRadius: 'var(--radius-pill)',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: `${pct}%`,
      height: '100%',
      background: tones[tone] || tones.accent,
      borderRadius: 'var(--radius-pill)',
      transition: 'width var(--duration-slow) var(--ease-soft)'
    }
  })));
}
Object.assign(__ds_scope, { ProgressBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/ProgressBar.jsx", error: String((e && e.message) || e) }); }

// components/coaching/GoalCard.jsx
try { (() => {
/**
 * GoalCard — a single goal toward the user's Future Version.
 * Shows title, a one-line "why", progress, and a streak/cadence badge.
 */
function GoalCard({
  title,
  why,
  value = 0,
  max = 100,
  cadence,
  icon = 'target',
  tone = 'accent',
  onClick,
  style = {}
}) {
  return /*#__PURE__*/React.createElement("div", {
    onClick: onClick,
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-3)',
      padding: 'var(--space-5)',
      background: 'var(--surface-card)',
      border: '1px solid var(--border)',
      borderRadius: 'var(--radius-lg)',
      boxShadow: 'var(--shadow-sm)',
      cursor: onClick ? 'pointer' : 'default',
      transition: 'transform var(--duration-base) var(--ease-out), box-shadow var(--duration-base) var(--ease-standard)',
      ...style
    },
    onMouseEnter: onClick ? e => {
      e.currentTarget.style.transform = 'translateY(-2px)';
      e.currentTarget.style.boxShadow = 'var(--shadow-md)';
    } : undefined,
    onMouseLeave: onClick ? e => {
      e.currentTarget.style.transform = 'translateY(0)';
      e.currentTarget.style.boxShadow = 'var(--shadow-sm)';
    } : undefined
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-start',
      gap: 'var(--space-3)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 42,
      height: 42,
      flex: 'none',
      borderRadius: 'var(--radius-md)',
      background: 'var(--surface-accent-soft)',
      color: 'var(--accent-press)',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 20
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("h4", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--text-lg)',
      fontWeight: 'var(--weight-medium)',
      color: 'var(--text-primary)',
      margin: 0
    }
  }, title), why && /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--text-sm)',
      color: 'var(--text-secondary)',
      margin: '2px 0 0'
    }
  }, why)), cadence && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-2xs)',
      letterSpacing: '0.08em',
      textTransform: 'uppercase',
      color: 'var(--text-muted)',
      whiteSpace: 'nowrap'
    }
  }, cadence)), /*#__PURE__*/React.createElement(__ds_scope.ProgressBar, {
    value: value,
    max: max,
    tone: tone,
    showLabel: true
  }));
}
Object.assign(__ds_scope, { GoalCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/coaching/GoalCard.jsx", error: String((e && e.message) || e) }); }

// components/core/SegmentedControl.jsx
try { (() => {
/**
 * SegmentedControl — pill switcher for 2–4 views (e.g. Day / Week / Month).
 */
function SegmentedControl({
  options = [],
  value,
  onChange,
  style = {}
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'inline-flex',
      padding: 4,
      gap: 2,
      background: 'var(--surface-sunken)',
      borderRadius: 'var(--radius-pill)',
      border: '1px solid var(--border)',
      ...style
    }
  }, options.map(opt => {
    const val = typeof opt === 'string' ? opt : opt.value;
    const lbl = typeof opt === 'string' ? opt : opt.label;
    const active = val === value;
    return /*#__PURE__*/React.createElement("button", {
      key: val,
      type: "button",
      onClick: () => onChange && onChange(val),
      style: {
        border: 'none',
        cursor: 'pointer',
        padding: '8px 18px',
        borderRadius: 'var(--radius-pill)',
        fontFamily: 'var(--font-body)',
        fontSize: 'var(--text-sm)',
        fontWeight: 'var(--weight-semibold)',
        color: active ? 'var(--text-primary)' : 'var(--text-muted)',
        background: active ? 'var(--surface)' : 'transparent',
        boxShadow: active ? 'var(--shadow-xs)' : 'none',
        transition: 'all var(--duration-fast) var(--ease-out)'
      }
    }, lbl);
  }));
}
Object.assign(__ds_scope, { SegmentedControl });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/SegmentedControl.jsx", error: String((e && e.message) || e) }); }

// components/core/Switch.jsx
try { (() => {
/**
 * Switch — on/off toggle. Green when on, calm slide.
 */
function Switch({
  checked = false,
  onChange,
  disabled = false,
  label,
  id,
  style = {}
}) {
  const handle = () => {
    if (!disabled && onChange) onChange(!checked);
  };
  const sw = /*#__PURE__*/React.createElement("button", {
    type: "button",
    role: "switch",
    "aria-checked": checked,
    disabled: disabled,
    onClick: handle,
    style: {
      width: 48,
      height: 28,
      borderRadius: 'var(--radius-pill)',
      border: 'none',
      padding: 3,
      background: checked ? 'var(--accent)' : 'var(--sand-300)',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.5 : 1,
      transition: 'background var(--duration-base) var(--ease-soft)',
      display: 'inline-flex',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 22,
      height: 22,
      borderRadius: 'var(--radius-circle)',
      background: 'var(--white)',
      boxShadow: 'var(--shadow-sm)',
      transform: checked ? 'translateX(20px)' : 'translateX(0)',
      transition: 'transform var(--duration-base) var(--ease-soft)'
    }
  }));
  if (!label) return /*#__PURE__*/React.createElement("span", {
    style: style
  }, sw);
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 'var(--space-3)',
      cursor: disabled ? 'not-allowed' : 'pointer',
      ...style
    }
  }, sw, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-base)',
      color: 'var(--text-primary)'
    }
  }, label));
}
Object.assign(__ds_scope, { Switch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Switch.jsx", error: String((e && e.message) || e) }); }

// components/core/Textarea.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Textarea — multi-line reflective input. Used for journals & check-ins.
 */
function Textarea({
  label,
  hint,
  rows = 4,
  id,
  style = {},
  ...rest
}) {
  const inputId = id || (label ? `cm-${label.replace(/\s+/g, '-').toLowerCase()}` : undefined);
  const [focused, setFocused] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-2)',
      width: '100%',
      ...style
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    htmlFor: inputId,
    style: {
      fontSize: 'var(--text-sm)',
      fontWeight: 'var(--weight-semibold)',
      color: 'var(--text-primary)'
    }
  }, label), /*#__PURE__*/React.createElement("textarea", _extends({
    id: inputId,
    rows: rows,
    onFocus: e => {
      setFocused(true);
      rest.onFocus && rest.onFocus(e);
    },
    onBlur: e => {
      setFocused(false);
      rest.onBlur && rest.onBlur(e);
    }
  }, rest, {
    style: {
      width: '100%',
      padding: '14px 16px',
      background: 'var(--field-bg)',
      border: `1.5px solid ${focused ? 'var(--accent)' : 'var(--field-border)'}`,
      borderRadius: 'var(--radius-md)',
      boxShadow: focused ? 'var(--ring-focus)' : 'none',
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--text-base)',
      lineHeight: 'var(--leading-relaxed)',
      color: 'var(--text-primary)',
      resize: 'vertical',
      outline: 'none',
      transition: 'border-color var(--duration-fast) var(--ease-standard), box-shadow var(--duration-fast) var(--ease-standard)'
    }
  })), hint && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-xs)',
      color: 'var(--text-muted)'
    }
  }, hint));
}
Object.assign(__ds_scope, { Textarea });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Textarea.jsx", error: String((e && e.message) || e) }); }

// components/navigation/BottomNav.jsx
try { (() => {
/**
 * BottomNav — mobile tab bar. Active tab gets the green accent.
 * The center "talk to coach" action can be emphasized via `emphasis`.
 */
function BottomNav({
  items = [],
  value,
  onChange,
  style = {}
}) {
  return /*#__PURE__*/React.createElement("nav", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-around',
      gap: 'var(--space-1)',
      padding: '10px 12px calc(10px + env(safe-area-inset-bottom))',
      background: 'var(--surface)',
      borderTop: '1px solid var(--border)',
      boxShadow: 'var(--shadow-lg)',
      ...style
    }
  }, items.map(item => {
    const active = item.value === value;
    if (item.emphasis) {
      return /*#__PURE__*/React.createElement("button", {
        key: item.value,
        type: "button",
        onClick: () => onChange && onChange(item.value),
        "aria-label": item.label,
        style: {
          width: 56,
          height: 56,
          flex: 'none',
          marginTop: -22,
          borderRadius: 'var(--radius-circle)',
          border: '4px solid var(--surface)',
          background: 'var(--accent)',
          color: 'var(--accent-contrast)',
          display: 'inline-flex',
          alignItems: 'center',
          justifyContent: 'center',
          cursor: 'pointer',
          boxShadow: 'var(--shadow-md)'
        }
      }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
        name: item.icon,
        size: 26
      }));
    }
    return /*#__PURE__*/React.createElement("button", {
      key: item.value,
      type: "button",
      onClick: () => onChange && onChange(item.value),
      style: {
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        gap: 3,
        flex: 1,
        border: 'none',
        background: 'transparent',
        cursor: 'pointer',
        color: active ? 'var(--accent-press)' : 'var(--text-faint)',
        transition: 'color var(--duration-fast) var(--ease-standard)'
      }
    }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
      name: item.icon,
      size: 23,
      strokeWidth: active ? 2.1 : 1.75
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 'var(--text-2xs)',
        fontWeight: active ? 'var(--weight-semibold)' : 'var(--weight-medium)'
      }
    }, item.label));
  }));
}
Object.assign(__ds_scope, { BottomNav });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/BottomNav.jsx", error: String((e && e.message) || e) }); }

// ui_kits/app/chrome.jsx
try { (() => {
// CoachMe app — shared chrome: phone frame, status bar, decorative backdrop.
const {
  useState: _us
} = React;
function StatusBar({
  dark
}) {
  const color = dark ? 'var(--sand-50)' : 'var(--forest-900)';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      height: 44,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '0 24px',
      flex: 'none'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 14,
      fontWeight: 600,
      color
    }
  }, "9:41"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 6,
      alignItems: 'center',
      color
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 11
    }
  }), /*#__PURE__*/React.createElement("svg", {
    width: "17",
    height: "11",
    viewBox: "0 0 17 11",
    fill: color
  }, /*#__PURE__*/React.createElement("rect", {
    x: "0",
    y: "6",
    width: "3",
    height: "5",
    rx: "1"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "4.5",
    y: "4",
    width: "3",
    height: "7",
    rx: "1"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "9",
    y: "2",
    width: "3",
    height: "9",
    rx: "1"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "13.5",
    y: "0",
    width: "3",
    height: "11",
    rx: "1"
  })), /*#__PURE__*/React.createElement("svg", {
    width: "24",
    height: "12",
    viewBox: "0 0 24 12",
    fill: "none"
  }, /*#__PURE__*/React.createElement("rect", {
    x: "0.5",
    y: "0.5",
    width: "20",
    height: "11",
    rx: "3",
    stroke: color,
    opacity: "0.45"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "2",
    y: "2",
    width: "16",
    height: "8",
    rx: "1.5",
    fill: color
  }), /*#__PURE__*/React.createElement("rect", {
    x: "21.5",
    y: "4",
    width: "1.5",
    height: "4",
    rx: "0.75",
    fill: color,
    opacity: "0.45"
  }))));
}

// Soft organic blob backdrop (decorative)
function BlobBackdrop({
  tone = 'var(--green-200)',
  tone2 = 'var(--clay-200)'
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      overflow: 'hidden',
      pointerEvents: 'none',
      zIndex: 0
    },
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/blob-1.svg",
    style: {
      position: 'absolute',
      top: -90,
      right: -70,
      width: 280,
      color: tone,
      opacity: 0.5
    }
  }), /*#__PURE__*/React.createElement("img", {
    src: "../../assets/blob-3.svg",
    style: {
      position: 'absolute',
      bottom: -120,
      left: -90,
      width: 300,
      color: tone2,
      opacity: 0.45
    }
  }));
}

// The CoachMe sprout (inline, themable via fill prop)
function Sprout({
  size = 40,
  fill = 'var(--accent)'
}) {
  return /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 48 48",
    width: size,
    height: size,
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("g", {
    fill: fill
  }, /*#__PURE__*/React.createElement("path", {
    d: "M24 43c-.9 0-1.6-.7-1.6-1.6V22.5c0-.9.7-1.6 1.6-1.6s1.6.7 1.6 1.6v18.9c0 .9-.7 1.6-1.6 1.6z"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M23 25.5c-.6-7.2-5.3-12.4-13.2-13.4-1 7.9 3.6 13.6 13.2 13.4z"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M25 21.5c.6-8 6-13.8 14.7-14.9 1.1 8.8-4.1 15.1-14.7 14.9z",
    opacity: "0.78"
  })));
}

// Phone frame — 390x844, rounded bezel. Applies theme to inner surface.
function PhoneFrame({
  children,
  theme = 'light'
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      width: 390,
      height: 844,
      flex: 'none',
      borderRadius: 54,
      padding: 12,
      background: '#0a0a0a',
      boxShadow: 'var(--shadow-xl)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    "data-theme": theme,
    style: {
      position: 'relative',
      width: '100%',
      height: '100%',
      borderRadius: 42,
      overflow: 'hidden',
      background: 'var(--bg)',
      display: 'flex',
      flexDirection: 'column'
    }
  }, children));
}
window.CoachMeChrome = {
  StatusBar,
  BlobBackdrop,
  Sprout,
  PhoneFrame
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/chrome.jsx", error: String((e && e.message) || e) }); }

// ui_kits/app/kit-components.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
// AUTO-GENERATED from components/**.jsx — do not hand-edit.
const {
  useState,
  useEffect,
  useRef,
  useMemo,
  useCallback
} = React;

// ===== components/core/Icon.jsx =====

/**
 * Icon — thin wrapper over Lucide. Requires the Lucide UMD script on the page:
 * <script src="https://unpkg.com/lucide@latest"></script>
 * CoachMe uses Lucide at stroke-width 1.75 for a calm, rounded feel.
 */
function Icon({
  name,
  size = 20,
  strokeWidth = 1.75,
  color = 'currentColor',
  style = {},
  ...rest
}) {
  const ref = useRef(null);
  useEffect(() => {
    if (typeof window !== 'undefined' && window.lucide && ref.current) {
      window.lucide.createIcons({
        attrs: {
          'stroke-width': strokeWidth,
          width: size,
          height: size
        },
        nameAttr: 'data-lucide'
      });
    }
  });
  return /*#__PURE__*/React.createElement("span", _extends({
    ref: ref,
    style: {
      display: 'inline-flex',
      width: size,
      height: size,
      color,
      flex: 'none',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("i", {
    "data-lucide": name,
    style: {
      width: size,
      height: size
    }
  }));
}

// ===== components/core/Button.jsx =====

/**
 * Button — CoachMe's primary action element.
 * Variants: primary (green), secondary (soft surface), ghost (text only),
 * warm (clay), inverse (forest on light). Sizes: sm, md, lg. Optional icons.
 */
function Button({
  children,
  variant = 'primary',
  size = 'md',
  iconLeft,
  iconRight,
  fullWidth = false,
  disabled = false,
  type = 'button',
  style = {},
  ...rest
}) {
  const sizes = {
    sm: {
      padding: '0 14px',
      height: 36,
      font: 'var(--text-sm)',
      icon: 16,
      radius: 'var(--radius-pill)'
    },
    md: {
      padding: '0 20px',
      height: 46,
      font: 'var(--text-base)',
      icon: 18,
      radius: 'var(--radius-pill)'
    },
    lg: {
      padding: '0 28px',
      height: 56,
      font: 'var(--text-md)',
      icon: 20,
      radius: 'var(--radius-pill)'
    }
  };
  const variants = {
    primary: {
      background: 'var(--accent)',
      color: 'var(--accent-contrast)',
      border: '1px solid transparent',
      boxShadow: 'var(--shadow-sm)'
    },
    secondary: {
      background: 'var(--surface-sunken)',
      color: 'var(--text-primary)',
      border: '1px solid var(--border)'
    },
    ghost: {
      background: 'transparent',
      color: 'var(--text-primary)',
      border: '1px solid transparent'
    },
    warm: {
      background: 'var(--warm)',
      color: 'var(--forest-950)',
      border: '1px solid transparent',
      boxShadow: 'var(--shadow-sm)'
    },
    inverse: {
      background: 'var(--surface-inverse)',
      color: 'var(--text-on-inverse)',
      border: '1px solid transparent',
      boxShadow: 'var(--shadow-sm)'
    }
  };
  const s = sizes[size] || sizes.md;
  const v = variants[variant] || variants.primary;
  return /*#__PURE__*/React.createElement("button", _extends({
    type: type,
    disabled: disabled,
    className: `cm-btn cm-btn--${variant}`,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 'var(--space-2)',
      height: s.height,
      padding: s.padding,
      width: fullWidth ? '100%' : 'auto',
      fontFamily: 'var(--font-body)',
      fontSize: s.font,
      fontWeight: 'var(--weight-semibold)',
      letterSpacing: '0.005em',
      whiteSpace: 'nowrap',
      borderRadius: s.radius,
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.45 : 1,
      transition: 'transform var(--duration-fast) var(--ease-out), background var(--duration-fast) var(--ease-standard), box-shadow var(--duration-fast) var(--ease-standard)',
      ...v,
      ...style
    },
    onMouseDown: e => {
      if (!disabled) e.currentTarget.style.transform = 'scale(0.97)';
    },
    onMouseUp: e => {
      e.currentTarget.style.transform = 'scale(1)';
    },
    onMouseLeave: e => {
      e.currentTarget.style.transform = 'scale(1)';
    }
  }, rest), iconLeft && /*#__PURE__*/React.createElement(Icon, {
    name: iconLeft,
    size: s.icon
  }), children, iconRight && /*#__PURE__*/React.createElement(Icon, {
    name: iconRight,
    size: s.icon
  }));
}

// ===== components/core/IconButton.jsx =====

/**
 * IconButton — square/circular tap target for a single icon action.
 * Variants: solid, soft, ghost. Always >= 44px hit area at md+.
 */
function IconButton({
  icon,
  variant = 'ghost',
  size = 'md',
  shape = 'circle',
  disabled = false,
  label,
  style = {},
  ...rest
}) {
  const sizes = {
    sm: 36,
    md: 44,
    lg: 52
  };
  const iconSizes = {
    sm: 18,
    md: 20,
    lg: 24
  };
  const variants = {
    solid: {
      background: 'var(--accent)',
      color: 'var(--accent-contrast)',
      border: '1px solid transparent'
    },
    soft: {
      background: 'var(--surface-sunken)',
      color: 'var(--text-primary)',
      border: '1px solid var(--border)'
    },
    ghost: {
      background: 'transparent',
      color: 'var(--text-secondary)',
      border: '1px solid transparent'
    }
  };
  const dim = sizes[size] || sizes.md;
  const v = variants[variant] || variants.ghost;
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    "aria-label": label,
    disabled: disabled,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      width: dim,
      height: dim,
      borderRadius: shape === 'circle' ? 'var(--radius-circle)' : 'var(--radius-md)',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.45 : 1,
      transition: 'transform var(--duration-fast) var(--ease-out), background var(--duration-fast) var(--ease-standard)',
      ...v,
      ...style
    },
    onMouseDown: e => {
      if (!disabled) e.currentTarget.style.transform = 'scale(0.92)';
    },
    onMouseUp: e => {
      e.currentTarget.style.transform = 'scale(1)';
    },
    onMouseLeave: e => {
      e.currentTarget.style.transform = 'scale(1)';
    }
  }, rest), /*#__PURE__*/React.createElement(Icon, {
    name: icon,
    size: iconSizes[size] || 20
  }));
}

// ===== components/core/Input.jsx =====

/**
 * Input — labelled text field. Calm focus ring, generous height.
 */
function Input({
  label,
  hint,
  error,
  iconLeft,
  id,
  style = {},
  ...rest
}) {
  const inputId = id || (label ? `cm-${label.replace(/\s+/g, '-').toLowerCase()}` : undefined);
  const [focused, setFocused] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-2)',
      width: '100%',
      ...style
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    htmlFor: inputId,
    style: {
      fontSize: 'var(--text-sm)',
      fontWeight: 'var(--weight-semibold)',
      color: 'var(--text-primary)'
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-2)',
      height: 50,
      padding: '0 16px',
      background: 'var(--field-bg)',
      border: `1.5px solid ${error ? 'var(--danger)' : focused ? 'var(--accent)' : 'var(--field-border)'}`,
      borderRadius: 'var(--radius-md)',
      boxShadow: focused ? 'var(--ring-focus)' : 'none',
      transition: 'border-color var(--duration-fast) var(--ease-standard), box-shadow var(--duration-fast) var(--ease-standard)'
    }
  }, iconLeft && /*#__PURE__*/React.createElement(Icon, {
    name: iconLeft,
    size: 18,
    color: "var(--text-muted)"
  }), /*#__PURE__*/React.createElement("input", _extends({
    id: inputId,
    onFocus: e => {
      setFocused(true);
      rest.onFocus && rest.onFocus(e);
    },
    onBlur: e => {
      setFocused(false);
      rest.onBlur && rest.onBlur(e);
    }
  }, rest, {
    style: {
      flex: 1,
      border: 'none',
      outline: 'none',
      background: 'transparent',
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--text-base)',
      color: 'var(--text-primary)',
      minWidth: 0
    }
  }))), (hint || error) && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-xs)',
      color: error ? 'var(--danger)' : 'var(--text-muted)'
    }
  }, error || hint));
}

// ===== components/core/Textarea.jsx =====

/**
 * Textarea — multi-line reflective input. Used for journals & check-ins.
 */
function Textarea({
  label,
  hint,
  rows = 4,
  id,
  style = {},
  ...rest
}) {
  const inputId = id || (label ? `cm-${label.replace(/\s+/g, '-').toLowerCase()}` : undefined);
  const [focused, setFocused] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-2)',
      width: '100%',
      ...style
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    htmlFor: inputId,
    style: {
      fontSize: 'var(--text-sm)',
      fontWeight: 'var(--weight-semibold)',
      color: 'var(--text-primary)'
    }
  }, label), /*#__PURE__*/React.createElement("textarea", _extends({
    id: inputId,
    rows: rows,
    onFocus: e => {
      setFocused(true);
      rest.onFocus && rest.onFocus(e);
    },
    onBlur: e => {
      setFocused(false);
      rest.onBlur && rest.onBlur(e);
    }
  }, rest, {
    style: {
      width: '100%',
      padding: '14px 16px',
      background: 'var(--field-bg)',
      border: `1.5px solid ${focused ? 'var(--accent)' : 'var(--field-border)'}`,
      borderRadius: 'var(--radius-md)',
      boxShadow: focused ? 'var(--ring-focus)' : 'none',
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--text-base)',
      lineHeight: 'var(--leading-relaxed)',
      color: 'var(--text-primary)',
      resize: 'vertical',
      outline: 'none',
      transition: 'border-color var(--duration-fast) var(--ease-standard), box-shadow var(--duration-fast) var(--ease-standard)'
    }
  })), hint && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-xs)',
      color: 'var(--text-muted)'
    }
  }, hint));
}

// ===== components/core/Switch.jsx =====

/**
 * Switch — on/off toggle. Green when on, calm slide.
 */
function Switch({
  checked = false,
  onChange,
  disabled = false,
  label,
  id,
  style = {}
}) {
  const handle = () => {
    if (!disabled && onChange) onChange(!checked);
  };
  const sw = /*#__PURE__*/React.createElement("button", {
    type: "button",
    role: "switch",
    "aria-checked": checked,
    disabled: disabled,
    onClick: handle,
    style: {
      width: 48,
      height: 28,
      borderRadius: 'var(--radius-pill)',
      border: 'none',
      padding: 3,
      background: checked ? 'var(--accent)' : 'var(--sand-300)',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.5 : 1,
      transition: 'background var(--duration-base) var(--ease-soft)',
      display: 'inline-flex',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 22,
      height: 22,
      borderRadius: 'var(--radius-circle)',
      background: 'var(--white)',
      boxShadow: 'var(--shadow-sm)',
      transform: checked ? 'translateX(20px)' : 'translateX(0)',
      transition: 'transform var(--duration-base) var(--ease-soft)'
    }
  }));
  if (!label) return /*#__PURE__*/React.createElement("span", {
    style: style
  }, sw);
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 'var(--space-3)',
      cursor: disabled ? 'not-allowed' : 'pointer',
      ...style
    }
  }, sw, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-base)',
      color: 'var(--text-primary)'
    }
  }, label));
}

// ===== components/core/Checkbox.jsx =====

/**
 * Checkbox — used for plan steps & task lists. Green fill + check when done.
 */
function Checkbox({
  checked = false,
  onChange,
  disabled = false,
  label,
  style = {}
}) {
  const handle = () => {
    if (!disabled && onChange) onChange(!checked);
  };
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 'var(--space-3)',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.5 : 1,
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    onClick: handle,
    role: "checkbox",
    "aria-checked": checked,
    style: {
      width: 24,
      height: 24,
      flex: 'none',
      borderRadius: 'var(--radius-sm)',
      border: `1.5px solid ${checked ? 'var(--accent)' : 'var(--field-border)'}`,
      background: checked ? 'var(--accent)' : 'var(--field-bg)',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      transition: 'all var(--duration-fast) var(--ease-out)'
    }
  }, checked && /*#__PURE__*/React.createElement(Icon, {
    name: "check",
    size: 16,
    color: "var(--accent-contrast)"
  })), label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-base)',
      color: 'var(--text-primary)',
      textDecoration: checked ? 'line-through' : 'none',
      textDecorationColor: 'var(--text-faint)'
    }
  }, label));
}

// ===== components/core/Card.jsx =====

/**
 * Card — the primary surface container. Soft radius, gentle shadow.
 * Variants: default (surface + shadow), soft (sunken, no shadow),
 * outline (border only), inverse (forest fill), accent (green tint).
 */
function Card({
  children,
  variant = 'default',
  padding = 'var(--space-5)',
  interactive = false,
  style = {},
  ...rest
}) {
  const variants = {
    default: {
      background: 'var(--surface-card)',
      border: '1px solid var(--border)',
      boxShadow: 'var(--shadow-sm)'
    },
    soft: {
      background: 'var(--surface-sunken)',
      border: '1px solid transparent'
    },
    outline: {
      background: 'transparent',
      border: '1px solid var(--border-strong)'
    },
    inverse: {
      background: 'var(--surface-inverse)',
      color: 'var(--text-on-inverse)',
      border: '1px solid transparent',
      boxShadow: 'var(--shadow-md)'
    },
    accent: {
      background: 'var(--surface-accent-soft)',
      border: '1px solid transparent'
    }
  };
  const v = variants[variant] || variants.default;
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      borderRadius: 'var(--radius-lg)',
      padding,
      transition: interactive ? 'transform var(--duration-base) var(--ease-out), box-shadow var(--duration-base) var(--ease-standard)' : 'none',
      cursor: interactive ? 'pointer' : 'default',
      ...v,
      ...style
    },
    onMouseEnter: interactive ? e => {
      e.currentTarget.style.transform = 'translateY(-2px)';
      e.currentTarget.style.boxShadow = 'var(--shadow-md)';
    } : undefined,
    onMouseLeave: interactive ? e => {
      e.currentTarget.style.transform = 'translateY(0)';
      e.currentTarget.style.boxShadow = v.boxShadow || 'none';
    } : undefined
  }, rest), children);
}

// ===== components/core/Badge.jsx =====

/**
 * Badge — small status / count pill. Tones map to semantic colors.
 */
function Badge({
  children,
  tone = 'neutral',
  icon,
  size = 'md',
  style = {}
}) {
  const tones = {
    neutral: {
      background: 'var(--surface-sunken)',
      color: 'var(--text-secondary)'
    },
    accent: {
      background: 'var(--surface-accent-soft)',
      color: 'var(--accent-press)'
    },
    success: {
      background: 'var(--success-soft)',
      color: 'var(--success)'
    },
    warning: {
      background: 'var(--warning-soft)',
      color: '#9A6A14'
    },
    danger: {
      background: 'var(--danger-soft)',
      color: 'var(--danger)'
    },
    warm: {
      background: 'var(--surface-warm-soft)',
      color: 'var(--warm-hover)'
    }
  };
  const sizes = {
    sm: {
      font: 'var(--text-2xs)',
      pad: '2px 8px',
      icon: 12
    },
    md: {
      font: 'var(--text-xs)',
      pad: '4px 10px',
      icon: 13
    }
  };
  const t = tones[tone] || tones.neutral;
  const s = sizes[size] || sizes.md;
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 'var(--space-1)',
      padding: s.pad,
      fontSize: s.font,
      fontWeight: 'var(--weight-semibold)',
      lineHeight: 1,
      whiteSpace: 'nowrap',
      borderRadius: 'var(--radius-pill)',
      ...t,
      ...style
    }
  }, icon && /*#__PURE__*/React.createElement(Icon, {
    name: icon,
    size: s.icon
  }), children);
}

// ===== components/core/Avatar.jsx =====

/**
 * Avatar — user or coach identity. Image, initials, or the CoachMe sprout.
 */
function Avatar({
  src,
  name = '',
  size = 44,
  coach = false,
  style = {}
}) {
  const initials = name.split(' ').map(p => p[0]).filter(Boolean).slice(0, 2).join('').toUpperCase();
  const base = {
    width: size,
    height: size,
    flex: 'none',
    borderRadius: 'var(--radius-circle)',
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
    fontFamily: 'var(--font-body)',
    fontWeight: 'var(--weight-semibold)',
    fontSize: size * 0.38,
    ...style
  };
  if (coach) {
    return /*#__PURE__*/React.createElement("span", {
      style: {
        ...base,
        background: 'var(--forest-800)'
      }
    }, /*#__PURE__*/React.createElement("svg", {
      viewBox: "0 0 48 48",
      width: size * 0.62,
      height: size * 0.62,
      "aria-hidden": "true"
    }, /*#__PURE__*/React.createElement("g", {
      fill: "#5FCBA3"
    }, /*#__PURE__*/React.createElement("path", {
      d: "M24 43c-.9 0-1.6-.7-1.6-1.6V22.5c0-.9.7-1.6 1.6-1.6s1.6.7 1.6 1.6v18.9c0 .9-.7 1.6-1.6 1.6z"
    }), /*#__PURE__*/React.createElement("path", {
      d: "M23 25.5c-.6-7.2-5.3-12.4-13.2-13.4-1 7.9 3.6 13.6 13.2 13.4z"
    }), /*#__PURE__*/React.createElement("path", {
      d: "M25 21.5c.6-8 6-13.8 14.7-14.9 1.1 8.8-4.1 15.1-14.7 14.9z",
      opacity: "0.78"
    }))));
  }
  if (src) {
    return /*#__PURE__*/React.createElement("img", {
      src: src,
      alt: name,
      style: {
        ...base,
        objectFit: 'cover'
      }
    });
  }
  return /*#__PURE__*/React.createElement("span", {
    style: {
      ...base,
      background: 'var(--clay-300)',
      color: 'var(--forest-900)'
    }
  }, initials || '·');
}

// ===== components/core/ProgressBar.jsx =====

/**
 * ProgressBar — calm horizontal progress for goals & plans.
 */
function ProgressBar({
  value = 0,
  max = 100,
  tone = 'accent',
  showLabel = false,
  label,
  height = 8,
  style = {}
}) {
  const pct = Math.max(0, Math.min(100, value / max * 100));
  const tones = {
    accent: 'var(--accent)',
    warm: 'var(--warm)',
    success: 'var(--success)'
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      width: '100%',
      ...style
    }
  }, (showLabel || label) && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      marginBottom: 'var(--space-2)',
      fontSize: 'var(--text-sm)',
      color: 'var(--text-secondary)'
    }
  }, /*#__PURE__*/React.createElement("span", null, label), showLabel && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-xs)',
      color: 'var(--text-muted)'
    }
  }, Math.round(pct), "%")), /*#__PURE__*/React.createElement("div", {
    style: {
      width: '100%',
      height,
      background: 'var(--surface-sunken)',
      borderRadius: 'var(--radius-pill)',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: `${pct}%`,
      height: '100%',
      background: tones[tone] || tones.accent,
      borderRadius: 'var(--radius-pill)',
      transition: 'width var(--duration-slow) var(--ease-soft)'
    }
  })));
}

// ===== components/core/SegmentedControl.jsx =====

/**
 * SegmentedControl — pill switcher for 2–4 views (e.g. Day / Week / Month).
 */
function SegmentedControl({
  options = [],
  value,
  onChange,
  style = {}
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'inline-flex',
      padding: 4,
      gap: 2,
      background: 'var(--surface-sunken)',
      borderRadius: 'var(--radius-pill)',
      border: '1px solid var(--border)',
      ...style
    }
  }, options.map(opt => {
    const val = typeof opt === 'string' ? opt : opt.value;
    const lbl = typeof opt === 'string' ? opt : opt.label;
    const active = val === value;
    return /*#__PURE__*/React.createElement("button", {
      key: val,
      type: "button",
      onClick: () => onChange && onChange(val),
      style: {
        border: 'none',
        cursor: 'pointer',
        padding: '8px 18px',
        borderRadius: 'var(--radius-pill)',
        fontFamily: 'var(--font-body)',
        fontSize: 'var(--text-sm)',
        fontWeight: 'var(--weight-semibold)',
        color: active ? 'var(--text-primary)' : 'var(--text-muted)',
        background: active ? 'var(--surface)' : 'transparent',
        boxShadow: active ? 'var(--shadow-xs)' : 'none',
        transition: 'all var(--duration-fast) var(--ease-out)'
      }
    }, lbl);
  }));
}

// ===== components/coaching/ChatBubble.jsx =====

/**
 * ChatBubble — a single turn in the coaching conversation.
 * `from="coach"` is the deep forest bubble (the AI/coach voice);
 * `from="user"` is the soft/green bubble. Coach questions can use the
 * serif voice via `serif` for reflective prompts.
 */
function ChatBubble({
  from = 'coach',
  children,
  serif = false,
  time,
  style = {}
}) {
  const isCoach = from === 'coach';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: isCoach ? 'flex-start' : 'flex-end',
      gap: 'var(--space-1)',
      maxWidth: '86%',
      alignSelf: isCoach ? 'flex-start' : 'flex-end',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '12px 16px',
      borderRadius: 'var(--radius-lg)',
      borderBottomLeftRadius: isCoach ? 'var(--radius-xs)' : 'var(--radius-lg)',
      borderBottomRightRadius: isCoach ? 'var(--radius-lg)' : 'var(--radius-xs)',
      background: isCoach ? 'var(--coach-bubble)' : 'var(--user-bubble)',
      color: isCoach ? 'var(--coach-bubble-text)' : 'var(--user-bubble-text)',
      fontFamily: serif ? 'var(--font-display)' : 'var(--font-body)',
      fontSize: serif ? 'var(--text-lg)' : 'var(--text-base)',
      lineHeight: serif ? 'var(--leading-snug)' : 'var(--leading-normal)',
      fontWeight: 'var(--weight-regular)',
      boxShadow: 'var(--shadow-xs)'
    }
  }, children), time && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-2xs)',
      color: 'var(--text-faint)',
      padding: '0 6px'
    }
  }, time));
}

// ===== components/coaching/OptionChip.jsx =====

/**
 * OptionChip — a tappable suggested reply. CoachMe offers gentle prompts
 * so users never face a blank box. Selectable (radio-like) or one-shot.
 */
function OptionChip({
  children,
  selected = false,
  onClick,
  icon,
  style = {}
}) {
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onClick,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 'var(--space-2)',
      padding: '10px 16px',
      borderRadius: 'var(--radius-pill)',
      border: `1.5px solid ${selected ? 'var(--accent)' : 'var(--border-strong)'}`,
      background: selected ? 'var(--surface-accent-soft)' : 'var(--surface)',
      color: selected ? 'var(--accent-press)' : 'var(--text-primary)',
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--text-sm)',
      fontWeight: 'var(--weight-medium)',
      whiteSpace: 'nowrap',
      cursor: 'pointer',
      transition: 'all var(--duration-fast) var(--ease-out)',
      ...style
    },
    onMouseDown: e => {
      e.currentTarget.style.transform = 'scale(0.97)';
    },
    onMouseUp: e => {
      e.currentTarget.style.transform = 'scale(1)';
    },
    onMouseLeave: e => {
      e.currentTarget.style.transform = 'scale(1)';
    }
  }, children);
}

// ===== components/coaching/GoalCard.jsx =====

/**
 * GoalCard — a single goal toward the user's Future Version.
 * Shows title, a one-line "why", progress, and a streak/cadence badge.
 */
function GoalCard({
  title,
  why,
  value = 0,
  max = 100,
  cadence,
  icon = 'target',
  tone = 'accent',
  onClick,
  style = {}
}) {
  return /*#__PURE__*/React.createElement("div", {
    onClick: onClick,
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-3)',
      padding: 'var(--space-5)',
      background: 'var(--surface-card)',
      border: '1px solid var(--border)',
      borderRadius: 'var(--radius-lg)',
      boxShadow: 'var(--shadow-sm)',
      cursor: onClick ? 'pointer' : 'default',
      transition: 'transform var(--duration-base) var(--ease-out), box-shadow var(--duration-base) var(--ease-standard)',
      ...style
    },
    onMouseEnter: onClick ? e => {
      e.currentTarget.style.transform = 'translateY(-2px)';
      e.currentTarget.style.boxShadow = 'var(--shadow-md)';
    } : undefined,
    onMouseLeave: onClick ? e => {
      e.currentTarget.style.transform = 'translateY(0)';
      e.currentTarget.style.boxShadow = 'var(--shadow-sm)';
    } : undefined
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-start',
      gap: 'var(--space-3)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 42,
      height: 42,
      flex: 'none',
      borderRadius: 'var(--radius-md)',
      background: 'var(--surface-accent-soft)',
      color: 'var(--accent-press)',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: icon,
    size: 20
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("h4", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--text-lg)',
      fontWeight: 'var(--weight-medium)',
      color: 'var(--text-primary)',
      margin: 0
    }
  }, title), why && /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--text-sm)',
      color: 'var(--text-secondary)',
      margin: '2px 0 0'
    }
  }, why)), cadence && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-2xs)',
      letterSpacing: '0.08em',
      textTransform: 'uppercase',
      color: 'var(--text-muted)',
      whiteSpace: 'nowrap'
    }
  }, cadence)), /*#__PURE__*/React.createElement(ProgressBar, {
    value: value,
    max: max,
    tone: tone,
    showLabel: true
  }));
}

// ===== components/navigation/BottomNav.jsx =====

/**
 * BottomNav — mobile tab bar. Active tab gets the green accent.
 * The center "talk to coach" action can be emphasized via `emphasis`.
 */
function BottomNav({
  items = [],
  value,
  onChange,
  style = {}
}) {
  return /*#__PURE__*/React.createElement("nav", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-around',
      gap: 'var(--space-1)',
      padding: '10px 12px calc(10px + env(safe-area-inset-bottom))',
      background: 'var(--surface)',
      borderTop: '1px solid var(--border)',
      boxShadow: 'var(--shadow-lg)',
      ...style
    }
  }, items.map(item => {
    const active = item.value === value;
    if (item.emphasis) {
      return /*#__PURE__*/React.createElement("button", {
        key: item.value,
        type: "button",
        onClick: () => onChange && onChange(item.value),
        "aria-label": item.label,
        style: {
          width: 56,
          height: 56,
          flex: 'none',
          marginTop: -22,
          borderRadius: 'var(--radius-circle)',
          border: '4px solid var(--surface)',
          background: 'var(--accent)',
          color: 'var(--accent-contrast)',
          display: 'inline-flex',
          alignItems: 'center',
          justifyContent: 'center',
          cursor: 'pointer',
          boxShadow: 'var(--shadow-md)'
        }
      }, /*#__PURE__*/React.createElement(Icon, {
        name: item.icon,
        size: 26
      }));
    }
    return /*#__PURE__*/React.createElement("button", {
      key: item.value,
      type: "button",
      onClick: () => onChange && onChange(item.value),
      style: {
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        gap: 3,
        flex: 1,
        border: 'none',
        background: 'transparent',
        cursor: 'pointer',
        color: active ? 'var(--accent-press)' : 'var(--text-faint)',
        transition: 'color var(--duration-fast) var(--ease-standard)'
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      name: item.icon,
      size: 23,
      strokeWidth: active ? 2.1 : 1.75
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 'var(--text-2xs)',
        fontWeight: active ? 'var(--weight-semibold)' : 'var(--weight-medium)'
      }
    }, item.label));
  }));
}
window.CoachMeKit = {
  Icon,
  Button,
  IconButton,
  Input,
  Textarea,
  Switch,
  Checkbox,
  Card,
  Badge,
  Avatar,
  ProgressBar,
  SegmentedControl,
  ChatBubble,
  OptionChip,
  GoalCard,
  BottomNav
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/kit-components.jsx", error: String((e && e.message) || e) }); }

// ui_kits/app/screens-main.jsx
try { (() => {
// CoachMe — main app screens: Today, Chat, Future Version, Plan, You.
const {
  Button: _B,
  IconButton: _IB,
  Icon: _Ic,
  Card: _Cd,
  Badge: _Bd,
  Avatar: _Av,
  ProgressBar: _PB,
  SegmentedControl: _SC,
  GoalCard: _GC,
  ChatBubble: _CB,
  OptionChip: _OC,
  Switch: _Sw,
  Input: _In
} = window.CoachMeKit;
const {
  Sprout: _Sp
} = window.CoachMeChrome;
const eyebrow = {
  fontFamily: 'var(--font-mono)',
  fontSize: 11,
  letterSpacing: '0.14em',
  textTransform: 'uppercase',
  color: 'var(--text-muted)',
  margin: 0
};
const sectionLabel = {
  fontFamily: 'var(--font-mono)',
  fontSize: 11,
  letterSpacing: '0.12em',
  textTransform: 'uppercase',
  color: 'var(--text-muted)',
  margin: '0 0 12px'
};
const h1 = {
  fontFamily: 'var(--font-display)',
  fontWeight: 500,
  letterSpacing: '-0.02em',
  color: 'var(--text-primary)',
  margin: 0
};
function Scroll({
  children,
  pad = 24
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflowY: 'auto',
      padding: `8px ${pad}px 24px`
    }
  }, children);
}

/* ---------------- TODAY ---------------- */
function TodayScreen({
  name = 'there',
  onTalk
}) {
  return /*#__PURE__*/React.createElement(Scroll, null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'flex-start',
      gap: 12,
      marginTop: 8
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: eyebrow
  }, "Friday \xB7 June 6"), /*#__PURE__*/React.createElement("h1", {
    style: {
      ...h1,
      fontSize: 28,
      marginTop: 6
    }
  }, "Good morning, ", name, ".")), /*#__PURE__*/React.createElement(_Av, {
    name: name,
    size: 44
  })), /*#__PURE__*/React.createElement(_Cd, {
    variant: "inverse",
    padding: "22px",
    style: {
      marginTop: 22,
      position: 'relative',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/blob-2.svg",
    "aria-hidden": "true",
    style: {
      position: 'absolute',
      top: -40,
      right: -40,
      width: 150,
      color: 'var(--forest-600)',
      opacity: 0.5
    }
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      ...eyebrow,
      color: 'var(--green-300)',
      position: 'relative'
    }
  }, "Today's reflection"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 23,
      lineHeight: 1.25,
      color: 'var(--sand-50)',
      margin: '12px 0 18px',
      position: 'relative'
    }
  }, "What would make today feel like enough?"), /*#__PURE__*/React.createElement(_B, {
    variant: "primary",
    size: "md",
    iconLeft: "message-circle",
    onClick: onTalk
  }, "Talk it through")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      margin: '26px 0 12px'
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      ...sectionLabel,
      margin: 0
    }
  }, "Your momentum"), /*#__PURE__*/React.createElement(_Bd, {
    tone: "warm",
    icon: "flame"
  }, "7-day streak")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(_GC, {
    title: "Move my body daily",
    why: "So I feel clear-headed",
    value: 4,
    max: 7,
    cadence: "DAILY",
    icon: "footprints"
  }), /*#__PURE__*/React.createElement(_GC, {
    title: "Finish the first draft",
    why: "The book I keep talking about",
    value: 2,
    max: 10,
    cadence: "3\xD7/WK",
    icon: "pen-line",
    tone: "warm"
  })), /*#__PURE__*/React.createElement(_Cd, {
    variant: "soft",
    padding: "16px",
    style: {
      marginTop: 16,
      display: 'flex',
      gap: 12,
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 40,
      height: 40,
      borderRadius: 12,
      background: 'var(--surface-accent-soft)',
      color: 'var(--accent-press)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      flex: 'none'
    }
  }, /*#__PURE__*/React.createElement(_Ic, {
    name: "sparkles",
    size: 20
  })), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 14,
      color: 'var(--text-secondary)',
      margin: 0,
      lineHeight: 1.45
    }
  }, "You've kept your morning walk 4 days running. ", /*#__PURE__*/React.createElement("strong", {
    style: {
      color: 'var(--text-primary)'
    }
  }, "That's how futures get built."))));
}

/* ---------------- CHAT ---------------- */
function ChatScreen() {
  const [msgs, setMsgs] = React.useState([{
    from: 'coach',
    serif: true,
    text: 'Good to see you. What would make this week feel like a win for you?',
    time: '9:24'
  }, {
    from: 'user',
    text: "Honestly? Just finishing one thing I keep putting off.",
    time: '9:25'
  }, {
    from: 'coach',
    text: "That counts for a lot. What's the one thing — and what would the smallest first step look like?",
    time: '9:25'
  }]);
  const opts = ['The draft I keep avoiding', 'A hard conversation', 'Just 10 focused minutes'];
  const scroller = React.useRef(null);
  React.useEffect(() => {
    if (scroller.current) scroller.current.scrollTop = scroller.current.scrollHeight;
  }, [msgs]);
  const send = text => {
    setMsgs(m => [...m, {
      from: 'user',
      text,
      time: '9:26'
    }]);
    setTimeout(() => setMsgs(m => [...m, {
      from: 'coach',
      serif: true,
      text: 'Beautiful. Ten honest minutes is a promise you can keep. When today will you take them?',
      time: '9:26'
    }]), 650);
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      height: '100%'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      padding: '6px 20px 14px',
      borderBottom: '1px solid var(--divider)'
    }
  }, /*#__PURE__*/React.createElement(_Av, {
    coach: true,
    size: 40
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      fontWeight: 700,
      fontSize: 15,
      margin: 0,
      color: 'var(--text-primary)'
    }
  }, "Your coach"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 12,
      color: 'var(--success)',
      margin: 0,
      display: 'flex',
      alignItems: 'center',
      gap: 5
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 7,
      height: 7,
      borderRadius: 999,
      background: 'var(--success)'
    }
  }), "Listening")), /*#__PURE__*/React.createElement(_IB, {
    icon: "more-horizontal",
    variant: "ghost",
    label: "More"
  })), /*#__PURE__*/React.createElement("div", {
    ref: scroller,
    style: {
      flex: 1,
      overflowY: 'auto',
      padding: '18px 20px',
      display: 'flex',
      flexDirection: 'column',
      gap: 12
    }
  }, msgs.map((m, i) => /*#__PURE__*/React.createElement(_CB, {
    key: i,
    from: m.from,
    serif: m.serif,
    time: m.time
  }, m.text))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '0 16px 8px',
      display: 'flex',
      gap: 8,
      flexWrap: 'wrap'
    }
  }, opts.map(o => /*#__PURE__*/React.createElement(_OC, {
    key: o,
    onClick: () => send(o)
  }, o))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      padding: '10px 16px calc(14px + env(safe-area-inset-bottom))',
      borderTop: '1px solid var(--divider)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      display: 'flex',
      alignItems: 'center',
      background: 'var(--field-bg)',
      border: '1.5px solid var(--field-border)',
      borderRadius: 999,
      padding: '0 8px 0 16px',
      height: 46
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      color: 'var(--field-placeholder)',
      fontSize: 15
    }
  }, "Share what's on your mind\u2026"), /*#__PURE__*/React.createElement(_IB, {
    icon: "mic",
    variant: "ghost",
    size: "sm",
    label: "Voice"
  })), /*#__PURE__*/React.createElement(_IB, {
    icon: "arrow-up",
    variant: "solid",
    label: "Send",
    onClick: () => send('Right after lunch.')
  })));
}

/* ---------------- FUTURE VERSION ---------------- */
function FutureVersionScreen() {
  const values = ['Calm mornings', 'Finished work', 'Time outdoors', 'Present with people', 'A clear head'];
  return /*#__PURE__*/React.createElement(Scroll, null, /*#__PURE__*/React.createElement("p", {
    style: {
      ...eyebrow,
      marginTop: 8
    }
  }, "Who you're becoming"), /*#__PURE__*/React.createElement("h1", {
    style: {
      ...h1,
      fontSize: 28,
      marginTop: 6
    }
  }, "Your Future Version"), /*#__PURE__*/React.createElement(_Cd, {
    variant: "default",
    padding: "22px",
    style: {
      marginTop: 18,
      position: 'relative',
      overflow: 'hidden',
      borderColor: 'var(--green-300)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      marginBottom: 12
    }
  }, /*#__PURE__*/React.createElement(_Sp, {
    size: 30
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 11,
      letterSpacing: '0.1em',
      textTransform: 'uppercase',
      color: 'var(--text-muted)'
    }
  }, "Six months from now")), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 21,
      lineHeight: 1.4,
      color: 'var(--text-primary)',
      margin: 0
    }
  }, "\"I wake up unhurried and clear. The draft is done \u2014 not perfect, but mine. I move every day, and I'm actually ", /*#__PURE__*/React.createElement("em", {
    style: {
      color: 'var(--accent-press)',
      fontStyle: 'italic'
    }
  }, "there"), " for the people I love.\"")), /*#__PURE__*/React.createElement("p", {
    style: {
      ...sectionLabel,
      marginTop: 26
    }
  }, "What matters to this version of you"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: 8
    }
  }, values.map(v => /*#__PURE__*/React.createElement(_Bd, {
    key: v,
    tone: "accent",
    size: "md"
  }, v))), /*#__PURE__*/React.createElement("p", {
    style: {
      ...sectionLabel,
      marginTop: 26
    }
  }, "The plan that gets you there"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(_GC, {
    title: "Move my body daily",
    why: "Calm, clear mornings",
    value: 4,
    max: 7,
    cadence: "DAILY",
    icon: "footprints"
  }), /*#__PURE__*/React.createElement(_GC, {
    title: "Finish the first draft",
    why: "Finished work, off my mind",
    value: 2,
    max: 10,
    cadence: "3\xD7/WK",
    icon: "pen-line",
    tone: "warm"
  })));
}

/* ---------------- PLAN ---------------- */
function PlanScreen() {
  const [range, setRange] = React.useState('This week');
  return /*#__PURE__*/React.createElement(Scroll, null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginTop: 8
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      ...h1,
      fontSize: 28
    }
  }, "Your plan"), /*#__PURE__*/React.createElement(_IB, {
    icon: "plus",
    variant: "solid",
    label: "Add goal"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      margin: '16px 0 18px'
    }
  }, /*#__PURE__*/React.createElement(_SC, {
    options: ['This week', 'All goals'],
    value: range,
    onChange: setRange
  })), /*#__PURE__*/React.createElement(_Cd, {
    variant: "accent",
    padding: "18px",
    style: {
      marginBottom: 16
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      ...eyebrow,
      color: 'var(--accent-press)'
    }
  }, "This week"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 20,
      color: 'var(--text-primary)',
      margin: '8px 0 12px'
    }
  }, "6 of 12 steps, on track."), /*#__PURE__*/React.createElement(_PB, {
    value: 6,
    max: 12,
    showLabel: true
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(_GC, {
    title: "Move my body daily",
    why: "So I feel clear-headed",
    value: 4,
    max: 7,
    cadence: "DAILY",
    icon: "footprints"
  }), /*#__PURE__*/React.createElement(_GC, {
    title: "Finish the first draft",
    why: "The book I keep talking about",
    value: 2,
    max: 10,
    cadence: "3\xD7/WK",
    icon: "pen-line",
    tone: "warm"
  }), /*#__PURE__*/React.createElement(_GC, {
    title: "Protect my evenings",
    why: "Be present with people I love",
    value: 5,
    max: 7,
    cadence: "DAILY",
    icon: "moon",
    tone: "success"
  })));
}

/* ---------------- YOU ---------------- */
function YouScreen({
  name = 'there'
}) {
  const [reminders, setReminders] = React.useState(true);
  const [dark, setDark] = React.useState(false);
  React.useEffect(() => {
    if (window.__setKitTheme) window.__setKitTheme(dark ? 'dark' : 'light');
  }, [dark]);
  return /*#__PURE__*/React.createElement(Scroll, null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 14,
      marginTop: 14
    }
  }, /*#__PURE__*/React.createElement(_Av, {
    name: name,
    size: 60
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h1", {
    style: {
      ...h1,
      fontSize: 24
    }
  }, name), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 13,
      color: 'var(--text-muted)',
      margin: '2px 0 0'
    }
  }, "Day 7 with CoachMe"))), /*#__PURE__*/React.createElement("p", {
    style: {
      ...sectionLabel,
      marginTop: 26
    }
  }, "Preferences"), /*#__PURE__*/React.createElement(_Cd, {
    variant: "default",
    padding: "4px 18px"
  }, /*#__PURE__*/React.createElement(Setting, {
    label: "Daily check-in reminder",
    right: /*#__PURE__*/React.createElement(_Sw, {
      checked: reminders,
      onChange: setReminders
    })
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      height: 1,
      background: 'var(--divider)'
    }
  }), /*#__PURE__*/React.createElement(Setting, {
    label: "Dark theme",
    right: /*#__PURE__*/React.createElement(_Sw, {
      checked: dark,
      onChange: setDark
    })
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      height: 1,
      background: 'var(--divider)'
    }
  }), /*#__PURE__*/React.createElement(Setting, {
    label: "Coaching style",
    right: /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 14,
        color: 'var(--text-muted)'
      }
    }, "Gently \u203A")
  })), /*#__PURE__*/React.createElement("p", {
    style: {
      ...sectionLabel,
      marginTop: 26
    }
  }, "Your journey"), /*#__PURE__*/React.createElement(_Cd, {
    variant: "soft",
    padding: "18px",
    style: {
      display: 'flex',
      gap: 18
    }
  }, /*#__PURE__*/React.createElement(Stat, {
    n: "23",
    l: "Sessions"
  }), /*#__PURE__*/React.createElement(Stat, {
    n: "7",
    l: "Day streak"
  }), /*#__PURE__*/React.createElement(Stat, {
    n: "48",
    l: "Journal notes"
  })));
}
function Setting({
  label,
  right
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '16px 0'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 15,
      color: 'var(--text-primary)'
    }
  }, label), right);
}
function Stat({
  n,
  l
}) {
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: 26,
      color: 'var(--text-primary)',
      margin: 0
    }
  }, n), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 12,
      color: 'var(--text-muted)',
      margin: 0
    }
  }, l));
}
window.CoachMeScreens = {
  TodayScreen,
  ChatScreen,
  FutureVersionScreen,
  PlanScreen,
  YouScreen
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/screens-main.jsx", error: String((e && e.message) || e) }); }

// ui_kits/app/screens-onboarding.jsx
try { (() => {
// CoachMe — Onboarding / intake flow (deep forest, focused).
const {
  Button: _OB,
  Input: _OI,
  Textarea: _OT,
  OptionChip: _OOC,
  IconButton: _OIB,
  Icon: _OIcon
} = window.CoachMeKit;
const {
  StatusBar: _OSB,
  Sprout: _OSprout
} = window.CoachMeChrome;
function OnboardingFlow({
  onComplete
}) {
  const [step, setStep] = React.useState(0);
  const [name, setName] = React.useState('');
  const [focus, setFocus] = React.useState([]);
  const [vision, setVision] = React.useState('');
  const [style, setStyle] = React.useState('Gently — ask me questions');
  const toggle = v => setFocus(f => f.includes(v) ? f.filter(x => x !== v) : [...f, v]);
  const total = 4;
  const next = () => step < total - 1 ? setStep(step + 1) : onComplete && onComplete({
    name
  });
  const back = () => setStep(Math.max(0, step - 1));
  const focusOpts = ['Build a habit', 'Make a big decision', 'Find more focus', 'Feel less stuck', 'Grow my career', 'Take better care of myself'];
  const styleOpts = ['Gently — ask me questions', 'Directly — keep me accountable', 'A wise, calm mentor', 'An upbeat companion'];
  const eyebrow = {
    fontFamily: 'var(--font-mono)',
    fontSize: 11,
    letterSpacing: '0.14em',
    textTransform: 'uppercase',
    color: 'var(--green-300)'
  };
  const question = {
    fontFamily: 'var(--font-display)',
    fontSize: 30,
    lineHeight: 1.12,
    letterSpacing: '-0.02em',
    color: 'var(--sand-50)',
    margin: '14px 0 0',
    fontWeight: 500
  };
  const help = {
    fontSize: 14,
    color: 'var(--forest-200)',
    margin: '10px 0 0',
    lineHeight: 1.5
  };
  return /*#__PURE__*/React.createElement("div", {
    "data-theme": "dark",
    style: {
      position: 'relative',
      width: '100%',
      height: '100%',
      background: 'var(--forest-900)',
      display: 'flex',
      flexDirection: 'column',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/blob-1.svg",
    "aria-hidden": "true",
    style: {
      position: 'absolute',
      top: -100,
      right: -90,
      width: 300,
      color: 'var(--forest-700)',
      opacity: 0.6,
      zIndex: 0
    }
  }), /*#__PURE__*/React.createElement(StatusBarDark, null), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      padding: '4px 24px 0',
      zIndex: 1
    }
  }, /*#__PURE__*/React.createElement(_OIB, {
    icon: "arrow-left",
    variant: "ghost",
    size: "sm",
    label: "Back",
    onClick: back,
    style: {
      color: 'var(--sand-50)',
      opacity: step === 0 ? 0.35 : 1
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      height: 5,
      background: 'rgba(231,224,208,0.16)',
      borderRadius: 999,
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: `${(step + 1) / total * 100}%`,
      height: '100%',
      background: 'var(--green-400)',
      borderRadius: 999,
      transition: 'width 420ms cubic-bezier(0.32,0.72,0,1)'
    }
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 11,
      color: 'var(--forest-200)'
    }
  }, step + 1, "/", total)), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      padding: '24px 24px 0',
      overflowY: 'auto',
      zIndex: 1
    }
  }, step === 0 && /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(_OSprout, {
    size: 52,
    fill: "var(--green-400)"
  }), /*#__PURE__*/React.createElement("p", {
    style: eyebrow
  }, "Welcome to CoachMe"), /*#__PURE__*/React.createElement("h1", {
    style: question
  }, "First \u2014 what should your coach call you?"), /*#__PURE__*/React.createElement("p", {
    style: help
  }, "No accounts, no pressure. Just a name to make this feel like yours."), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 22
    }
  }, /*#__PURE__*/React.createElement(_OI, {
    placeholder: "Your name",
    value: name,
    onChange: e => setName(e.target.value),
    iconLeft: "user"
  }))), step === 1 && /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("p", {
    style: eyebrow
  }, "A little context"), /*#__PURE__*/React.createElement("h1", {
    style: question
  }, "What brings you here right now?"), /*#__PURE__*/React.createElement("p", {
    style: help
  }, "Pick anything that fits \u2014 you can change course anytime."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: 10,
      marginTop: 22
    }
  }, focusOpts.map(o => /*#__PURE__*/React.createElement(_OOC, {
    key: o,
    selected: focus.includes(o),
    onClick: () => toggle(o)
  }, o)))), step === 2 && /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("p", {
    style: eyebrow
  }, "The seed of your Future Version"), /*#__PURE__*/React.createElement("h1", {
    style: question
  }, "Picture six months from now. What feels different?"), /*#__PURE__*/React.createElement("p", {
    style: help
  }, "A sentence is plenty. We'll shape it together later."), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 20
    }
  }, /*#__PURE__*/React.createElement(_OT, {
    rows: 4,
    placeholder: "I wake up clearer, I've kept a promise to myself, I\u2026",
    value: vision,
    onChange: e => setVision(e.target.value)
  }))), step === 3 && /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("p", {
    style: eyebrow
  }, "How we'll talk"), /*#__PURE__*/React.createElement("h1", {
    style: question
  }, "How do you like to be coached?"), /*#__PURE__*/React.createElement("p", {
    style: help
  }, "This sets the tone of every conversation."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 10,
      marginTop: 22
    }
  }, styleOpts.map(o => /*#__PURE__*/React.createElement(_OOC, {
    key: o,
    selected: style === o,
    onClick: () => setStyle(o),
    style: {
      width: '100%',
      justifyContent: 'flex-start'
    }
  }, o))))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '16px 24px calc(20px + env(safe-area-inset-bottom))',
      zIndex: 1
    }
  }, /*#__PURE__*/React.createElement(_OB, {
    variant: "primary",
    size: "lg",
    fullWidth: true,
    iconRight: "arrow-right",
    onClick: next,
    disabled: step === 0 && !name.trim()
  }, step === total - 1 ? 'Meet your coach' : 'Continue')));
}
function StatusBarDark() {
  return /*#__PURE__*/React.createElement(_OSB, {
    dark: true
  });
}
window.CoachMeOnboarding = {
  OnboardingFlow
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/screens-onboarding.jsx", error: String((e && e.message) || e) }); }

__ds_ns.ChatBubble = __ds_scope.ChatBubble;

__ds_ns.GoalCard = __ds_scope.GoalCard;

__ds_ns.OptionChip = __ds_scope.OptionChip;

__ds_ns.Avatar = __ds_scope.Avatar;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.Icon = __ds_scope.Icon;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.ProgressBar = __ds_scope.ProgressBar;

__ds_ns.SegmentedControl = __ds_scope.SegmentedControl;

__ds_ns.Switch = __ds_scope.Switch;

__ds_ns.Textarea = __ds_scope.Textarea;

__ds_ns.BottomNav = __ds_scope.BottomNav;

})();
