# Flipkart Merch Design System

A design system for **Flipkart merchandising** — the library that merch & creative teams use
to assemble Category Landing Page (CLP) widgets, promotional banners and sale creatives across
Flipkart's family of brands. It is a *placement & creative* system: standardized widget frames,
image-slot grids, section headers and a deep multi-brand / multi-language / multi-sale token set,
rather than a transactional product UI.

> **Source:** Reconstructed from the Figma file **"Merch Design Systems.fig"** (mounted read-only).
> Top-level pages: Cover, Roadmap, Guidelines, Widgets, Typography, Colour-System, Componets.
> 441 Figma Variables, 142 local components, ~3000 nodes. If you have the original file, it is the
> source of truth for anything not captured here.

---

## Products / brands represented

The token system carries **8 brand modes** and many seasonal sale themes. Each re-points the same
semantic variables (`--brand-primary`, `--background-bold-brand-primary-group`, …):

| Brand | Primary | Secondary | Notes |
|-------|---------|-----------|-------|
| **Flipkart** (default) | Blue `#1967F2` | Yellow `#FFDA33` | The flagship marketplace |
| **Minutes** | Magenta `#C70255` | Yellow `#FFDA33` | Quick-commerce (10-min delivery) |
| **Kilos** | Yellow/Gold | Yellow | Grocery |
| **Spoyl** | Neon green | Yellow | Gen-Z fashion |
| **Shopsy** | Aqua | Yellow | Value/social commerce |
| **Brand Mall**, **Travel**, **Pay** | Blue | — | Sub-surfaces, blue-led |

Plus theme modes: **Big Billion Day, RD Sale, Valentines, March BSD, Festivals of India, Template**
(each sets `--dark-colour1..3` / `--light-colour1..3`), a **Dark** theme, **Sharp/Curv** radius modes,
and **12 Indian-language** font modes (English, Hindi, Bengali, Tamil, Telugu, Kannada, Malayalam,
Marathi, Gujarati, Punjabi, Odia, Assamese).

The constant across every brand is the **Flipkart yellow `#FFDA33`** secondary.

---

## What this system is for

Merchandisers drop product/lifestyle imagery into **standardized image-slot widgets** and add a
**section header** ("Trending now"). The widgets enforce correct aspect ratios, spacing and corner
radii so every CLP looks consistent. Core widget families (all in the Figma "Widgets" page):

- **clp-2-grid / 3-grid / 4-grid** — fixed product grids
- **clp-flex** — mixed-size flexible grid
- **clp-hpw** — horizontal product widget (scrollable rail)
- **clp-scroll-jacket / no-jacket** — scrollable rails, with or without a colored container ("jacket")

Each widget = optional `section-header` + one or more **image placeholder slots** (light-blue
`#CFEBFE` rounded rectangles, radius 12) + an optional scroll progress indicator.

---

## CONTENT FUNDAMENTALS

**Voice.** Short, punchy, retail-merchandising copy. Benefit- and price-led. It speaks *to* the
shopper ("you") and *about* the product, never in the first person.

- **Section headers** are 2–4 word hooks, sentence case: *"Trending now"*, *"Latest trends around you"*.
- **Product names** are literal and specific: *"Sony A7M4 Mirrorless"*.
- **Feature lines** are spec fragments, no end punctuation: *"120 fps + 8K video recording"*,
  *"24.2MP full-frame camera"*.
- **Price callouts** use the rupee glyph and Indian grouping: *"From ₹57,999"*, *"Incl. of all offers"*.
- **Casing:** sentence case for headers & body; product names keep their brand capitalization.
  Reserve ALL-CAPS for tiny mono spec labels only.
- **Numerals are heroes.** Prices, percentages, fps, MP and "From ₹…" are set large and bold —
  the design literally renders giant numbers (120px Fields Display) as focal points.
- **No emoji.** None appear in the system. Use real iconography or imagery instead.
- **Tone:** confident, energetic, value-forward. Indian e-commerce idiom ("Incl. of all offers",
  "Big Billion Days"). Avoid fluff, filler adjectives or exclamation spam.

---

## VISUAL FOUNDATIONS

**Colour.** A very large primitive palette (aqua, blue, brown, gold, green, magenta, neon, orange,
pesto, pink, purple, red, silver, teal, ultramarine, violet, yellow — each 50→950) plus exhaustive
neutrals (light/dark × solid/opaque, 00→1000). Brands draw a *core pair* (primary + the constant
yellow). Surfaces are overwhelmingly **white / near-white** in product context; the *system docs*
themselves use saturated brand backgrounds (deep violet `#381980`, magenta `#88004C`). Imagery
slots default to **light-blue / light-pink wash** behind the product cut-out.

**Typography.** Four families:
- **Fields Display** *(proprietary — substituted with Bricolage Grotesque)* — display headlines &
  hero numbers: 120px / 48px / 20px, bold, near-0.9 line-height, tight tracking.
- **Inter** — the UI workhorse: section headers 17px/700, product names 14px/700, body 14px/400,
  feature captions 11px/400. Tracking ~0.
- **New SEC APP** *(proprietary — substituted with Inter Light 300)* — long descriptions, 14px, 1.4.
- **IBM Plex Mono** — tiny spec / dimension labels (8px), e.g. "180x256(1×) | 720x1024(4×)".

**Spacing.** Even scale: 2 / 4 / 6 / 8 / 12 / 16 / 20 / 24 / 32 / 40 / 48 / 56 / 64. Widget internal
padding is **16px**, gap between cards **12px**.

**Corner radii.** 2 → 32 ladder. Product cards / image slots = **12** (`--radius-md`). Panel/specimen
cards = **24**. Widget jacket containers = **32**. A global **Sharp** mode flattens everything to 0.

**Backgrounds.** Product widgets sit on flat white. Brand creatives use flat brand-color fills or a
subtle two-stop gradient (the cover is a blue radial→linear wash). Image slots use a flat light-blue
fill behind a `center / contain` product cut-out — **not** photographic full-bleed by default.

**Borders & dividers.** Hairlines: `1px #EEE`–`#E0E0E0` on light; on dark/brand surfaces a
**0.5px inset white @ 10%** hairline. Spec/annotation outlines use 1px dashed `#9747FF` (Figma
slice markers — not for production).

**Shadows.** Soft and low. Cards: `0 2px 6px rgba(0,0,0,.09)` / `0 6px 16px rgba(0,0,0,.10)`.
Floating product cut-outs on brand backgrounds use a deeper `0 6px 16px rgba(0,0,0,.5)`.

**Imagery vibe.** Clean studio product cut-outs on light wash, or lifestyle photography filling a
slot. Bright, high-key, color-forward — never moody, never b&w, no heavy grain. The product is hero;
background is a flat brand tint.

**Protection / scrims.** When text overlays imagery, a bottom-up black gradient scrim
(`rgba(0,0,0,0)→0.55`) protects legibility rather than a solid capsule.

**Motion.** Static-creative system; the only implied motion is **horizontal scroll** of product rails
(with a thin progress bar / page-dot indicator at the bottom). Keep transitions quick and functional —
ease-out fades and slides, no bounce, no decorative looping. Respect `prefers-reduced-motion`.

**Hover / press (for interactive recreations).** Hover = slight lift / 4–8% darken of brand fills;
press = scale to ~0.98 and a touch darker. Hit targets ≥ 44px on mobile surfaces.

---

## ICONOGRAPHY

The Figma file is **light on icons** — it is a creative/placement system, not an app UI. The one
recurring control is a **chevron/arrow "next" button**: a blue (`#1152E0`) pill, radius 30, with a
white chevron — used to advance scrollable product rails. Bottom-of-rail progress is shown as a
**scroll indicator bar / page dots**, not numeric pagination.

- **No icon font or sprite** ships in the file. **No emoji, no unicode glyphs** used as icons.
- Keyboard glyphs (⌘, ⇧) appear only inside the "how to replace placeholder" instruction art.
- For interactive recreations needing UI icons, substitute **Lucide** (CDN) at a 1.5–2px stroke to
  match the clean, geometric feel. *(Flagged substitution — swap for Flipkart's real icon set if
  provided.)*

See `assets/` for the placeholder-slot reference graphic. Brand wordmarks were not embedded as
standalone assets in the file; the brand swatches in `Colour-System/Brands` define the brand colors.

---

## FONT SUBSTITUTIONS (action needed)

| Design font | Role | Substituted with | Status |
|-------------|------|------------------|--------|
| **Fields Display** | Display headlines, hero numbers | **Bricolage Grotesque** (Google) | ⚠️ proprietary — please provide `.woff2` |
| **New SEC APP** | Light app body / descriptions | **Inter Light 300** | ⚠️ proprietary — please provide `.woff2` |
| Inter, IBM Plex Mono | UI / mono | *same (Google)* | ✅ authentic |
| Noto Sans (Bengali/Kannada/Malayalam/Telugu), Mukta family | Indian-language modes | *same (Google)* | ✅ authentic |

Drop real files into `assets/fonts/` and update the `@font-face` / alias in `tokens/fonts.css`.

---

## INDEX / MANIFEST

**Root**
- `styles.css` — global CSS entry (import this). `@import`s everything below.
- `readme.md` — this guide.
- `SKILL.md` — Agent-Skills front-matter for portable use.

**Tokens** (`tokens/`)
- `fonts.css` — webfont imports + display-font alias.
- `colors.css` — brand cores, surfaces, text, placeholder & status aliases + `data-brand` scopes.
- `typography.css` — type ramp tokens + `.fk-*` specimen helper classes.
- `spacing.css` — spacing / radius / elevation aliases.
- `figma/fig-tokens.css` — full 441-variable Figma palette + brand/lang/sale/theme modes.
- `figma/fig-typography.css` — (empty; no text styles exported).

**Components** (`components/`) — reusable React primitives. Card thumbnails in each directory.
- `core/` — **Button** (brand CTA), **Badge** (offer chip), **ChevronButton** (carousel arrow).
- `widgets/` — **SectionHeader** ("Trending now"), **ImageSlot** (fillable placeholder),
  **ProductCard** (image + name + price + feature), **ScrollIndicator** (rail progress),
  **CLPWidget** (full header + grid/scroll widget, with brand jacket).

**UI kits** (`ui_kits/`)
- `clp/` — interactive mobile **Category Landing Page**: brand switcher, scroll rails, tap-to-cart.

**Guidelines** (`guidelines/`) — foundation specimen cards (Type ×3, Colors ×6, Spacing ×3, Brand ×2).

**Assets** (`assets/`) — `imagery/placeholder-slot.png` (the "Replace this" slot reference).
