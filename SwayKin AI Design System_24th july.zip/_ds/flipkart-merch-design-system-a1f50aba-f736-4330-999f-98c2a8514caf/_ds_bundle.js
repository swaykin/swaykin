/* @ds-bundle: {"format":3,"namespace":"FlipkartMerchDesignSystem_a1f50a","components":[{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"ChevronButton","sourcePath":"components/core/ChevronButton.jsx"},{"name":"CLPWidget","sourcePath":"components/widgets/CLPWidget.jsx"},{"name":"ImageSlot","sourcePath":"components/widgets/ImageSlot.jsx"},{"name":"ProductCard","sourcePath":"components/widgets/ProductCard.jsx"},{"name":"ScrollIndicator","sourcePath":"components/widgets/ScrollIndicator.jsx"},{"name":"SectionHeader","sourcePath":"components/widgets/SectionHeader.jsx"}],"sourceHashes":{"components/core/Badge.jsx":"7843801daaf5","components/core/Button.jsx":"1b648d8e5fbc","components/core/ChevronButton.jsx":"ad3f6efb913a","components/widgets/CLPWidget.jsx":"e1c161b2f47a","components/widgets/ImageSlot.jsx":"f0f40ba8558e","components/widgets/ProductCard.jsx":"d9f9ba39cc25","components/widgets/ScrollIndicator.jsx":"e0780e08b6d5","components/widgets/SectionHeader.jsx":"bc0345122b35","ui_kits/clp/AppBar.jsx":"8d7966252369","ui_kits/clp/BottomNav.jsx":"743a23ee6548","ui_kits/clp/CategoryChips.jsx":"1398a92c68e4","ui_kits/clp/HeroBanner.jsx":"7b48f356691a"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.FlipkartMerchDesignSystem_a1f50a = window.FlipkartMerchDesignSystem_a1f50a || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Badge({
  children,
  tone = "brand",
  // brand | yellow | success | error | neutral | dark
  size = "md",
  // sm | md
  style = {},
  ...rest
}) {
  const tones = {
    brand: {
      background: "var(--brand-primary)",
      color: "#fff"
    },
    yellow: {
      background: "var(--brand-yellow)",
      color: "var(--text-strong)"
    },
    success: {
      background: "var(--status-success)",
      color: "#fff"
    },
    error: {
      background: "var(--status-error)",
      color: "#fff"
    },
    neutral: {
      background: "var(--neutral-light-solid-100)",
      color: "var(--text-default)"
    },
    dark: {
      background: "var(--surface-dark)",
      color: "#fff"
    }
  };
  const t = tones[tone] || tones.brand;
  const sz = size === "sm" ? {
    fontSize: 10,
    padding: "3px 7px"
  } : {
    fontSize: 12,
    padding: "4px 10px"
  };
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 4,
      fontFamily: "var(--font-ui)",
      fontWeight: 700,
      lineHeight: 1,
      borderRadius: "var(--radius-xs)",
      letterSpacing: "0.01em",
      ...sz,
      ...t,
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Button({
  children,
  variant = "primary",
  // primary | secondary | outline | ghost
  size = "md",
  // sm | md | lg
  brand,
  // optional: flipkart | minutes | kilos | spoyl | shopsy
  fullWidth = false,
  disabled = false,
  onClick,
  style = {},
  ...rest
}) {
  const sizes = {
    sm: {
      padding: "6px 14px",
      fontSize: 12,
      height: 32,
      radius: "var(--radius-sm)"
    },
    md: {
      padding: "9px 20px",
      fontSize: 14,
      height: 40,
      radius: "var(--radius-md)"
    },
    lg: {
      padding: "13px 28px",
      fontSize: 16,
      height: 52,
      radius: "var(--radius-lg)"
    }
  };
  const s = sizes[size] || sizes.md;
  const palettes = {
    primary: {
      background: "var(--brand-primary)",
      color: "#fff",
      border: "1px solid transparent"
    },
    secondary: {
      background: "var(--brand-secondary)",
      color: "var(--text-strong)",
      border: "1px solid transparent"
    },
    outline: {
      background: "transparent",
      color: "var(--brand-primary)",
      border: "1.5px solid var(--brand-primary)"
    },
    ghost: {
      background: "transparent",
      color: "var(--brand-primary)",
      border: "1px solid transparent"
    }
  };
  const p = palettes[variant] || palettes.primary;
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    onClick: disabled ? undefined : onClick,
    disabled: disabled,
    "data-brand": brand,
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      gap: 8,
      fontFamily: "var(--font-ui)",
      fontWeight: 700,
      fontSize: s.fontSize,
      lineHeight: 1,
      height: s.height,
      padding: s.padding,
      borderRadius: s.radius,
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? 0.45 : 1,
      width: fullWidth ? "100%" : "auto",
      transition: "filter .15s ease, transform .08s ease",
      ...p,
      ...style
    },
    onMouseEnter: e => !disabled && (e.currentTarget.style.filter = "brightness(0.93)"),
    onMouseLeave: e => e.currentTarget.style.filter = "none",
    onMouseDown: e => !disabled && (e.currentTarget.style.transform = "scale(0.97)"),
    onMouseUp: e => e.currentTarget.style.transform = "scale(1)"
  }, rest), children);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/ChevronButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function ChevronButton({
  direction = "right",
  // left | right
  size = "md",
  // sm | md | lg
  disabled = false,
  onClick,
  ariaLabel,
  style = {},
  ...rest
}) {
  const sizes = {
    sm: 28,
    md: 36,
    lg: 44
  };
  const d = sizes[size] || sizes.md;
  const icon = d * 0.42;
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    "aria-label": ariaLabel || (direction === "left" ? "Previous" : "Next"),
    onClick: disabled ? undefined : onClick,
    disabled: disabled,
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      width: d,
      height: d,
      borderRadius: "var(--radius-pill)",
      border: "none",
      background: "var(--blue-700)",
      color: "#fff",
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? 0.4 : 1,
      boxShadow: "var(--shadow-sm)",
      transition: "filter .15s ease, transform .08s ease",
      ...style
    },
    onMouseEnter: e => !disabled && (e.currentTarget.style.filter = "brightness(1.08)"),
    onMouseLeave: e => e.currentTarget.style.filter = "none",
    onMouseDown: e => !disabled && (e.currentTarget.style.transform = "scale(0.92)"),
    onMouseUp: e => e.currentTarget.style.transform = "scale(1)"
  }, rest), /*#__PURE__*/React.createElement("svg", {
    width: icon,
    height: icon,
    viewBox: "0 0 24 24",
    fill: "none",
    style: {
      transform: direction === "left" ? "rotate(180deg)" : "none"
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M9 6l6 6-6 6",
    stroke: "currentColor",
    strokeWidth: "2.5",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  })));
}
Object.assign(__ds_scope, { ChevronButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/ChevronButton.jsx", error: String((e && e.message) || e) }); }

// components/widgets/ImageSlot.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function ImageSlot({
  src,
  // image URL; when omitted shows the empty wash
  alt = "",
  ratio = "158 / 225",
  // aspect-ratio string, e.g. "1 / 1", "158 / 225"
  wash = "blue",
  // blue | blue-2 | pink
  radius = "var(--radius-md)",
  fit = "cover",
  // cover | contain
  children,
  // overlay content (badges, captions)
  style = {},
  ...rest
}) {
  const washes = {
    blue: "var(--placeholder-blue)",
    "blue-2": "var(--placeholder-blue-2)",
    pink: "var(--placeholder-pink)"
  };
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      position: "relative",
      aspectRatio: ratio,
      borderRadius: radius,
      overflow: "hidden",
      background: washes[wash] || washes.blue,
      ...style
    }
  }, rest), src ? /*#__PURE__*/React.createElement("img", {
    src: src,
    alt: alt,
    style: {
      width: "100%",
      height: "100%",
      objectFit: fit,
      display: "block"
    }
  }) : /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      fontFamily: "var(--font-mono)",
      fontSize: 11,
      fontWeight: 600,
      color: "var(--placeholder-text)"
    }
  }, "Replace this"), children);
}
Object.assign(__ds_scope, { ImageSlot });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/widgets/ImageSlot.jsx", error: String((e && e.message) || e) }); }

// components/widgets/ProductCard.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function ProductCard({
  src,
  alt = "",
  name,
  // product name (Inter 14/700)
  price,
  // e.g. "From ₹57,999"
  feature,
  // e.g. "120 fps + 8K video recording"
  badge,
  // optional offer string -> error Badge
  ratio = "158 / 225",
  wash = "blue",
  onClick,
  style = {},
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    onClick: onClick,
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 6,
      cursor: onClick ? "pointer" : "default",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement(__ds_scope.ImageSlot, {
    src: src,
    alt: alt,
    ratio: ratio,
    wash: wash,
    fit: "cover"
  }, badge && /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      top: 8,
      left: 8
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Badge, {
    tone: "error",
    size: "sm"
  }, badge))), name && /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-ui)",
      fontWeight: 700,
      fontSize: 14,
      lineHeight: 1.3,
      color: "var(--text-strong)"
    }
  }, name), price && /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-ui)",
      fontWeight: 700,
      fontSize: 14,
      color: "var(--text-default)"
    }
  }, price), feature && /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-ui)",
      fontWeight: 400,
      fontSize: 11,
      lineHeight: 1.4,
      color: "var(--text-muted)"
    }
  }, feature));
}
Object.assign(__ds_scope, { ProductCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/widgets/ProductCard.jsx", error: String((e && e.message) || e) }); }

// components/widgets/ScrollIndicator.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function ScrollIndicator({
  count = 8,
  active = 0,
  // index of active page (0-based)
  style = {},
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: "flex",
      gap: 6,
      alignItems: "center",
      padding: "0 16px 14px",
      ...style
    }
  }, rest), Array.from({
    length: count
  }).map((_, i) => {
    const isActive = i === active;
    return /*#__PURE__*/React.createElement("span", {
      key: i,
      style: {
        height: 4,
        flex: isActive ? "0 0 24px" : "1 1 auto",
        maxWidth: isActive ? 24 : 16,
        borderRadius: "var(--radius-pill)",
        background: isActive ? "var(--text-strong)" : "var(--neutral-light-solid-300)",
        transition: "background .2s ease"
      }
    });
  }));
}
Object.assign(__ds_scope, { ScrollIndicator });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/widgets/ScrollIndicator.jsx", error: String((e && e.message) || e) }); }

// components/widgets/SectionHeader.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function SectionHeader({
  title = "Trending now",
  action,
  // optional string e.g. "View all"
  onAction,
  onContrast = false,
  // true when sitting on a brand-colored jacket
  style = {},
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      padding: "16px 16px 12px",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-ui)",
      fontWeight: 700,
      fontSize: 17,
      lineHeight: "24px",
      color: onContrast ? "#fff" : "var(--text-default)",
      whiteSpace: "nowrap",
      overflow: "hidden",
      textOverflow: "ellipsis"
    }
  }, title), action && /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onAction,
    style: {
      border: "none",
      background: "transparent",
      cursor: "pointer",
      fontFamily: "var(--font-ui)",
      fontWeight: 700,
      fontSize: 13,
      color: onContrast ? "#fff" : "var(--text-link)",
      padding: 0
    }
  }, action));
}
Object.assign(__ds_scope, { SectionHeader });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/widgets/SectionHeader.jsx", error: String((e && e.message) || e) }); }

// components/widgets/CLPWidget.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function CLPWidget({
  title = "Trending now",
  action,
  onAction,
  layout = "grid",
  // grid | scroll
  columns = 2,
  // for grid layout
  jacket = false,
  // colored brand container vs plain white
  jacketColor,
  // override jacket fill (defaults to --brand-primary)
  scroll = false,
  // show ScrollIndicator
  scrollCount = 8,
  scrollActive = 0,
  brand,
  // re-skin: flipkart | minutes | ...
  children,
  style = {},
  ...rest
}) {
  const onContrast = jacket;
  return /*#__PURE__*/React.createElement("div", _extends({
    "data-brand": brand,
    style: {
      background: jacket ? jacketColor || "var(--brand-primary)" : "var(--surface-card)",
      borderRadius: "var(--radius-2xl)",
      overflow: "hidden",
      boxShadow: "var(--shadow-md)",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement(__ds_scope.SectionHeader, {
    title: title,
    action: action,
    onAction: onAction,
    onContrast: onContrast
  }), /*#__PURE__*/React.createElement("div", {
    style: layout === "scroll" ? {
      display: "flex",
      gap: 12,
      padding: "0 16px 16px",
      overflowX: "auto",
      scrollbarWidth: "none"
    } : {
      display: "grid",
      gridTemplateColumns: `repeat(${columns}, 1fr)`,
      gap: 12,
      padding: "0 16px 16px"
    }
  }, children), scroll && /*#__PURE__*/React.createElement(__ds_scope.ScrollIndicator, {
    count: scrollCount,
    active: scrollActive
  }));
}
Object.assign(__ds_scope, { CLPWidget });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/widgets/CLPWidget.jsx", error: String((e && e.message) || e) }); }

// ui_kits/clp/AppBar.jsx
try { (() => {
// AppBar — Flipkart-style mobile top bar: brand wordmark + search + cart.
function AppBar({
  brandName = "Flipkart",
  onBrand
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: "sticky",
      top: 0,
      zIndex: 20
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--brand-primary)",
      padding: "10px 14px 12px",
      display: "flex",
      flexDirection: "column",
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      lineHeight: 1
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-display)",
      fontWeight: 800,
      fontSize: 19,
      color: "#fff",
      fontStyle: "italic"
    }
  }, brandName), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-ui)",
      fontSize: 10,
      color: "var(--brand-yellow)",
      fontWeight: 600,
      fontStyle: "italic"
    }
  }, "Explore ", /*#__PURE__*/React.createElement("span", {
    style: {
      color: "#fff"
    }
  }, "Plus"), " \u2726")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 16,
      alignItems: "center",
      color: "#fff"
    }
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "bell",
    style: {
      width: 22
    }
  }), /*#__PURE__*/React.createElement("i", {
    "data-lucide": "shopping-cart",
    style: {
      width: 22
    }
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      background: "#fff",
      borderRadius: "var(--radius-sm)",
      display: "flex",
      alignItems: "center",
      gap: 8,
      padding: "9px 12px",
      boxShadow: "var(--shadow-xs)"
    }
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "search",
    style: {
      width: 18,
      color: "var(--brand-primary)"
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-ui)",
      fontSize: 13,
      color: "var(--text-muted)"
    }
  }, "Search for products, brands and more"))));
}
window.AppBar = AppBar;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/clp/AppBar.jsx", error: String((e && e.message) || e) }); }

// ui_kits/clp/BottomNav.jsx
try { (() => {
// BottomNav — fixed bottom navigation, Flipkart app style.
function BottomNav() {
  const items = [["home", "Home", true], ["grid-2x2", "Categories", false], ["zap", "Deals", false], ["user", "Account", false], ["shopping-cart", "Cart", false]];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: "sticky",
      bottom: 0,
      zIndex: 20,
      background: "#fff",
      borderTop: "1px solid var(--border-subtle)",
      display: "flex",
      justifyContent: "space-around",
      padding: "8px 4px 10px"
    }
  }, items.map(([icon, label, active]) => /*#__PURE__*/React.createElement("div", {
    key: label,
    style: {
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      gap: 3
    }
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": icon,
    style: {
      width: 21,
      color: active ? "var(--brand-primary)" : "var(--text-muted)"
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-ui)",
      fontSize: 10,
      fontWeight: active ? 700 : 500,
      color: active ? "var(--brand-primary)" : "var(--text-muted)"
    }
  }, label))));
}
window.BottomNav = BottomNav;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/clp/BottomNav.jsx", error: String((e && e.message) || e) }); }

// ui_kits/clp/CategoryChips.jsx
try { (() => {
// CategoryChips — the horizontal category strip + a brand switcher row.
function CategoryChips({
  brand,
  onBrand
}) {
  const cats = ["Grocery", "Mobiles", "Fashion", "Electronics", "Home", "Appliances", "Travel", "Toys"];
  const brands = [["flipkart", "Flipkart"], ["minutes", "Minutes"], ["shopsy", "Shopsy"], ["spoyl", "Spoyl"]];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: "#fff",
      borderBottom: "1px solid var(--border-subtle)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 8,
      padding: "10px 14px",
      overflowX: "auto",
      scrollbarWidth: "none"
    }
  }, brands.map(([id, label]) => {
    const active = id === brand;
    return /*#__PURE__*/React.createElement("button", {
      key: id,
      onClick: () => onBrand(id),
      "data-brand": id,
      style: {
        flex: "none",
        border: active ? "none" : "1px solid var(--border-default)",
        background: active ? "var(--brand-primary)" : "#fff",
        color: active ? "#fff" : "var(--text-default)",
        fontFamily: "var(--font-ui)",
        fontWeight: 700,
        fontSize: 12,
        padding: "6px 14px",
        borderRadius: "var(--radius-pill)",
        cursor: "pointer"
      }
    }, label);
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 18,
      padding: "4px 14px 12px",
      overflowX: "auto",
      scrollbarWidth: "none"
    }
  }, cats.map(c => /*#__PURE__*/React.createElement("div", {
    key: c,
    style: {
      flex: "none",
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      gap: 6,
      width: 52
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 48,
      height: 48,
      borderRadius: "var(--radius-md)",
      background: "var(--placeholder-blue)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center"
    }
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "package",
    style: {
      width: 22,
      color: "var(--brand-primary)"
    }
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-ui)",
      fontSize: 10,
      color: "var(--text-default)",
      textAlign: "center"
    }
  }, c)))));
}
window.CategoryChips = CategoryChips;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/clp/CategoryChips.jsx", error: String((e && e.message) || e) }); }

// ui_kits/clp/HeroBanner.jsx
try { (() => {
// HeroBanner — full-bleed promo banner built on a brand jacket + image slot.
function HeroBanner({
  Button
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      margin: "12px 14px",
      borderRadius: "var(--radius-xl)",
      overflow: "hidden",
      background: "var(--brand-primary)",
      position: "relative",
      display: "flex",
      alignItems: "stretch",
      minHeight: 150
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: "1 1 56%",
      padding: "18px",
      display: "flex",
      flexDirection: "column",
      justifyContent: "center",
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-ui)",
      fontWeight: 700,
      fontSize: 11,
      color: "var(--brand-yellow)",
      letterSpacing: ".04em"
    }
  }, "BIG SAVINGS DAYS"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-display)",
      fontWeight: 800,
      fontSize: 30,
      lineHeight: 0.95,
      color: "#fff"
    }
  }, "Up to 70% off"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-ui)",
      fontWeight: 400,
      fontSize: 12,
      color: "rgba(255,255,255,.85)"
    }
  }, "Incl. of all offers \xB7 From \u20B957,999"), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    size: "sm"
  }, "Shop now"))), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: "1 1 44%",
      background: "var(--placeholder-blue-2)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center"
    }
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "image",
    style: {
      width: 30,
      color: "var(--placeholder-text)"
    }
  })));
}
window.HeroBanner = HeroBanner;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/clp/HeroBanner.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.ChevronButton = __ds_scope.ChevronButton;

__ds_ns.CLPWidget = __ds_scope.CLPWidget;

__ds_ns.ImageSlot = __ds_scope.ImageSlot;

__ds_ns.ProductCard = __ds_scope.ProductCard;

__ds_ns.ScrollIndicator = __ds_scope.ScrollIndicator;

__ds_ns.SectionHeader = __ds_scope.SectionHeader;

})();
