/* @ds-bundle: {"format":3,"namespace":"CleartripDesignSystem_23ed32","components":[{"name":"Button","sourcePath":"components/buttons/Button.jsx"},{"name":"IconButton","sourcePath":"components/buttons/IconButton.jsx"},{"name":"Badge","sourcePath":"components/data-display/Badge.jsx"},{"name":"Card","sourcePath":"components/data-display/Card.jsx"},{"name":"Chip","sourcePath":"components/data-display/Chip.jsx"},{"name":"AlertCallout","sourcePath":"components/feedback/AlertCallout.jsx"},{"name":"Tabs","sourcePath":"components/feedback/Tabs.jsx"},{"name":"Toast","sourcePath":"components/feedback/Toast.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"Radio","sourcePath":"components/forms/Radio.jsx"},{"name":"Switch","sourcePath":"components/forms/Switch.jsx"}],"sourceHashes":{"components/buttons/Button.jsx":"c4db5266eeab","components/buttons/IconButton.jsx":"c5049001a8a4","components/data-display/Badge.jsx":"8fd18232b12c","components/data-display/Card.jsx":"7f0fa2731810","components/data-display/Chip.jsx":"f2e70da65bc4","components/feedback/AlertCallout.jsx":"bbf7688cd17f","components/feedback/Tabs.jsx":"aae43bc28fa5","components/feedback/Toast.jsx":"75698c2b2677","components/forms/Checkbox.jsx":"bd0095e2bdcb","components/forms/Input.jsx":"51608a5d8fb2","components/forms/Radio.jsx":"5e96acc92a8a","components/forms/Switch.jsx":"bfc45983fe42","ui_kits/cleartrip-web/AppHeader.jsx":"e4191895e4f3","ui_kits/cleartrip-web/FilterRail.jsx":"b102ae643547","ui_kits/cleartrip-web/FlightCard.jsx":"afa7ca3f9cd5","ui_kits/cleartrip-web/Screens.jsx":"05381f989104","ui_kits/cleartrip-web/SearchWidget.jsx":"4e2aadbf6ae0"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.CleartripDesignSystem_23ed32 = window.CleartripDesignSystem_23ed32 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/buttons/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Cleartrip Button.
 * Mirrors @cleartrip/ct-design-components Button: variant (contained|outline|bare)
 * × color (primary=ink, secondary=brand orange, tertiary=blue, neutral) × size.
 * Note the brand signature: the *primary* contained button is INK BLACK; orange is
 * the *secondary* fill.
 */
function Button({
  children,
  variant = 'contained',
  color = 'primary',
  size = 'medium',
  isFullWidth = false,
  disabled = false,
  loading = false,
  prefixIcon,
  suffixIcon,
  onClick,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const isDisabled = disabled || loading;
  const sizes = {
    small: {
      height: 32,
      padding: '0 12px',
      font: 'var(--ct-fw-semibold) 14px/20px var(--ct-font-family)'
    },
    medium: {
      height: 40,
      padding: '0 16px',
      font: 'var(--ct-fw-semibold) 14px/20px var(--ct-font-family)'
    },
    large: {
      height: 48,
      padding: '0 20px',
      font: 'var(--ct-fw-semibold) 16px/24px var(--ct-font-family)'
    }
  };
  const fills = {
    primary: {
      bg: 'var(--ct-neutral-900)',
      label: 'var(--ct-neutral-100)',
      hover: '#000000'
    },
    secondary: {
      bg: 'var(--ct-brand)',
      label: 'var(--ct-neutral-100)',
      hover: 'var(--ct-bg-primary-hover)'
    },
    tertiary: {
      bg: 'var(--ct-link)',
      label: 'var(--ct-neutral-100)',
      hover: 'var(--ct-link-2-hover)'
    },
    neutral: {
      bg: 'var(--ct-neutral-100)',
      label: 'var(--ct-neutral-900)',
      hover: 'var(--ct-neutral-200)'
    }
  };
  const outlineColors = {
    primary: {
      border: 'var(--ct-neutral-900)',
      label: 'var(--ct-neutral-900)'
    },
    secondary: {
      border: 'var(--ct-brand)',
      label: 'var(--ct-brand)'
    },
    tertiary: {
      border: 'var(--ct-link)',
      label: 'var(--ct-link)'
    },
    neutral: {
      border: 'var(--ct-neutral-900)',
      label: 'var(--ct-neutral-900)'
    }
  };
  const sz = sizes[size] || sizes.medium;
  const base = {
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    height: sz.height,
    padding: sz.padding,
    font: sz.font,
    borderRadius: 'var(--ct-radius-button)',
    border: '1px solid transparent',
    cursor: isDisabled ? 'not-allowed' : 'pointer',
    width: isFullWidth ? '100%' : 'auto',
    transition: 'background-color 150ms cubic-bezier(0.4,0,0.2,1), color 150ms, border-color 150ms',
    whiteSpace: 'nowrap',
    ...style
  };
  let skin;
  if (isDisabled) {
    skin = variant === 'outline' ? {
      background: 'var(--ct-neutral-300)',
      color: 'var(--ct-disabled-text)',
      borderColor: 'transparent'
    } : {
      background: 'var(--ct-neutral-300)',
      color: 'var(--ct-disabled-text)'
    };
  } else if (variant === 'contained') {
    const f = fills[color] || fills.primary;
    skin = {
      background: hover ? f.hover : f.bg,
      color: f.label,
      borderColor: color === 'neutral' ? 'var(--ct-line)' : 'transparent'
    };
  } else if (variant === 'outline') {
    const o = outlineColors[color] || outlineColors.primary;
    skin = {
      background: hover ? 'var(--ct-neutral-200)' : 'var(--ct-neutral-100)',
      color: o.label,
      borderColor: o.border
    };
  } else {
    // bare
    const o = outlineColors[color] || outlineColors.primary;
    skin = {
      background: 'transparent',
      color: o.label,
      borderColor: 'transparent',
      padding: '0 4px'
    };
  }
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    onClick: isDisabled ? undefined : onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      ...base,
      ...skin
    },
    disabled: isDisabled
  }, rest), loading ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      gap: 4
    }
  }, /*#__PURE__*/React.createElement(Dot, null), " ", /*#__PURE__*/React.createElement(Dot, {
    d: 120
  }), " ", /*#__PURE__*/React.createElement(Dot, {
    d: 240
  })) : /*#__PURE__*/React.createElement(React.Fragment, null, prefixIcon, children, suffixIcon));
}
function Dot({
  d = 0
}) {
  return /*#__PURE__*/React.createElement("span", {
    style: {
      width: 6,
      height: 6,
      borderRadius: '50%',
      background: 'currentColor',
      display: 'inline-block',
      opacity: 0.4,
      animation: `ctDot 1s ${d}ms infinite ease-in-out`
    }
  });
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/buttons/Button.jsx", error: String((e && e.message) || e) }); }

// components/buttons/IconButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Cleartrip IconButton — a square tap target wrapping a single icon.
 * Pass a Material Symbols ligature name as `icon` (uses .ct-icon) or any node as children.
 */
function IconButton({
  icon,
  children,
  size = 'medium',
  variant = 'bare',
  ariaLabel,
  disabled = false,
  onClick,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const dims = {
    small: 32,
    medium: 40,
    large: 48
  }[size] || 40;
  const iconPx = {
    small: 18,
    medium: 22,
    large: 24
  }[size] || 22;
  const skins = {
    bare: {
      background: hover && !disabled ? 'var(--ct-neutral-300)' : 'transparent',
      border: 'none'
    },
    outline: {
      background: 'var(--ct-neutral-100)',
      border: '1px solid var(--ct-line)'
    },
    filled: {
      background: hover && !disabled ? 'var(--ct-neutral-300)' : 'var(--ct-neutral-200)',
      border: 'none'
    }
  };
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    "aria-label": ariaLabel,
    onClick: disabled ? undefined : onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    disabled: disabled,
    style: {
      width: dims,
      height: dims,
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      borderRadius: 'var(--ct-radius-pill)',
      cursor: disabled ? 'not-allowed' : 'pointer',
      color: disabled ? 'var(--ct-disabled-text)' : 'var(--ct-neutral-900)',
      transition: 'background-color 150ms cubic-bezier(0.4,0,0.2,1)',
      ...skins[variant],
      ...style
    }
  }, rest), icon ? /*#__PURE__*/React.createElement("span", {
    className: "ct-icon",
    style: {
      fontSize: iconPx
    }
  }, icon) : children);
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/buttons/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/data-display/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Cleartrip Badge — small status/metadata pill. 4px radius, B3/B4 semibold.
 * `variant` subtle (tinted bg + coloured text) or solid (filled). `color` picks the
 * semantic ramp. Use for fare tags (NON-STOP), status (Confirmed), deals (-30%).
 */
function Badge({
  children,
  color = 'default',
  variant = 'subtle',
  size = 'standard',
  icon,
  style,
  ...rest
}) {
  const ramp = {
    default: {
      soft: 'var(--ct-neutral-300)',
      solid: 'var(--ct-neutral-900)',
      text: 'var(--ct-neutral-900)',
      onSolid: 'var(--ct-neutral-100)'
    },
    brand: {
      soft: 'var(--ct-orange-100)',
      solid: 'var(--ct-brand)',
      text: 'var(--ct-brand)',
      onSolid: 'var(--ct-neutral-100)'
    },
    green: {
      soft: 'var(--ct-success-bg)',
      solid: 'var(--ct-success)',
      text: 'var(--ct-success)',
      onSolid: 'var(--ct-neutral-100)'
    },
    red: {
      soft: 'var(--ct-warning-bg)',
      solid: 'var(--ct-warning)',
      text: 'var(--ct-warning)',
      onSolid: 'var(--ct-neutral-100)'
    },
    yellow: {
      soft: 'var(--ct-alert-bg)',
      solid: 'var(--ct-alert)',
      text: 'var(--ct-alert)',
      onSolid: 'var(--ct-neutral-100)'
    },
    blue: {
      soft: 'var(--ct-blue-100)',
      solid: 'var(--ct-link)',
      text: 'var(--ct-link)',
      onSolid: 'var(--ct-neutral-100)'
    },
    premium: {
      soft: 'var(--ct-neutral-900)',
      solid: 'var(--ct-neutral-900)',
      text: 'var(--ct-neutral-100)',
      onSolid: 'var(--ct-neutral-100)'
    }
  }[color] || {};
  const solid = variant === 'solid' || color === 'premium';
  const pad = size === 'nano' ? '2px 4px' : size === 'micro' ? '2px 8px' : '4px 8px';
  const font = size === 'standard' ? 'var(--ct-fw-semibold) 12px/16px var(--ct-font-family)' : 'var(--ct-fw-semibold) 10px/12px var(--ct-font-family)';
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 4,
      padding: pad,
      borderRadius: 'var(--ct-radius-badge)',
      background: solid ? ramp.solid : ramp.soft,
      color: solid ? ramp.onSolid : ramp.text,
      font,
      whiteSpace: 'nowrap',
      ...style
    }
  }, rest), icon && /*#__PURE__*/React.createElement("span", {
    className: "ct-icon",
    style: {
      fontSize: size === 'standard' ? 14 : 12
    }
  }, icon), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-display/Badge.jsx", error: String((e && e.message) || e) }); }

// components/data-display/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Cleartrip Card — white surface container. Hairline border by default, shadow only
 * on lift. `radius` sm 6 / md 8 / lg 12 / xl 16. `elevation` 0–3.
 */
function Card({
  children,
  radius = 'md',
  elevation = 0,
  border = true,
  padding = 16,
  interactive = false,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const radii = {
    none: 0,
    sm: 6,
    md: 8,
    lg: 12,
    xl: 16
  };
  const shadows = {
    0: 'none',
    1: 'var(--ct-elevation-1)',
    2: 'var(--ct-elevation-2)',
    3: 'var(--ct-elevation-3)'
  };
  const effElev = interactive && hover ? Math.min(3, (elevation || 0) + 2) : elevation;
  return /*#__PURE__*/React.createElement("div", _extends({
    onMouseEnter: () => interactive && setHover(true),
    onMouseLeave: () => interactive && setHover(false),
    style: {
      background: 'var(--ct-surface-card)',
      borderRadius: radii[radius] ?? 8,
      border: border ? '1px solid var(--ct-line)' : 'none',
      boxShadow: shadows[effElev] || 'none',
      padding,
      cursor: interactive ? 'pointer' : 'default',
      transition: 'box-shadow 200ms cubic-bezier(0.4,0,0.2,1)',
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-display/Card.jsx", error: String((e && e.message) || e) }); }

// components/data-display/Chip.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Cleartrip Chip — fully-rounded filter/selection pill, 32px tall.
 * Unselected: white with 1px grey border. Selected: grey fill with 1.5px ink border.
 * Optional leading icon and trailing dropdown caret.
 */
function Chip({
  children,
  selected = false,
  disabled = false,
  icon,
  dropdown = false,
  onClick,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    onClick: disabled ? undefined : onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    disabled: disabled,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      height: 32,
      padding: '0 14px',
      borderRadius: 'var(--ct-radius-pill)',
      font: 'var(--ct-fw-medium) 14px/20px var(--ct-font-family)',
      cursor: disabled ? 'not-allowed' : 'pointer',
      background: disabled ? 'var(--ct-neutral-300)' : selected ? 'var(--ct-neutral-300)' : hover ? 'var(--ct-neutral-200)' : 'var(--ct-neutral-100)',
      color: disabled ? 'var(--ct-disabled-text)' : 'var(--ct-neutral-900)',
      border: disabled ? '1px solid transparent' : selected ? '1.5px solid var(--ct-neutral-900)' : '1px solid var(--ct-neutral-400)',
      transition: 'background-color 150ms, border-color 150ms',
      whiteSpace: 'nowrap',
      ...style
    }
  }, rest), icon && /*#__PURE__*/React.createElement("span", {
    className: "ct-icon",
    style: {
      fontSize: 18
    }
  }, icon), children, dropdown && /*#__PURE__*/React.createElement("span", {
    className: "ct-icon",
    style: {
      fontSize: 18,
      marginRight: -4
    }
  }, "expand_more"));
}
Object.assign(__ds_scope, { Chip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-display/Chip.jsx", error: String((e && e.message) || e) }); }

// components/feedback/AlertCallout.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Cleartrip AlertCallout — inline, persistent message banner with a tinted semantic
 * surface and matching icon. For policy notes, errors, info ("Fares may change").
 */
function AlertCallout({
  children,
  title,
  type = 'info',
  icon,
  onClose,
  style,
  ...rest
}) {
  const ramp = {
    info: {
      bg: 'var(--ct-blue-100)',
      fg: 'var(--ct-link)',
      icon: 'info'
    },
    success: {
      bg: 'var(--ct-success-bg)',
      fg: 'var(--ct-success)',
      icon: 'check_circle'
    },
    warning: {
      bg: 'var(--ct-alert-bg)',
      fg: 'var(--ct-alert)',
      icon: 'warning'
    },
    error: {
      bg: 'var(--ct-warning-bg)',
      fg: 'var(--ct-warning)',
      icon: 'error'
    }
  }[type] || {};
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: 'flex',
      gap: 12,
      alignItems: 'flex-start',
      background: ramp.bg,
      borderRadius: 'var(--ct-radius-8)',
      padding: '12px 14px',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    className: "ct-icon",
    style: {
      fontSize: 20,
      color: ramp.fg,
      flexShrink: 0
    }
  }, icon || ramp.icon), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, title && /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--ct-fw-semibold) 14px/20px var(--ct-font-family)',
      color: 'var(--ct-neutral-900)'
    }
  }, title), /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--ct-fw-regular) 13px/18px var(--ct-font-family)',
      color: 'var(--ct-neutral-700)',
      marginTop: title ? 2 : 0
    }
  }, children)), onClose && /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onClose,
    "aria-label": "Dismiss",
    style: {
      background: 'none',
      border: 'none',
      cursor: 'pointer',
      padding: 0,
      color: 'var(--ct-neutral-700)',
      display: 'inline-flex'
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "ct-icon",
    style: {
      fontSize: 18
    }
  }, "close")));
}
Object.assign(__ds_scope, { AlertCallout });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/AlertCallout.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Tabs.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Cleartrip Tabs — underline navigation tabs. Selected tab gets an ink label and a
 * 2px ink underline; the others are grey.
 */
function Tabs({
  tabs = [],
  value,
  defaultValue,
  onChange,
  style,
  ...rest
}) {
  const isControlled = value !== undefined;
  const [inner, setInner] = React.useState(defaultValue ?? (tabs[0] && tabs[0].id));
  const active = isControlled ? value : inner;
  const select = id => {
    if (!isControlled) setInner(id);
    onChange && onChange(id);
  };
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: 'flex',
      gap: 24,
      borderBottom: '1px solid var(--ct-line)',
      ...style
    }
  }, rest), tabs.map(t => {
    const on = t.id === active;
    return /*#__PURE__*/React.createElement("button", {
      key: t.id,
      type: "button",
      onClick: () => select(t.id),
      style: {
        background: 'none',
        border: 'none',
        cursor: 'pointer',
        padding: '12px 0',
        position: 'relative',
        display: 'inline-flex',
        alignItems: 'center',
        gap: 6,
        font: `${on ? 'var(--ct-fw-semibold)' : 'var(--ct-fw-medium)'} 14px/20px var(--ct-font-family)`,
        color: on ? 'var(--ct-neutral-900)' : 'var(--ct-neutral-700)'
      }
    }, t.icon && /*#__PURE__*/React.createElement("span", {
      className: "ct-icon",
      style: {
        fontSize: 18
      }
    }, t.icon), t.label, /*#__PURE__*/React.createElement("span", {
      style: {
        position: 'absolute',
        left: 0,
        right: 0,
        bottom: -1,
        height: 2,
        background: on ? 'var(--ct-neutral-900)' : 'transparent',
        borderRadius: '2px 2px 0 0'
      }
    }));
  }));
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Tabs.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Toast.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Cleartrip Toast — transient snackbar. Dark ink surface, white text, optional action.
 * For confirmations and quick feedback ("Added to trip", "Coupon applied").
 */
function Toast({
  children,
  icon,
  action,
  onAction,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 12,
      background: 'var(--ct-neutral-900)',
      color: 'var(--ct-neutral-100)',
      padding: '12px 16px',
      borderRadius: 'var(--ct-radius-8)',
      boxShadow: 'var(--ct-elevation-3)',
      font: 'var(--ct-fw-medium) 14px/20px var(--ct-font-family)',
      maxWidth: 420,
      ...style
    }
  }, rest), icon && /*#__PURE__*/React.createElement("span", {
    className: "ct-icon",
    style: {
      fontSize: 20,
      color: 'var(--ct-green-100)'
    }
  }, icon), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    }
  }, children), action && /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onAction,
    style: {
      background: 'none',
      border: 'none',
      cursor: 'pointer',
      padding: 0,
      color: 'var(--ct-brand)',
      font: 'var(--ct-fw-semibold) 14px/20px var(--ct-font-family)'
    }
  }, action));
}
Object.assign(__ds_scope, { Toast });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Toast.jsx", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Cleartrip Checkbox — square, ink-filled when checked, 1.5px grey border when not. */
function Checkbox({
  checked,
  defaultChecked = false,
  onChange,
  label,
  disabled = false,
  style,
  ...rest
}) {
  const isControlled = checked !== undefined;
  const [inner, setInner] = React.useState(defaultChecked);
  const on = isControlled ? checked : inner;
  const toggle = () => {
    if (disabled) return;
    if (!isControlled) setInner(!on);
    onChange && onChange(!on);
  };
  return /*#__PURE__*/React.createElement("label", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 10,
      cursor: disabled ? 'not-allowed' : 'pointer',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 20,
      height: 20,
      borderRadius: 'var(--ct-radius-4)',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: on ? disabled ? 'var(--ct-neutral-500)' : 'var(--ct-neutral-900)' : 'var(--ct-neutral-100)',
      border: on ? '1.5px solid transparent' : `1.5px solid ${disabled ? 'var(--ct-neutral-400)' : 'var(--ct-neutral-500)'}`,
      transition: 'background-color 150ms, border-color 150ms'
    },
    onClick: toggle
  }, on && /*#__PURE__*/React.createElement("svg", {
    width: "12",
    height: "10",
    viewBox: "0 0 10 8",
    fill: "none"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M9 1L3.5 6.5L1 4",
    stroke: "#fff",
    strokeWidth: "1.5",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }))), label && /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--ct-fw-medium) 14px/20px var(--ct-font-family)',
      color: disabled ? 'var(--ct-disabled-text)' : 'var(--ct-neutral-900)'
    },
    onClick: toggle
  }, label));
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Cleartrip Input field. Floating-label text field matching the Field component:
 * 56px tall (md) / 40px (sm), 8px radius, 1px grey border that thickens to 1.5px ink
 * on focus and 1.5px red on error. Label floats up when focused or filled.
 */
function Input({
  label,
  value,
  defaultValue,
  onChange,
  placeholder,
  size = 'md',
  error,
  helperText,
  disabled = false,
  prefix,
  suffix,
  type = 'text',
  style,
  ...rest
}) {
  const isControlled = value !== undefined;
  const [inner, setInner] = React.useState(defaultValue || '');
  const val = isControlled ? value : inner;
  const [focus, setFocus] = React.useState(false);
  const filled = val !== undefined && val !== null && String(val).length > 0 || focus;
  const borderColor = error ? 'var(--ct-warning)' : focus ? 'var(--ct-neutral-900)' : 'var(--ct-neutral-500)';
  const borderWidth = error || focus ? 1.5 : 1;
  const h = size === 'sm' ? 40 : 56;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'inline-flex',
      flexDirection: 'column',
      width: '100%',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      height: h,
      display: 'flex',
      alignItems: 'center',
      background: disabled ? 'var(--ct-neutral-300)' : 'var(--ct-neutral-100)',
      border: `${borderWidth}px solid ${borderColor}`,
      borderRadius: 'var(--ct-radius-field)',
      padding: '0 16px',
      gap: 8,
      transition: 'border-color 150ms cubic-bezier(0.4,0,0.2,1)'
    }
  }, prefix && /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--ct-neutral-700)',
      display: 'inline-flex'
    }
  }, prefix), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      flex: 1,
      height: '100%'
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    style: {
      position: 'absolute',
      left: 0,
      pointerEvents: 'none',
      color: error ? 'var(--ct-warning)' : 'var(--ct-neutral-700)',
      transition: 'all 150ms cubic-bezier(0.4,0,0.2,1)',
      ...(size === 'sm' || filled ? {
        top: 8,
        font: 'var(--ct-fw-medium) 11px/14px var(--ct-font-family)'
      } : {
        top: '50%',
        transform: 'translateY(-50%)',
        font: 'var(--ct-fw-regular) 16px/20px var(--ct-font-family)'
      })
    }
  }, label), /*#__PURE__*/React.createElement("input", _extends({
    type: type,
    value: val,
    disabled: disabled,
    placeholder: filled || !label ? placeholder : '',
    onChange: e => {
      if (!isControlled) setInner(e.target.value);
      onChange && onChange(e);
    },
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      width: '100%',
      height: '100%',
      border: 'none',
      outline: 'none',
      background: 'transparent',
      font: 'var(--ct-fw-medium) 16px/20px var(--ct-font-family)',
      color: disabled ? 'var(--ct-disabled-text)' : 'var(--ct-neutral-900)',
      paddingTop: label && size !== 'sm' && filled ? 18 : label && size === 'sm' ? 14 : 0
    }
  }, rest))), suffix && /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--ct-neutral-700)',
      display: 'inline-flex'
    }
  }, suffix)), (error || helperText) && /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--ct-fw-regular) 12px/16px var(--ct-font-family)',
      color: error ? 'var(--ct-warning)' : 'var(--ct-neutral-700)',
      marginTop: 4
    }
  }, error || helperText));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/Radio.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Cleartrip Radio — circular, ink dot + ink ring when selected. */
function Radio({
  checked,
  defaultChecked = false,
  onChange,
  label,
  name,
  value,
  disabled = false,
  style,
  ...rest
}) {
  const isControlled = checked !== undefined;
  const [inner, setInner] = React.useState(defaultChecked);
  const on = isControlled ? checked : inner;
  const select = () => {
    if (disabled) return;
    if (!isControlled) setInner(true);
    onChange && onChange(value !== undefined ? value : true);
  };
  return /*#__PURE__*/React.createElement("label", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 10,
      cursor: disabled ? 'not-allowed' : 'pointer',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 20,
      height: 20,
      borderRadius: '50%',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: 'var(--ct-neutral-100)',
      border: `1.5px solid ${on ? 'var(--ct-neutral-900)' : disabled ? 'var(--ct-neutral-400)' : 'var(--ct-neutral-500)'}`,
      transition: 'border-color 150ms'
    },
    onClick: select
  }, on && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 10,
      height: 10,
      borderRadius: '50%',
      background: disabled ? 'var(--ct-neutral-500)' : 'var(--ct-neutral-900)'
    }
  })), label && /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--ct-fw-medium) 14px/20px var(--ct-font-family)',
      color: disabled ? 'var(--ct-disabled-text)' : 'var(--ct-neutral-900)'
    },
    onClick: select
  }, label));
}
Object.assign(__ds_scope, { Radio });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Radio.jsx", error: String((e && e.message) || e) }); }

// components/forms/Switch.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Cleartrip Switch — pill toggle; track turns brand orange when on. */
function Switch({
  checked,
  defaultChecked = false,
  onChange,
  label,
  disabled = false,
  style,
  ...rest
}) {
  const isControlled = checked !== undefined;
  const [inner, setInner] = React.useState(defaultChecked);
  const on = isControlled ? checked : inner;
  const toggle = () => {
    if (disabled) return;
    if (!isControlled) setInner(!on);
    onChange && onChange(!on);
  };
  return /*#__PURE__*/React.createElement("label", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 10,
      cursor: disabled ? 'not-allowed' : 'pointer',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    onClick: toggle,
    style: {
      width: 40,
      height: 24,
      borderRadius: 'var(--ct-radius-pill)',
      padding: 2,
      background: on ? disabled ? 'var(--ct-neutral-400)' : 'var(--ct-brand)' : 'var(--ct-neutral-400)',
      display: 'inline-flex',
      alignItems: 'center',
      transition: 'background-color 200ms cubic-bezier(0.4,0,0.2,1)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 20,
      height: 20,
      borderRadius: '50%',
      background: '#fff',
      boxShadow: '0 1px 3px rgba(0,0,0,.2)',
      transform: on ? 'translateX(16px)' : 'translateX(0)',
      transition: 'transform 200ms cubic-bezier(0.4,0,0.2,1)'
    }
  })), label && /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--ct-fw-medium) 14px/20px var(--ct-font-family)',
      color: disabled ? 'var(--ct-disabled-text)' : 'var(--ct-neutral-900)'
    },
    onClick: toggle
  }, label));
}
Object.assign(__ds_scope, { Switch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Switch.jsx", error: String((e && e.message) || e) }); }

// ui_kits/cleartrip-web/AppHeader.jsx
try { (() => {
// Cleartrip web — top app header (logo, primary nav, account)
const headerStyles = {
  bar: {
    height: 64,
    background: 'var(--ct-neutral-100)',
    borderBottom: '1px solid var(--ct-line)',
    display: 'flex',
    alignItems: 'center',
    gap: 32,
    padding: '0 32px',
    position: 'sticky',
    top: 0,
    zIndex: 50
  },
  nav: {
    display: 'flex',
    gap: 4,
    flex: 1
  },
  navItem: on => ({
    display: 'inline-flex',
    alignItems: 'center',
    gap: 8,
    height: 40,
    padding: '0 14px',
    borderRadius: 999,
    cursor: 'pointer',
    border: 'none',
    background: on ? 'var(--ct-neutral-900)' : 'transparent',
    color: on ? 'var(--ct-neutral-100)' : 'var(--ct-neutral-900)',
    font: 'var(--ct-fw-semibold) 14px/20px var(--ct-font-family)'
  }),
  right: {
    display: 'flex',
    alignItems: 'center',
    gap: 8
  },
  pill: {
    display: 'inline-flex',
    alignItems: 'center',
    gap: 6,
    height: 36,
    padding: '0 12px',
    borderRadius: 999,
    border: '1px solid var(--ct-line)',
    background: '#fff',
    cursor: 'pointer',
    font: 'var(--ct-fw-semibold) 13px/18px var(--ct-font-family)',
    color: 'var(--ct-neutral-900)'
  }
};
function AppHeader({
  active = 'flights',
  onNav
}) {
  const {
    IconButton
  } = window.CleartripDesignSystem_23ed32;
  const items = [{
    id: 'flights',
    label: 'Flights',
    icon: 'flight'
  }, {
    id: 'hotels',
    label: 'Hotels',
    icon: 'hotel'
  }, {
    id: 'trains',
    label: 'Trains',
    icon: 'train'
  }, {
    id: 'buses',
    label: 'Buses',
    icon: 'directions_bus'
  }, {
    id: 'activities',
    label: 'Activities',
    icon: 'confirmation_number'
  }];
  return /*#__PURE__*/React.createElement("header", {
    style: headerStyles.bar
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/cleartrip-logo.svg",
    alt: "Cleartrip",
    style: {
      height: 22
    }
  }), /*#__PURE__*/React.createElement("nav", {
    style: headerStyles.nav
  }, items.map(it => /*#__PURE__*/React.createElement("button", {
    key: it.id,
    style: headerStyles.navItem(active === it.id),
    onClick: () => onNav && onNav(it.id)
  }, /*#__PURE__*/React.createElement("span", {
    className: "ct-icon",
    style: {
      fontSize: 20
    }
  }, it.icon), it.label))), /*#__PURE__*/React.createElement("div", {
    style: headerStyles.right
  }, /*#__PURE__*/React.createElement("button", {
    style: headerStyles.pill
  }, /*#__PURE__*/React.createElement("span", {
    className: "ct-icon",
    style: {
      fontSize: 18
    }
  }, "language"), "INR \xB7 EN"), /*#__PURE__*/React.createElement("button", {
    style: headerStyles.pill
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/supercoin.svg",
    style: {
      width: 18,
      height: 18
    }
  }), "2,450"), /*#__PURE__*/React.createElement("button", {
    style: {
      ...headerStyles.pill,
      background: 'var(--ct-neutral-900)',
      color: '#fff',
      border: 'none'
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "ct-icon",
    style: {
      fontSize: 18
    }
  }, "person"), "Login")));
}
window.AppHeader = AppHeader;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/cleartrip-web/AppHeader.jsx", error: String((e && e.message) || e) }); }

// ui_kits/cleartrip-web/FilterRail.jsx
try { (() => {
// Cleartrip web — results filter rail
const railStyles = {
  rail: {
    width: 256,
    flexShrink: 0
  },
  group: {
    padding: '16px 0',
    borderBottom: '1px solid var(--ct-line)'
  },
  head: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12
  },
  title: {
    font: 'var(--ct-fw-semibold) 14px/20px var(--ct-font-family)',
    color: 'var(--ct-neutral-900)'
  },
  clear: {
    font: 'var(--ct-fw-semibold) 12px/16px var(--ct-font-family)',
    color: 'var(--ct-link)',
    cursor: 'pointer'
  },
  opt: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10
  },
  price: {
    font: 'var(--ct-fw-regular) 12px/16px var(--ct-font-family)',
    color: 'var(--ct-neutral-700)'
  }
};
function FilterRail() {
  const {
    Checkbox
  } = window.CleartripDesignSystem_23ed32;
  const Group = ({
    title,
    children
  }) => /*#__PURE__*/React.createElement("div", {
    style: railStyles.group
  }, /*#__PURE__*/React.createElement("div", {
    style: railStyles.head
  }, /*#__PURE__*/React.createElement("span", {
    style: railStyles.title
  }, title), /*#__PURE__*/React.createElement("span", {
    style: railStyles.clear
  }, "Clear")), children);
  const Opt = ({
    label,
    price,
    def
  }) => /*#__PURE__*/React.createElement("div", {
    style: railStyles.opt
  }, /*#__PURE__*/React.createElement(Checkbox, {
    label: label,
    defaultChecked: def
  }), price && /*#__PURE__*/React.createElement("span", {
    style: railStyles.price
  }, price));
  return /*#__PURE__*/React.createElement("aside", {
    style: railStyles.rail
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      ...railStyles.head,
      padding: '0 0 8px'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--ct-fw-semibold) 16px/24px var(--ct-font-family)'
    }
  }, "Filters")), /*#__PURE__*/React.createElement(Group, {
    title: "Stops"
  }, /*#__PURE__*/React.createElement(Opt, {
    label: "Non-stop",
    price: "\u20B95,310",
    def: true
  }), /*#__PURE__*/React.createElement(Opt, {
    label: "1 stop",
    price: "\u20B94,180"
  }), /*#__PURE__*/React.createElement(Opt, {
    label: "2+ stops",
    price: "\u20B93,950"
  })), /*#__PURE__*/React.createElement(Group, {
    title: "Departure time"
  }, /*#__PURE__*/React.createElement(Opt, {
    label: "Before 6 AM"
  }), /*#__PURE__*/React.createElement(Opt, {
    label: "6 AM \u2013 12 PM",
    def: true
  }), /*#__PURE__*/React.createElement(Opt, {
    label: "12 PM \u2013 6 PM"
  }), /*#__PURE__*/React.createElement(Opt, {
    label: "After 6 PM"
  })), /*#__PURE__*/React.createElement(Group, {
    title: "Airlines"
  }, /*#__PURE__*/React.createElement(Opt, {
    label: "IndiGo",
    price: "\u20B95,310",
    def: true
  }), /*#__PURE__*/React.createElement(Opt, {
    label: "Akasa Air",
    price: "\u20B95,499"
  }), /*#__PURE__*/React.createElement(Opt, {
    label: "Air India",
    price: "\u20B96,120"
  }), /*#__PURE__*/React.createElement(Opt, {
    label: "Vistara",
    price: "\u20B96,740"
  })));
}
window.FilterRail = FilterRail;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/cleartrip-web/FilterRail.jsx", error: String((e && e.message) || e) }); }

// ui_kits/cleartrip-web/FlightCard.jsx
try { (() => {
// Cleartrip web — a single flight result row
const flightStyles = {
  row: {
    display: 'flex',
    alignItems: 'center',
    gap: 24,
    padding: '18px 20px'
  },
  airline: {
    display: 'flex',
    alignItems: 'center',
    gap: 12,
    width: 180,
    flexShrink: 0
  },
  logo: {
    width: 36,
    height: 36,
    borderRadius: 8,
    background: 'var(--ct-neutral-200)',
    border: '1px solid var(--ct-line)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    color: 'var(--ct-neutral-700)'
  },
  name: {
    font: 'var(--ct-fw-semibold) 14px/20px var(--ct-font-family)',
    color: 'var(--ct-neutral-900)'
  },
  code: {
    font: 'var(--ct-fw-regular) 12px/16px var(--ct-font-family)',
    color: 'var(--ct-neutral-700)'
  },
  times: {
    display: 'flex',
    alignItems: 'center',
    gap: 16,
    flex: 1
  },
  time: {
    font: 'var(--ct-fw-semibold) 18px/24px var(--ct-font-family)',
    color: 'var(--ct-neutral-900)'
  },
  city: {
    font: 'var(--ct-fw-regular) 12px/16px var(--ct-font-family)',
    color: 'var(--ct-neutral-700)'
  },
  mid: {
    flex: 1,
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    gap: 4,
    minWidth: 120
  },
  dur: {
    font: 'var(--ct-fw-medium) 12px/16px var(--ct-font-family)',
    color: 'var(--ct-neutral-700)'
  },
  lineWrap: {
    width: '100%',
    display: 'flex',
    alignItems: 'center',
    gap: 6
  },
  dot: {
    width: 6,
    height: 6,
    borderRadius: '50%',
    background: 'var(--ct-neutral-400)'
  },
  line: {
    flex: 1,
    height: 1,
    background: 'var(--ct-neutral-350)'
  },
  priceCol: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'flex-end',
    gap: 6,
    width: 150,
    flexShrink: 0
  },
  price: {
    font: 'var(--ct-fw-semibold) 20px/28px var(--ct-font-family)',
    color: 'var(--ct-neutral-900)'
  }
};
function FlightCard({
  flight
}) {
  const {
    Card,
    Badge,
    Button
  } = window.CleartripDesignSystem_23ed32;
  const f = flight;
  return /*#__PURE__*/React.createElement(Card, {
    radius: "md",
    padding: 0,
    interactive: true,
    style: {
      marginBottom: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: flightStyles.row
  }, /*#__PURE__*/React.createElement("div", {
    style: flightStyles.airline
  }, /*#__PURE__*/React.createElement("div", {
    style: flightStyles.logo
  }, /*#__PURE__*/React.createElement("span", {
    className: "ct-icon",
    style: {
      fontSize: 20
    }
  }, "flight")), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: flightStyles.name
  }, f.airline), /*#__PURE__*/React.createElement("div", {
    style: flightStyles.code
  }, f.code))), /*#__PURE__*/React.createElement("div", {
    style: flightStyles.times
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: flightStyles.time
  }, f.dep), /*#__PURE__*/React.createElement("div", {
    style: flightStyles.city
  }, f.from)), /*#__PURE__*/React.createElement("div", {
    style: flightStyles.mid
  }, /*#__PURE__*/React.createElement("div", {
    style: flightStyles.dur
  }, f.duration), /*#__PURE__*/React.createElement("div", {
    style: flightStyles.lineWrap
  }, /*#__PURE__*/React.createElement("span", {
    style: flightStyles.dot
  }), /*#__PURE__*/React.createElement("span", {
    style: flightStyles.line
  }), /*#__PURE__*/React.createElement("span", {
    style: flightStyles.dot
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      ...flightStyles.dur,
      color: f.stops === 'Non-stop' ? 'var(--ct-success)' : 'var(--ct-neutral-700)'
    }
  }, f.stops)), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: flightStyles.time
  }, f.arr), /*#__PURE__*/React.createElement("div", {
    style: flightStyles.city
  }, f.to))), /*#__PURE__*/React.createElement("div", {
    style: flightStyles.priceCol
  }, f.tag && /*#__PURE__*/React.createElement(Badge, {
    color: f.tag === 'Cheapest' ? 'brand' : 'green',
    size: "micro"
  }, f.tag), /*#__PURE__*/React.createElement("div", {
    style: flightStyles.price
  }, "\u20B9", f.price.toLocaleString('en-IN')), /*#__PURE__*/React.createElement(Button, {
    size: "small",
    color: "primary"
  }, "View prices"))), f.note && /*#__PURE__*/React.createElement("div", {
    style: {
      borderTop: '1px dashed var(--ct-line)',
      padding: '8px 20px',
      display: 'flex',
      alignItems: 'center',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "ct-icon",
    style: {
      fontSize: 16,
      color: 'var(--ct-success)'
    }
  }, "savings"), /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--ct-fw-medium) 12px/16px var(--ct-font-family)',
      color: 'var(--ct-success)'
    }
  }, f.note)));
}
window.FlightCard = FlightCard;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/cleartrip-web/FlightCard.jsx", error: String((e && e.message) || e) }); }

// ui_kits/cleartrip-web/Screens.jsx
try { (() => {
// Cleartrip web — Home (search landing) and Results screens
const screenStyles = {
  page: {
    minHeight: '100%',
    background: 'var(--ct-surface-page)'
  },
  hero: {
    background: 'linear-gradient(180deg,#FFF4EE 0%, var(--ct-surface-page) 70%)',
    padding: '40px 32px 24px'
  },
  heroInner: {
    maxWidth: 1080,
    margin: '0 auto'
  },
  h1: {
    font: 'var(--ct-fw-semibold) 32px/40px var(--ct-font-family)',
    letterSpacing: '-0.25px',
    color: 'var(--ct-neutral-900)',
    marginBottom: 4
  },
  sub: {
    font: 'var(--ct-fw-regular) 16px/22px var(--ct-font-family)',
    color: 'var(--ct-neutral-700)',
    marginBottom: 20
  },
  section: {
    maxWidth: 1080,
    margin: '0 auto',
    padding: '24px 32px'
  },
  secTitle: {
    font: 'var(--ct-fw-semibold) 20px/28px var(--ct-font-family)',
    color: 'var(--ct-neutral-900)',
    marginBottom: 16
  },
  destGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(4,1fr)',
    gap: 16
  },
  dest: {
    borderRadius: 12,
    overflow: 'hidden',
    border: '1px solid var(--ct-line)',
    background: '#fff',
    cursor: 'pointer'
  },
  destImg: c => ({
    height: 120,
    background: c,
    display: 'flex',
    alignItems: 'flex-end',
    padding: 12
  }),
  destName: {
    font: 'var(--ct-fw-semibold) 16px/24px var(--ct-font-family)',
    color: '#fff'
  },
  destMeta: {
    padding: '10px 12px',
    font: 'var(--ct-fw-regular) 13px/18px var(--ct-font-family)',
    color: 'var(--ct-neutral-700)'
  },
  // results
  resWrap: {
    maxWidth: 1080,
    margin: '0 auto',
    padding: '20px 32px',
    display: 'flex',
    gap: 28
  },
  resMain: {
    flex: 1,
    minWidth: 0
  },
  sortBar: {
    display: 'flex',
    alignItems: 'center',
    gap: 8,
    marginBottom: 16,
    flexWrap: 'wrap'
  },
  resTitle: {
    font: 'var(--ct-fw-semibold) 18px/24px var(--ct-font-family)',
    color: 'var(--ct-neutral-900)',
    flex: 1
  }
};
const DESTS = [{
  name: 'Goa',
  meta: 'from ₹3,950',
  c: '#2A9D8F'
}, {
  name: 'Mumbai',
  meta: 'from ₹4,310',
  c: '#E76F51'
}, {
  name: 'Delhi',
  meta: 'from ₹4,880',
  c: '#264653'
}, {
  name: 'Dubai',
  meta: 'from ₹14,200',
  c: '#E9A23B'
}];
const FLIGHTS = [{
  airline: 'IndiGo',
  code: '6E 634',
  dep: '06:40',
  arr: '08:50',
  from: 'BLR',
  to: 'GOI',
  duration: '2h 10m',
  stops: 'Non-stop',
  price: 5310,
  tag: 'Cheapest',
  note: 'Earn 245 Supercoins on this booking'
}, {
  airline: 'Akasa Air',
  code: 'QP 1402',
  dep: '09:15',
  arr: '11:20',
  from: 'BLR',
  to: 'GOI',
  duration: '2h 05m',
  stops: 'Non-stop',
  price: 5499,
  tag: 'Fastest'
}, {
  airline: 'Air India',
  code: 'AI 573',
  dep: '13:30',
  arr: '17:45',
  from: 'BLR',
  to: 'GOI',
  duration: '4h 15m',
  stops: '1 stop',
  price: 4180
}, {
  airline: 'Vistara',
  code: 'UK 845',
  dep: '18:05',
  arr: '20:15',
  from: 'BLR',
  to: 'GOI',
  duration: '2h 10m',
  stops: 'Non-stop',
  price: 6740,
  note: 'Free cancellation available'
}];
function HomeScreen({
  onSearch
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: screenStyles.page
  }, /*#__PURE__*/React.createElement("div", {
    style: screenStyles.hero
  }, /*#__PURE__*/React.createElement("div", {
    style: screenStyles.heroInner
  }, /*#__PURE__*/React.createElement("div", {
    style: screenStyles.h1
  }, "Where to next?"), /*#__PURE__*/React.createElement("div", {
    style: screenStyles.sub
  }, "Search flights across every airline \u2014 pay less, earn Supercoins."), /*#__PURE__*/React.createElement(window.SearchWidget, {
    onSearch: onSearch
  }))), /*#__PURE__*/React.createElement("div", {
    style: screenStyles.section
  }, /*#__PURE__*/React.createElement("div", {
    style: screenStyles.secTitle
  }, "Popular destinations"), /*#__PURE__*/React.createElement("div", {
    style: screenStyles.destGrid
  }, DESTS.map(d => /*#__PURE__*/React.createElement("div", {
    key: d.name,
    style: screenStyles.dest
  }, /*#__PURE__*/React.createElement("div", {
    style: screenStyles.destImg(d.c)
  }, /*#__PURE__*/React.createElement("span", {
    style: screenStyles.destName
  }, d.name)), /*#__PURE__*/React.createElement("div", {
    style: screenStyles.destMeta
  }, "Flights ", d.meta))))));
}
function ResultsScreen({
  onBack
}) {
  const {
    Chip,
    Button
  } = window.CleartripDesignSystem_23ed32;
  return /*#__PURE__*/React.createElement("div", {
    style: screenStyles.page
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: '#fff',
      borderBottom: '1px solid var(--ct-line)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1080,
      margin: '0 auto',
      padding: '12px 32px',
      display: 'flex',
      alignItems: 'center',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "bare",
    color: "primary",
    size: "small",
    onClick: onBack,
    prefixIcon: /*#__PURE__*/React.createElement("span", {
      className: "ct-icon",
      style: {
        fontSize: 18
      }
    }, "arrow_back")
  }, "Modify"), /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--ct-fw-semibold) 15px/22px var(--ct-font-family)'
    }
  }, "Bengaluru \u2192 Goa"), /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--ct-fw-regular) 13px/18px var(--ct-font-family)',
      color: 'var(--ct-neutral-700)'
    }
  }, "Sat, 14 Jun \xB7 1 Adult \xB7 Economy"))), /*#__PURE__*/React.createElement("div", {
    style: screenStyles.resWrap
  }, /*#__PURE__*/React.createElement(window.FilterRail, null), /*#__PURE__*/React.createElement("div", {
    style: screenStyles.resMain
  }, /*#__PURE__*/React.createElement("div", {
    style: screenStyles.sortBar
  }, /*#__PURE__*/React.createElement("span", {
    style: screenStyles.resTitle
  }, "148 flights found"), /*#__PURE__*/React.createElement(Chip, {
    selected: true,
    icon: "sort"
  }, "Cheapest"), /*#__PURE__*/React.createElement(Chip, {
    icon: "bolt"
  }, "Fastest"), /*#__PURE__*/React.createElement(Chip, {
    icon: "schedule"
  }, "Earliest")), FLIGHTS.map((f, i) => /*#__PURE__*/React.createElement(window.FlightCard, {
    key: i,
    flight: f
  })))));
}
window.HomeScreen = HomeScreen;
window.ResultsScreen = ResultsScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/cleartrip-web/Screens.jsx", error: String((e && e.message) || e) }); }

// ui_kits/cleartrip-web/SearchWidget.jsx
try { (() => {
// Cleartrip web — flight search widget (trip type, from/to, dates, travellers)
const searchStyles = {
  card: {
    background: '#fff',
    borderRadius: 16,
    border: '1px solid var(--ct-line)',
    boxShadow: 'var(--ct-elevation-2)',
    padding: 20
  },
  tripRow: {
    display: 'flex',
    gap: 8,
    marginBottom: 16
  },
  fields: {
    display: 'grid',
    gridTemplateColumns: '1.4fr 1.4fr 1fr 1fr 1.1fr',
    gap: 1,
    background: 'var(--ct-line)',
    border: '1px solid var(--ct-line)',
    borderRadius: 12,
    overflow: 'hidden'
  },
  field: {
    background: '#fff',
    padding: '12px 16px',
    cursor: 'pointer',
    position: 'relative'
  },
  k: {
    font: 'var(--ct-fw-medium) 11px/16px var(--ct-font-family)',
    color: 'var(--ct-neutral-700)',
    textTransform: 'uppercase',
    letterSpacing: '.4px'
  },
  v: {
    font: 'var(--ct-fw-semibold) 20px/28px var(--ct-font-family)',
    color: 'var(--ct-neutral-900)',
    marginTop: 2
  },
  sub: {
    font: 'var(--ct-fw-regular) 12px/16px var(--ct-font-family)',
    color: 'var(--ct-neutral-700)'
  },
  swap: {
    position: 'absolute',
    right: -13,
    top: '50%',
    transform: 'translateY(-50%)',
    zIndex: 2,
    width: 26,
    height: 26,
    borderRadius: '50%',
    background: '#fff',
    border: '1px solid var(--ct-line)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    cursor: 'pointer'
  },
  actions: {
    display: 'flex',
    justifyContent: 'flex-end',
    marginTop: 16
  }
};
function SearchWidget({
  onSearch
}) {
  const {
    Chip,
    Button
  } = window.CleartripDesignSystem_23ed32;
  const [trip, setTrip] = React.useState('oneway');
  return /*#__PURE__*/React.createElement("div", {
    style: searchStyles.card
  }, /*#__PURE__*/React.createElement("div", {
    style: searchStyles.tripRow
  }, /*#__PURE__*/React.createElement(Chip, {
    selected: trip === 'oneway',
    onClick: () => setTrip('oneway')
  }, "One way"), /*#__PURE__*/React.createElement(Chip, {
    selected: trip === 'round',
    onClick: () => setTrip('round')
  }, "Round trip"), /*#__PURE__*/React.createElement(Chip, {
    selected: trip === 'multi',
    onClick: () => setTrip('multi')
  }, "Multi-city")), /*#__PURE__*/React.createElement("div", {
    style: searchStyles.fields
  }, /*#__PURE__*/React.createElement("div", {
    style: searchStyles.field
  }, /*#__PURE__*/React.createElement("div", {
    style: searchStyles.k
  }, "From"), /*#__PURE__*/React.createElement("div", {
    style: searchStyles.v
  }, "Bengaluru"), /*#__PURE__*/React.createElement("div", {
    style: searchStyles.sub
  }, "BLR \xB7 Kempegowda Intl"), /*#__PURE__*/React.createElement("div", {
    style: searchStyles.swap
  }, /*#__PURE__*/React.createElement("span", {
    className: "ct-icon",
    style: {
      fontSize: 16
    }
  }, "swap_horiz"))), /*#__PURE__*/React.createElement("div", {
    style: searchStyles.field
  }, /*#__PURE__*/React.createElement("div", {
    style: searchStyles.k
  }, "To"), /*#__PURE__*/React.createElement("div", {
    style: searchStyles.v
  }, "Goa"), /*#__PURE__*/React.createElement("div", {
    style: searchStyles.sub
  }, "GOI \xB7 Dabolim")), /*#__PURE__*/React.createElement("div", {
    style: searchStyles.field
  }, /*#__PURE__*/React.createElement("div", {
    style: searchStyles.k
  }, "Departure"), /*#__PURE__*/React.createElement("div", {
    style: searchStyles.v
  }, "14 Jun"), /*#__PURE__*/React.createElement("div", {
    style: searchStyles.sub
  }, "Saturday")), /*#__PURE__*/React.createElement("div", {
    style: {
      ...searchStyles.field,
      opacity: trip === 'round' ? 1 : 0.5
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: searchStyles.k
  }, "Return"), /*#__PURE__*/React.createElement("div", {
    style: searchStyles.v
  }, trip === 'round' ? '21 Jun' : 'Add'), /*#__PURE__*/React.createElement("div", {
    style: searchStyles.sub
  }, trip === 'round' ? 'Saturday' : 'Save more on round trips')), /*#__PURE__*/React.createElement("div", {
    style: searchStyles.field
  }, /*#__PURE__*/React.createElement("div", {
    style: searchStyles.k
  }, "Travellers & class"), /*#__PURE__*/React.createElement("div", {
    style: searchStyles.v
  }, "1 Adult"), /*#__PURE__*/React.createElement("div", {
    style: searchStyles.sub
  }, "Economy"))), /*#__PURE__*/React.createElement("div", {
    style: searchStyles.actions
  }, /*#__PURE__*/React.createElement(Button, {
    color: "secondary",
    size: "large",
    onClick: onSearch,
    prefixIcon: /*#__PURE__*/React.createElement("span", {
      className: "ct-icon",
      style: {
        fontSize: 20
      }
    }, "search")
  }, "Search flights")));
}
window.SearchWidget = SearchWidget;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/cleartrip-web/SearchWidget.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Button = __ds_scope.Button;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.Chip = __ds_scope.Chip;

__ds_ns.AlertCallout = __ds_scope.AlertCallout;

__ds_ns.Tabs = __ds_scope.Tabs;

__ds_ns.Toast = __ds_scope.Toast;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Radio = __ds_scope.Radio;

__ds_ns.Switch = __ds_scope.Switch;

})();
