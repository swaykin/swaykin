# Cleartrip Design System

A faithful, HTML/CSS/React recreation of **Cleartrip's** product design language — the brand orange, the ink-black UI, the 8px grid, the pill chips and hairline cards that power Cleartrip's flights, hotels, trains and activities booking flows.

Cleartrip is one of India's largest online travel aggregators (a Flipkart company). Its interfaces are dense, conversion-focused and trustworthy: lots of structured data (prices, times, fares, filters) presented calmly on white surfaces with a single hot brand accent reserved for the moments that matter.

---

## Sources

This system was reverse-engineered from Cleartrip's **production component library** (React + Emotion monorepo), mounted read-only at:

- `ct-design-system/` — pnpm/turbo monorepo, package `@cleartrip/ct-design-components`
  - `packages/core/tokens/src/token/global/*.ts` — colour, typography, spacing, size, border, elevation tokens (**source of truth** for this system's tokens)
  - `packages/core/theme/src/themes/*` — `BaseTheme` / `B2CTheme` semantic aliases (B2C = consumer)
  - `packages/components/*` — \~100 Emotion components (Button, Badge, Chip, Card, Field, Typography, Toast, …)
  - `packages/assets/icons/src/*.tsx` — icon set (CT logo, Supercoin, Material-Symbols-derived UI icons)
  - `out/` — a built Storybook (consumer-facing reference; not read in detail)

The theme system ships **four themes** (`B2C`, `B2B`, `SM`, `UltraFk`) wrapped via an Emotion `ThemeProvider`. This design system models the **B2C** (consumer) theme, which is the default and the one behind cleartrip.com.

> Reader does not need access to the above — values have been copied into `tokens/`.

---

## Index (manifest)

| Path | What |
| --- | --- |
| `styles.css` | Global entry point — `@import`s all tokens. **Consumers link this.** |
| `tokens/colors.css` | Full palette + B2C semantic aliases (`--ct-text-*`, `--ct-surface-*`, `--ct-btn-*`) |
| `tokens/typography.css` | Weight/size ramps + `.ct-hd1…ct-tag` variant classes |
| `tokens/fonts.css` | Webfont (Hanken Grotesk — **substitution, see Visual Foundations**) |
| `tokens/spacing.css` | 4px-base spacing + control heights |
| `tokens/radius.css` | Corner radii + border widths |
| `tokens/elevation.css` | Shadow ramp (bottom/top cast + modal) |
| `tokens/base.css` | Resets + `.ct-icon` (Material Symbols Rounded) helper |
| `assets/` | CT logo (orange/white/black), collapsed mark, Supercoin |
| `components/core/` | Button, IconButton, Badge, Chip, Card, Input, Checkbox, Radio, Switch, Toast, Tabs |
| `guidelines/` | Foundation specimen cards (Type, Colors, Spacing, Brand) |
| `ui_kits/cleartrip-web/` | Click-through flight search → results recreation |
| `templates/flights-search/` | Reusable **template** (`FlightsSearch.dc.html`) — flights search landing seed |
| `SKILL.md` | Agent-Skill manifest for downstream use |

**Components** (`window.CleartripDesignSystem_23ed32`): `Button`, `IconButton`, `Input`, `Checkbox`, `Radio`, `Switch`, `Badge`, `Chip`, `Card`, `Toast`, `AlertCallout`, `Tabs`. Foundation specimen cards populate the Design System tab under groups **Type · Colors · Spacing · Brand · Components · Cleartrip Web**.

---

## CONTENT FUNDAMENTALS

How Cleartrip writes. The voice is **plain, efficient and reassuring** — it respects that booking travel is a high-stakes, money-on-the-line task.

- **Tone:** practical and direct, never playful-for-its-own-sake. Copy answers the traveller's next question ("When does check-in open?", "Is this refundable?").
- **Person:** speaks to "you"; refers to itself rarely. Imperative for actions ("Search flights", "Add traveller", "Apply coupon"). Status in plain past/present ("Booking confirmed", "Price dropped").
- **Casing:** **Sentence case** everywhere — headings, buttons, labels, menu items ("Search flights", not "Search Flights"). UPPERCASE is reserved for tiny eyebrow tags/overlines (B3CAPS / B4CAPS) like `NON-STOP`, `CHEAPEST`, `BEST`.
- **Numbers & money:** Indian formatting — `₹4,899`, `₹12,450`. Prices are the loudest data on the screen. Durations as `2h 15m`, times as `06:40`, dates as `Sat, 14 Jun`.
- **Microcopy patterns:** scarcity/value nudges in muted tones ("Only 3 seats left", "Filtered by cheapest", "Free cancellation"), benefit badges ("Earn 245 Supercoins").
- **Emoji:** **not used** in product UI. Iconography carries meaning instead.
- **Vibe:** confident discount-era OTA — value-forward ("Save more", coupon-led) but clean and modern, not cluttered. The orange does the shouting; the words stay calm.

Examples: `Search flights` · `1 traveller, Economy` · `Non-stop · 2h 10m` · `₹5,310` · `Free cancellation available` · `Login to unlock member prices`.

---

## VISUAL FOUNDATIONS

**Color.** A near-monochrome canvas with one hot accent.

- Ink (`--ct-neutral-900` `#1A1A1A`) is the primary text colour **and** the primary button fill — Cleartrip's signature: the most-emphasised CTA is black, not orange.
- **Brand orange `#FF4F17`** is used sparingly: the logo, the *secondary* contained button, selected/active accents, price-drop and deal moments, links to offers. It is a spotlight, never a wash.
- Backgrounds are white (`#FFFFFF`) cards on a faint off-white page (`#FAFAFD`).
- Semantic colours are muted: success green `#11A670`, error red `#C83232`, alert amber `#DF9641`, info/link blue `#0F6BFF`, each with a soft tinted surface for callouts.
- Decorative accents (pink, purple, curacao, margarita greens) appear only in badges, loyalty and illustration contexts.

**Type.** Clean humanist grotesque. Three weights do the work: **regular (400)** for running paragraph text, **medium (500)** for body/UI workhorse text, **semibold (600)** for every heading, label and button. Bold (700) is rare. Display sizes 32–48px are tightly tracked (negative letter-spacing); body/label sizes track at zero; tiny CAPS tags track positive (+0.4px). Line-heights are generous relative to size for legibility of dense data.

**Spacing.** Strict **4px base, 8px rhythm**. Component padding is almost always 8/12/16; section gaps 16/24/32. Controls snap to fixed heights: 32 (small) / 40 (default) / 48 (large) buttons, 56 text fields.

**Backgrounds & imagery.** No gradients in chrome (the only gradients are inside loyalty badges). No textures or patterns. Destination/marketing imagery is full-colour photography (warm, aspirational travel shots) placed in rounded-corner cards or hero bands; product screens themselves are flat white. Photography is bright and saturated, not desaturated or grainy.

**Corners & cards.** Cards: 8px radius default (6 small, 12 large, 16 sheets), a **1px `#E7E7E7` hairline border** and usually **no shadow at rest**. Elevation appears on lift: resting popovers/hover at `0 4px 16px rgba(26,26,26,.08)`, dialogs at `0 10px 32px rgba(26,26,26,.2)`. Buttons & fields: 8px radius. **Chips & filter pills: fully rounded (pill).** Badges: 4px.

**Borders.** Hairlines everywhere (`#E7E7E7` dividers, `#F3F3F3` softer fills). Inputs use a 1px disabled-grey border that thickens to 1.5px ink on focus, 1.5px red on error. Selected chips get a 1.5px ink border + grey fill; unselected get a 1px grey border.

**Motion.** Restrained and functional. Easing `cubic-bezier(0.4, 0, 0.2, 1)` (standard), durations \~150–300ms (enter 225ms, leave 195ms). Fades and slides for sheets/toasts; no bounces, no decorative looping animation. Reduced-motion friendly.

**States.**

- *Hover:* contained-secondary (orange) darkens to `#CE4501`; links darken; cards may lift one elevation step. No scale-up.
- *Press/active:* selection state (border + fill) rather than transforms.
- *Focus:* 1.5px ink border on fields; keyboard focus ring on interactive elements.
- *Disabled:* `#F3F3F3` fill, `#B3B3B3` text, no border.

**Transparency & blur.** Used sparingly — modal scrims (`rgba(26,26,26,.5)`) and the occasional `rgba(255,255,255,.2)` highlight on dark surfaces (e.g. side-nav selected tab). No frosted-glass blur in core UI.

---

## ICONOGRAPHY

Cleartrip's UI iconography is **Google Material Symbols (Rounded)**. Evidence in the codebase is unambiguous: the bundled UI icons (`back`, `calendarMonth`, `dustbin`, `hidden`, `errorCalloutIcon`, …) are exported as the exact Material pattern — a 24×24 `viewBox`, a `#D9D9D9` alpha `<mask>` rect, and the canonical Material path geometry, tinted to `#1A1A1A` (ink) or a semantic colour. Stroke-style line icons (chevrons, swap, counters) appear at 1.5–2px weight for compact controls.

**How this system handles icons:**

- **UI icons → Material Symbols Rounded from CDN.** `tokens/base.css` loads the font and exposes `.ct-icon` (add `.fill` for filled). Use ligatures, e.g. `<span class="ct-icon">search</span>`, `flight`, `hotel`, `train`, `calendar_month`, `swap_horiz`, `chevron_right`, `close`, `add`, `remove`, `person`, `star`.
- **Brand / proprietary marks → copied SVGs** in `assets/`:
  - `cleartrip-logo.svg` (+ `-white`, `-black`) — full wordmark with the swoosh checkmark, brand orange `#FF4F17`.
  - `cleartrip-mark.svg` (+ `-white`) — collapsed app-icon mark.
  - `supercoin.svg` — the Supercoins loyalty currency coin (gold).
- **Emoji:** never used.
- **Unicode glyphs as icons:** not used; ligature icon font or SVG only.

> Substitution flag: Material Symbols Rounded is the genuine system Cleartrip uses, so this is a faithful match rather than an approximation. The few stroke icons (swap, counter +/−) are represented by their Material equivalents (`swap_horiz`, `add`, `remove`).
