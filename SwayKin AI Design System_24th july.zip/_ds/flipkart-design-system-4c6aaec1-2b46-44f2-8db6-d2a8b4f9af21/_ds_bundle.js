/* @ds-bundle: {"format":3,"namespace":"FlipkartDesignSystem_4c6aae","components":[{"name":"PriceBlock","sourcePath":"components/commerce/PriceBlock.jsx"},{"name":"ProductCard","sourcePath":"components/commerce/ProductCard.jsx"},{"name":"QuantityStepper","sourcePath":"components/commerce/QuantityStepper.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Divider","sourcePath":"components/core/Divider.jsx"},{"name":"Avatar","sourcePath":"components/data-display/Avatar.jsx"},{"name":"Chip","sourcePath":"components/data-display/Chip.jsx"},{"name":"Rating","sourcePath":"components/data-display/Rating.jsx"},{"name":"Tag","sourcePath":"components/data-display/Tag.jsx"},{"name":"Badge","sourcePath":"components/feedback/Badge.jsx"},{"name":"BottomSheet","sourcePath":"components/feedback/BottomSheet.jsx"},{"name":"Snackbar","sourcePath":"components/feedback/Snackbar.jsx"},{"name":"Tooltip","sourcePath":"components/feedback/Tooltip.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"Radio","sourcePath":"components/forms/Radio.jsx"},{"name":"TextField","sourcePath":"components/forms/TextField.jsx"},{"name":"BottomNav","sourcePath":"components/navigation/BottomNav.jsx"},{"name":"SearchBar","sourcePath":"components/navigation/SearchBar.jsx"},{"name":"Tabs","sourcePath":"components/navigation/Tabs.jsx"}],"sourceHashes":{"components/commerce/PriceBlock.jsx":"4b7766985ae3","components/commerce/ProductCard.jsx":"3c3d29b33676","components/commerce/QuantityStepper.jsx":"ec9f093c9fb5","components/core/Button.jsx":"50d9f59c201b","components/core/Divider.jsx":"46b456ecf2cd","components/data-display/Avatar.jsx":"729186b0e72e","components/data-display/Chip.jsx":"0cae1c40af32","components/data-display/Rating.jsx":"35ba1e564f4a","components/data-display/Tag.jsx":"cc751d0c93fe","components/feedback/Badge.jsx":"3222b2f6c890","components/feedback/BottomSheet.jsx":"ef897b2d8fc6","components/feedback/Snackbar.jsx":"2b6b1487d64e","components/feedback/Tooltip.jsx":"253669961817","components/forms/Checkbox.jsx":"dc6361266d4f","components/forms/Radio.jsx":"fc3b4001ca6b","components/forms/TextField.jsx":"610c5d537086","components/navigation/BottomNav.jsx":"af37696d5873","components/navigation/SearchBar.jsx":"1b79134d61ff","components/navigation/Tabs.jsx":"49a2a1f2f70a","ui_kits/flipkart-app/data.js":"12f8cc330681","ui_kits/flipkart-app/screens.jsx":"24d493a775ca"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.FlipkartDesignSystem_4c6aae = window.FlipkartDesignSystem_4c6aae || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/commerce/PriceBlock.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Flipkart DLS price block — final price, struck MRP, and green discount %. */
function PriceBlock({
  price,
  mrp,
  size = "medium",
  currency = "₹",
  style,
  ...rest
}) {
  const fmt = n => typeof n === "number" ? n.toLocaleString("en-IN") : n;
  const off = typeof price === "number" && typeof mrp === "number" && mrp > price ? Math.round((1 - price / mrp) * 100) : null;
  const big = size === "large" ? 22 : size === "small" ? 14 : 18;
  const small = size === "large" ? 14 : 12;
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: "inline-flex",
      alignItems: "baseline",
      gap: 8,
      flexWrap: "wrap",
      fontFamily: "var(--font-sans, Inter, sans-serif)",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: big,
      fontWeight: 700,
      color: "var(--text-strong-primary, #333)"
    }
  }, currency, fmt(price)), mrp != null && off ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: small,
      color: "var(--neutral-light-solid-600, #969595)",
      textDecoration: "line-through"
    }
  }, currency, fmt(mrp)) : null, off ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: small,
      fontWeight: 700,
      color: "var(--green-700, #008042)"
    }
  }, off, "% off") : null);
}
Object.assign(__ds_scope, { PriceBlock });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/commerce/PriceBlock.jsx", error: String((e && e.message) || e) }); }

// components/commerce/QuantityStepper.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Flipkart DLS quantity stepper (− value +), used in cart & quick-commerce. */
function QuantityStepper({
  value = 1,
  min = 1,
  max = 99,
  onChange,
  size = "medium",
  style,
  ...rest
}) {
  const [internal, setInternal] = React.useState(value);
  const v = onChange ? value : internal;
  const set = next => {
    const c = Math.max(min, Math.min(max, next));
    if (onChange) onChange(c);else setInternal(c);
  };
  const h = size === "small" ? 28 : 36;
  const fs = size === "small" ? 12 : 14;
  const btn = {
    appearance: "none",
    border: "none",
    background: "transparent",
    cursor: "pointer",
    width: h,
    height: h,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    color: "var(--blue-600, #1162F2)",
    fontSize: fs + 4
  };
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: "inline-flex",
      alignItems: "center",
      borderRadius: "calc(var(--cr2, 4) * 1px)",
      boxShadow: "inset 0 0 0 1.2px var(--blue-600, #1162F2)",
      fontFamily: "var(--font-sans, Inter, sans-serif)",
      overflow: "hidden",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("button", {
    type: "button",
    style: {
      ...btn,
      opacity: v <= min ? 0.4 : 1
    },
    onClick: () => set(v - 1),
    "aria-label": "decrease"
  }, /*#__PURE__*/React.createElement("i", {
    className: "ph-bold ph-minus"
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      minWidth: h,
      textAlign: "center",
      fontSize: fs,
      fontWeight: 700,
      color: "var(--text-strong-primary, #333)"
    }
  }, v), /*#__PURE__*/React.createElement("button", {
    type: "button",
    style: {
      ...btn,
      opacity: v >= max ? 0.4 : 1
    },
    onClick: () => set(v + 1),
    "aria-label": "increase"
  }, /*#__PURE__*/React.createElement("i", {
    className: "ph-bold ph-plus"
  })));
}
Object.assign(__ds_scope, { QuantityStepper });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/commerce/QuantityStepper.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Flipkart DLS Button.
 * Hierarchy: primary (yellow), secondary (blue), tertiary (blue outline), quaternary (neutral outline).
 * Sizes: large / medium / small. Optional leading/trailing Phosphor icon, full-width, loading & disabled states.
 */
function Button({
  children,
  hierarchy = "primary",
  size = "large",
  icon,
  // phosphor class name e.g. "ph-shopping-cart-simple"
  iconPosition = "left",
  fullWidth = false,
  loading = false,
  disabled = false,
  type = "button",
  onClick,
  style,
  ...rest
}) {
  const sizes = {
    large: {
      height: 48,
      radius: "var(--cr5, 12)",
      font: "var(--font-size-body, 14)",
      line: 18,
      padX: 24,
      icon: 18
    },
    medium: {
      height: 38,
      radius: "var(--cr4, 8)",
      font: "var(--font-size-body, 14)",
      line: 18,
      padX: 20,
      icon: 16
    },
    small: {
      height: 30,
      radius: "var(--cr4, 8)",
      font: "var(--font-size-subtext, 12)",
      line: 16,
      padX: 16,
      icon: 14
    }
  };
  const s = sizes[size] || sizes.large;
  const hierarchies = {
    primary: {
      background: "linear-gradient(90deg, var(--yellow-300, #FFE51F) 0%, var(--yellow-400, #FFCD03) 100%)",
      color: "var(--text-strong-primary, #333)",
      boxShadow: "none"
    },
    secondary: {
      background: "linear-gradient(90deg, var(--blue-600, #1162F2) 0%, var(--blue-700, #1152E0) 100%)",
      color: "#fff",
      boxShadow: "none"
    },
    tertiary: {
      background: "var(--neutral-light-solid-00, #fff)",
      color: "var(--blue-600, #1162F2)",
      boxShadow: "inset 0 0 0 1px var(--blue-400, #2EA1FF)"
    },
    quaternary: {
      background: "var(--neutral-light-solid-00, #fff)",
      color: "var(--text-strong-primary, #333)",
      boxShadow: "inset 0 0 0 1px var(--neutral-light-solid-300, #D6D6D6)"
    }
  };
  const h = hierarchies[hierarchy] || hierarchies.primary;
  const isDisabled = disabled || loading;
  const base = {
    appearance: "none",
    border: "none",
    fontFamily: "var(--font-sans, Inter, sans-serif)",
    fontWeight: 700,
    fontSize: `calc(${s.font} * 1px)`,
    lineHeight: `${s.line}px`,
    height: s.height,
    minWidth: s.height,
    padding: `0 ${s.padX}px`,
    borderRadius: `calc(${s.radius} * 1px)`,
    display: fullWidth ? "flex" : "inline-flex",
    width: fullWidth ? "100%" : undefined,
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    cursor: isDisabled ? "not-allowed" : "pointer",
    whiteSpace: "nowrap",
    boxSizing: "border-box",
    transition: "filter .15s ease, transform .08s ease, opacity .15s ease",
    background: h.background,
    color: h.color,
    boxShadow: h.boxShadow,
    ...(isDisabled && {
      background: "var(--neutral-light-solid-100, #F0F0F0)",
      color: "var(--neutral-light-solid-400, #C0C0C0)",
      boxShadow: hierarchy === "tertiary" || hierarchy === "quaternary" ? "inset 0 0 0 1px var(--neutral-light-solid-200, #E0E0E0)" : "none"
    }),
    ...style
  };
  const iconEl = icon && !loading ? /*#__PURE__*/React.createElement("i", {
    className: `ph-bold ${icon}`,
    style: {
      fontSize: s.icon,
      lineHeight: 1
    },
    "aria-hidden": "true"
  }) : null;
  return /*#__PURE__*/React.createElement("button", _extends({
    type: type,
    disabled: isDisabled,
    onClick: onClick,
    style: base,
    onMouseDown: e => !isDisabled && (e.currentTarget.style.transform = "scale(0.98)"),
    onMouseUp: e => e.currentTarget.style.transform = "scale(1)",
    onMouseEnter: e => !isDisabled && (e.currentTarget.style.filter = "brightness(0.94)"),
    onMouseLeave: e => {
      e.currentTarget.style.filter = "none";
      e.currentTarget.style.transform = "scale(1)";
    }
  }, rest), loading && /*#__PURE__*/React.createElement("span", {
    "aria-label": "loading",
    style: {
      width: s.icon,
      height: s.icon,
      borderRadius: "50%",
      border: `2px solid ${hierarchy === "secondary" ? "rgba(255,255,255,.4)" : "rgba(51,51,51,.25)"}`,
      borderTopColor: "currentColor",
      display: "inline-block",
      animation: "fk-spin .7s linear infinite"
    }
  }), iconPosition === "left" && iconEl, children && /*#__PURE__*/React.createElement("span", null, children), iconPosition === "right" && iconEl, /*#__PURE__*/React.createElement("style", null, "@keyframes fk-spin{to{transform:rotate(360deg)}}"));
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Divider.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Flipkart DLS separator — thin neutral rule. Horizontal or vertical, with optional inset. */
function Divider({
  orientation = "horizontal",
  inset = 0,
  color = "var(--neutral-light-solid-200, #E0E0E0)",
  style,
  ...rest
}) {
  if (orientation === "vertical") {
    return /*#__PURE__*/React.createElement("span", _extends({
      role: "separator",
      "aria-orientation": "vertical",
      style: {
        display: "inline-block",
        width: 1,
        alignSelf: "stretch",
        background: color,
        margin: `${inset}px 0`,
        ...style
      }
    }, rest));
  }
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "separator",
    style: {
      height: 1,
      background: color,
      margin: `0 ${inset}px`,
      ...style
    }
  }, rest));
}
Object.assign(__ds_scope, { Divider });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Divider.jsx", error: String((e && e.message) || e) }); }

// components/data-display/Avatar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Flipkart DLS avatar — circular image or initials, brand-tinted fallback. */
function Avatar({
  src,
  name = "",
  size = 40,
  style,
  ...rest
}) {
  const initials = name.split(" ").map(n => n[0]).filter(Boolean).slice(0, 2).join("").toUpperCase();
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      width: size,
      height: size,
      borderRadius: "50%",
      overflow: "hidden",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      background: "var(--blue-50, #EEF7FF)",
      color: "var(--blue-700, #1152E0)",
      fontFamily: "var(--font-sans, Inter, sans-serif)",
      fontWeight: 700,
      fontSize: size * 0.4,
      flexShrink: 0,
      ...style
    }
  }, rest), src ? /*#__PURE__*/React.createElement("img", {
    src: src,
    alt: name,
    style: {
      width: "100%",
      height: "100%",
      objectFit: "cover"
    }
  }) : initials);
}
Object.assign(__ds_scope, { Avatar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-display/Avatar.jsx", error: String((e && e.message) || e) }); }

// components/data-display/Chip.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Flipkart DLS filter chip / pill. White by default with a 1.2px neutral border;
 * selected state fills brand blue (single-select) or neutral grey (multi-select).
 */
function Chip({
  children,
  selected = false,
  selectMode = "single",
  icon,
  onClear,
  onClick,
  disabled = false,
  style,
  ...rest
}) {
  const fill = selected ? selectMode === "single" ? {
    background: "var(--blue-600, #1162F2)",
    color: "#fff",
    boxShadow: "none"
  } : {
    background: "var(--neutral-light-solid-200, #E0E0E0)",
    color: "var(--text-strong-primary, #333)",
    boxShadow: "none"
  } : {
    background: "var(--neutral-light-solid-00, #fff)",
    color: "var(--text-strong-primary, #333)",
    boxShadow: "inset 0 0 0 1.2px var(--neutral-light-solid-300, #D6D6D6)"
  };
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    onClick: onClick,
    disabled: disabled,
    style: {
      appearance: "none",
      border: "none",
      cursor: disabled ? "not-allowed" : "pointer",
      fontFamily: "var(--font-sans, Inter, sans-serif)",
      fontSize: "calc(var(--font-size-subtext, 12) * 1px)",
      fontWeight: 500,
      display: "inline-flex",
      alignItems: "center",
      gap: 6,
      height: 32,
      padding: "0 12px",
      borderRadius: "calc(var(--cr4, 8) * 1px)",
      opacity: disabled ? 0.5 : 1,
      transition: "background .12s ease, box-shadow .12s ease",
      ...fill,
      ...style
    }
  }, rest), icon && /*#__PURE__*/React.createElement("i", {
    className: `ph ${icon}`,
    style: {
      fontSize: 16
    },
    "aria-hidden": "true"
  }), children, onClear && /*#__PURE__*/React.createElement("i", {
    className: "ph-bold ph-x",
    onClick: e => {
      e.stopPropagation();
      onClear(e);
    },
    style: {
      fontSize: 13,
      marginLeft: 2,
      opacity: 0.7
    },
    "aria-hidden": "true"
  }));
}
Object.assign(__ds_scope, { Chip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-display/Chip.jsx", error: String((e && e.message) || e) }); }

// components/data-display/Rating.jsx
try { (() => {
/**
 * Flipkart's signature rating chip. The green pill (value + star) is one of the
 * most recognizable Flipkart UI elements, shown on every product card.
 */
function Rating({
  value = 4.1,
  count,
  size = "medium",
  variant = "filled",
  style
}) {
  const sizes = {
    small: {
      font: 11,
      star: 11,
      padX: 6,
      padY: 3,
      gap: 3,
      radius: "var(--cr2, 4)"
    },
    medium: {
      font: 12,
      star: 12,
      padX: 7,
      padY: 3,
      gap: 3,
      radius: "var(--cr2, 4)"
    },
    large: {
      font: 14,
      star: 14,
      padX: 9,
      padY: 4,
      gap: 4,
      radius: "var(--cr3, 6)"
    }
  };
  const s = sizes[size] || sizes.medium;
  const variants = {
    filled: {
      background: "var(--green-700, #008042)",
      color: "#fff",
      starColor: "#fff"
    },
    grey: {
      background: "var(--neutral-light-solid-50, #F5F5F5)",
      color: "var(--text-strong-primary, #333)",
      starColor: "var(--green-700, #008042)"
    },
    none: {
      background: "transparent",
      color: "var(--text-strong-primary, #333)",
      starColor: "var(--green-700, #008042)"
    }
  };
  const v = variants[variant] || variants.filled;
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6,
      fontFamily: "var(--font-sans, Inter, sans-serif)",
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: s.gap,
      background: v.background,
      color: v.color,
      padding: `${s.padY}px ${s.padX}px`,
      borderRadius: `calc(${s.radius} * 1px)`,
      fontSize: s.font,
      fontWeight: 700,
      lineHeight: 1
    }
  }, value, /*#__PURE__*/React.createElement("i", {
    className: "ph-fill ph-star",
    style: {
      fontSize: s.star,
      color: v.starColor
    },
    "aria-hidden": "true"
  })), count != null && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: s.font,
      fontWeight: 500,
      color: "var(--neutral-light-solid-600, #969595)"
    }
  }, "(", typeof count === "number" ? count.toLocaleString("en-IN") : count, ")"));
}
Object.assign(__ds_scope, { Rating });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-display/Rating.jsx", error: String((e && e.message) || e) }); }

// components/data-display/Tag.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Flipkart DLS tag / label — merchandising labels like "70% off", "Assured",
 * "Bestseller", "Sponsored". Tones map to the semantic colour palette.
 */
function Tag({
  children,
  tone = "neutral",
  icon,
  size = "medium",
  style,
  ...rest
}) {
  const tones = {
    neutral: {
      bg: "var(--neutral-light-solid-50, #F5F5F5)",
      fg: "var(--text-strong-secondary, #555)"
    },
    success: {
      bg: "var(--green-50, #E7FBF0)",
      fg: "var(--green-700, #008042)"
    },
    error: {
      bg: "var(--red-50, #FFF3F2)",
      fg: "var(--red-700, #C60424)"
    },
    warning: {
      bg: "var(--orange-100, #FFE9CC)",
      fg: "var(--orange-700, #B25600)"
    },
    info: {
      bg: "var(--blue-50, #EEF7FF)",
      fg: "var(--blue-700, #1152E0)"
    },
    /** Flipkart Assured-style brand tag. */
    brand: {
      bg: "var(--blue-600, #1162F2)",
      fg: "#fff"
    },
    /** discount green used on price savings. */
    discount: {
      bg: "transparent",
      fg: "var(--green-700, #008042)"
    }
  };
  const t = tones[tone] || tones.neutral;
  const fs = size === "small" ? 10 : 11;
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 4,
      fontFamily: "var(--font-sans, Inter, sans-serif)",
      fontSize: fs,
      fontWeight: 700,
      letterSpacing: ".01em",
      lineHeight: 1,
      padding: tone === "discount" ? "0" : "4px 6px",
      borderRadius: "calc(var(--cr2, 4) * 1px)",
      background: t.bg,
      color: t.fg,
      textTransform: "none",
      ...style
    }
  }, rest), icon && /*#__PURE__*/React.createElement("i", {
    className: `ph-fill ${icon}`,
    style: {
      fontSize: fs + 2
    },
    "aria-hidden": "true"
  }), children);
}
Object.assign(__ds_scope, { Tag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-display/Tag.jsx", error: String((e && e.message) || e) }); }

// components/commerce/ProductCard.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Flipkart DLS product card — image, title, rating chip, price block,
 * optional Assured tag and wishlist toggle. The core merchandising unit.
 */
function ProductCard({
  image,
  imageNode,
  title,
  brand,
  price,
  mrp,
  rating,
  ratingCount,
  assured = false,
  sponsored = false,
  wishlisted = false,
  onWishlist,
  onClick,
  style,
  ...rest
}) {
  const [wish, setWish] = React.useState(wishlisted);
  const toggle = e => {
    e.stopPropagation();
    const n = !wish;
    setWish(n);
    onWishlist && onWishlist(n);
  };
  return /*#__PURE__*/React.createElement("div", _extends({
    onClick: onClick,
    style: {
      width: 220,
      background: "var(--neutral-light-solid-00, #fff)",
      borderRadius: "calc(var(--cr4, 8) * 1px)",
      boxShadow: "0 1px 3px rgba(0,0,0,.08), 0 0 0 1px rgba(0,0,0,.04)",
      fontFamily: "var(--font-sans, Inter, sans-serif)",
      overflow: "hidden",
      cursor: onClick ? "pointer" : "default",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      aspectRatio: "1 / 1",
      background: "var(--neutral-light-solid-50, #F5F5F5)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center"
    }
  }, imageNode ? imageNode : image ? /*#__PURE__*/React.createElement("img", {
    src: image,
    alt: title,
    style: {
      width: "100%",
      height: "100%",
      objectFit: "contain",
      padding: 12,
      boxSizing: "border-box"
    }
  }) : /*#__PURE__*/React.createElement("i", {
    className: "ph ph-image",
    style: {
      fontSize: 40,
      color: "var(--neutral-light-solid-400, #C0C0C0)"
    }
  }), /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: toggle,
    "aria-label": "wishlist",
    style: {
      position: "absolute",
      top: 8,
      right: 8,
      width: 32,
      height: 32,
      borderRadius: "50%",
      background: "rgba(255,255,255,.92)",
      border: "none",
      boxShadow: "0 1px 4px rgba(0,0,0,.16)",
      cursor: "pointer",
      display: "flex",
      alignItems: "center",
      justifyContent: "center"
    }
  }, /*#__PURE__*/React.createElement("i", {
    className: `${wish ? "ph-fill" : "ph"} ph-heart`,
    style: {
      fontSize: 18,
      color: wish ? "var(--red-600, #E3122E)" : "var(--neutral-light-solid-600, #969595)"
    }
  })), sponsored && /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      bottom: 8,
      left: 8
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Tag, {
    tone: "neutral",
    size: "small"
  }, "Ad"))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 12,
      display: "flex",
      flexDirection: "column",
      gap: 6
    }
  }, brand && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      fontWeight: 600,
      color: "var(--neutral-light-solid-600, #969595)"
    }
  }, brand), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: "calc(var(--font-size-body, 14) * 1px)",
      fontWeight: 500,
      color: "var(--text-strong-primary, #333)",
      lineHeight: 1.35,
      display: "-webkit-box",
      WebkitLineClamp: 2,
      WebkitBoxOrient: "vertical",
      overflow: "hidden"
    }
  }, title), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8
    }
  }, rating != null && /*#__PURE__*/React.createElement(__ds_scope.Rating, {
    value: rating,
    count: ratingCount,
    size: "small"
  }), assured && /*#__PURE__*/React.createElement(__ds_scope.Tag, {
    tone: "brand",
    icon: "ph-seal-check",
    size: "small"
  }, "Assured")), /*#__PURE__*/React.createElement(__ds_scope.PriceBlock, {
    price: price,
    mrp: mrp
  })));
}
Object.assign(__ds_scope, { ProductCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/commerce/ProductCard.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Flipkart DLS notification badge — red count pill or dot, positioned on a child (e.g. cart icon). */
function Badge({
  count,
  max = 99,
  dot = false,
  tone = "error",
  children,
  style,
  ...rest
}) {
  const tones = {
    error: "var(--red-600, #E3122E)",
    brand: "var(--blue-600, #1162F2)",
    success: "var(--green-700, #008042)"
  };
  const bg = tones[tone] || tones.error;
  const show = dot || count != null;
  const text = count != null ? count > max ? `${max}+` : count : "";
  const badge = /*#__PURE__*/React.createElement("span", {
    style: {
      position: children ? "absolute" : "static",
      top: children ? -6 : undefined,
      right: children ? -6 : undefined,
      minWidth: dot ? 8 : 18,
      height: dot ? 8 : 18,
      padding: dot ? 0 : "0 5px",
      borderRadius: 999,
      background: bg,
      color: "#fff",
      fontFamily: "var(--font-sans, Inter, sans-serif)",
      fontSize: 11,
      fontWeight: 700,
      lineHeight: "18px",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      boxShadow: children ? "0 0 0 2px var(--neutral-light-solid-00, #fff)" : "none",
      boxSizing: "border-box"
    }
  }, text);
  if (!children) return show ? badge : null;
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      position: "relative",
      display: "inline-flex",
      ...style
    }
  }, rest), children, show && badge);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Badge.jsx", error: String((e && e.message) || e) }); }

// components/feedback/BottomSheet.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Flipkart DLS bottom sheet — slides up from the bottom with a grab handle,
 * optional title, and content. Renders its own dimmed scrim.
 */
function BottomSheet({
  open = true,
  title,
  onClose,
  children,
  showHandle = true,
  style,
  ...rest
}) {
  if (!open) return null;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      zIndex: 40,
      display: "flex",
      alignItems: "flex-end",
      justifyContent: "center",
      fontFamily: "var(--font-sans, Inter, sans-serif)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    onClick: onClose,
    style: {
      position: "absolute",
      inset: 0,
      background: "rgba(0,0,0,.5)"
    }
  }), /*#__PURE__*/React.createElement("div", _extends({
    role: "dialog",
    "aria-modal": "true",
    style: {
      position: "relative",
      width: "100%",
      maxWidth: 480,
      background: "var(--neutral-light-solid-00, #fff)",
      borderTopLeftRadius: "calc(var(--cr8, 16) * 1px)",
      borderTopRightRadius: "calc(var(--cr8, 16) * 1px)",
      boxShadow: "0 -8px 32px rgba(0,0,0,.2)",
      maxHeight: "85%",
      display: "flex",
      flexDirection: "column",
      ...style
    }
  }, rest), showHandle && /*#__PURE__*/React.createElement("div", {
    style: {
      width: 40,
      height: 4,
      borderRadius: 2,
      background: "var(--neutral-light-solid-300, #D6D6D6)",
      margin: "10px auto 4px"
    }
  }), title && /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      padding: "8px 16px 12px",
      boxShadow: "inset 0 -1px 0 var(--neutral-light-solid-200, #E0E0E0)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "calc(var(--font-size-subheading, 17) * 1px)",
      fontWeight: 700,
      color: "var(--text-strong-primary, #333)"
    }
  }, title), /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onClose,
    "aria-label": "close",
    style: {
      appearance: "none",
      border: "none",
      background: "transparent",
      cursor: "pointer",
      color: "var(--text-strong-secondary, #555)",
      fontSize: 22,
      lineHeight: 1
    }
  }, /*#__PURE__*/React.createElement("i", {
    className: "ph ph-x"
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 16,
      overflow: "auto"
    }
  }, children)));
}
Object.assign(__ds_scope, { BottomSheet });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/BottomSheet.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Snackbar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Flipkart DLS snackbar / toast — dark pill at the bottom with message + optional action. */
function Snackbar({
  message,
  action,
  onAction,
  icon,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "status",
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 12,
      background: "var(--neutral-light-solid-900, #333)",
      color: "#fff",
      fontFamily: "var(--font-sans, Inter, sans-serif)",
      fontSize: "calc(var(--font-size-body, 14) * 1px)",
      padding: "12px 16px",
      borderRadius: "calc(var(--cr4, 8) * 1px)",
      boxShadow: "0 8px 24px rgba(0,0,0,.24)",
      maxWidth: 420,
      ...style
    }
  }, rest), icon && /*#__PURE__*/React.createElement("i", {
    className: `ph-fill ${icon}`,
    style: {
      fontSize: 20,
      color: "var(--green-600, #009146)"
    },
    "aria-hidden": "true"
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    }
  }, message), action && /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onAction,
    style: {
      appearance: "none",
      border: "none",
      background: "transparent",
      cursor: "pointer",
      color: "var(--yellow-400, #FFCD03)",
      fontFamily: "inherit",
      fontWeight: 700,
      fontSize: "calc(var(--font-size-body, 14) * 1px)",
      textTransform: "uppercase",
      letterSpacing: ".02em"
    }
  }, action));
}
Object.assign(__ds_scope, { Snackbar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Snackbar.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Tooltip.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Flipkart DLS tooltip — small dark bubble with a pointer arrow. Hover the child to reveal. */
function Tooltip({
  label,
  placement = "top",
  children,
  style,
  ...rest
}) {
  const [open, setOpen] = React.useState(false);
  const pos = {
    top: {
      bottom: "calc(100% + 8px)",
      left: "50%",
      transform: "translateX(-50%)"
    },
    bottom: {
      top: "calc(100% + 8px)",
      left: "50%",
      transform: "translateX(-50%)"
    },
    left: {
      right: "calc(100% + 8px)",
      top: "50%",
      transform: "translateY(-50%)"
    },
    right: {
      left: "calc(100% + 8px)",
      top: "50%",
      transform: "translateY(-50%)"
    }
  };
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      position: "relative",
      display: "inline-flex",
      ...style
    },
    onMouseEnter: () => setOpen(true),
    onMouseLeave: () => setOpen(false)
  }, rest), children, open && /*#__PURE__*/React.createElement("span", {
    role: "tooltip",
    style: {
      position: "absolute",
      zIndex: 20,
      ...pos[placement],
      background: "var(--neutral-light-solid-900, #1F1F1F)",
      color: "#fff",
      fontFamily: "var(--font-sans, Inter, sans-serif)",
      fontSize: "calc(var(--font-size-footnote, 11) * 1px)",
      fontWeight: 500,
      padding: "6px 10px",
      borderRadius: "calc(var(--cr3, 6) * 1px)",
      whiteSpace: "nowrap",
      boxShadow: "0 4px 12px rgba(0,0,0,.2)",
      pointerEvents: "none"
    }
  }, label));
}
Object.assign(__ds_scope, { Tooltip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Tooltip.jsx", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Flipkart DLS checkbox. Square with 4px radius; checked fills brand blue. */
function Checkbox({
  checked,
  defaultChecked,
  disabled = false,
  label,
  onChange,
  id,
  style,
  ...rest
}) {
  const [internal, setInternal] = React.useState(defaultChecked || false);
  const isControlled = checked !== undefined;
  const on = isControlled ? checked : internal;
  const reactId = React.useId();
  const cbId = id || reactId;
  const toggle = e => {
    if (!isControlled) setInternal(e.target.checked);
    onChange && onChange(e);
  };
  return /*#__PURE__*/React.createElement("label", {
    htmlFor: cbId,
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 8,
      cursor: disabled ? "not-allowed" : "pointer",
      fontFamily: "var(--font-sans, Inter, sans-serif)",
      opacity: disabled ? 0.5 : 1,
      ...style
    }
  }, /*#__PURE__*/React.createElement("input", _extends({
    id: cbId,
    type: "checkbox",
    checked: on,
    disabled: disabled,
    onChange: toggle,
    style: {
      position: "absolute",
      opacity: 0,
      width: 0,
      height: 0
    }
  }, rest)), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 20,
      height: 20,
      flexShrink: 0,
      borderRadius: "calc(var(--cr2, 4) * 1px)",
      background: on ? "var(--blue-600, #1162F2)" : "var(--neutral-light-solid-00, #fff)",
      boxShadow: on ? "none" : "inset 0 0 0 2px var(--neutral-light-solid-400, #C0C0C0)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      transition: "background .12s ease, box-shadow .12s ease"
    }
  }, on && /*#__PURE__*/React.createElement("i", {
    className: "ph-bold ph-check",
    style: {
      color: "#fff",
      fontSize: 14
    },
    "aria-hidden": "true"
  })), label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "calc(var(--font-size-body, 14) * 1px)",
      color: "var(--text-strong-primary, #333)"
    }
  }, label));
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/forms/Radio.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Flipkart DLS radio button. Circular; selected shows brand-blue ring + dot. */
function Radio({
  checked,
  defaultChecked,
  disabled = false,
  label,
  name,
  value,
  onChange,
  id,
  style,
  ...rest
}) {
  const [internal, setInternal] = React.useState(defaultChecked || false);
  const isControlled = checked !== undefined;
  const on = isControlled ? checked : internal;
  const reactId = React.useId();
  const rId = id || reactId;
  const handle = e => {
    if (!isControlled) setInternal(true);
    onChange && onChange(e);
  };
  return /*#__PURE__*/React.createElement("label", {
    htmlFor: rId,
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 8,
      cursor: disabled ? "not-allowed" : "pointer",
      fontFamily: "var(--font-sans, Inter, sans-serif)",
      opacity: disabled ? 0.5 : 1,
      ...style
    }
  }, /*#__PURE__*/React.createElement("input", _extends({
    id: rId,
    type: "radio",
    name: name,
    value: value,
    checked: on,
    disabled: disabled,
    onChange: handle,
    style: {
      position: "absolute",
      opacity: 0,
      width: 0,
      height: 0
    }
  }, rest)), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 20,
      height: 20,
      flexShrink: 0,
      borderRadius: "50%",
      background: "var(--neutral-light-solid-00, #fff)",
      boxShadow: on ? "inset 0 0 0 2px var(--blue-600, #1162F2)" : "inset 0 0 0 2px var(--neutral-light-solid-400, #C0C0C0)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      transition: "box-shadow .12s ease"
    }
  }, on && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 10,
      height: 10,
      borderRadius: "50%",
      background: "var(--blue-600, #1162F2)"
    }
  })), label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "calc(var(--font-size-body, 14) * 1px)",
      color: "var(--text-strong-primary, #333)"
    }
  }, label));
}
Object.assign(__ds_scope, { Radio });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Radio.jsx", error: String((e && e.message) || e) }); }

// components/forms/TextField.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Flipkart DLS text field. Outlined or filled, with label, helper/error text,
 * optional prefix/suffix Phosphor icons. Mobile-first sizing.
 */
function TextField({
  label,
  value,
  defaultValue,
  placeholder,
  helperText,
  error,
  variant = "outlined",
  // "outlined" | "filled"
  type = "text",
  prefixIcon,
  suffixIcon,
  disabled = false,
  onChange,
  style,
  ...rest
}) {
  const [focused, setFocused] = React.useState(false);
  const errored = Boolean(error);
  const borderColor = errored ? "var(--red-600, #E3122E)" : focused ? "var(--blue-600, #1162F2)" : "var(--neutral-light-solid-300, #D6D6D6)";
  const wrap = {
    fontFamily: "var(--font-sans, Inter, sans-serif)",
    display: "flex",
    flexDirection: "column",
    gap: 6,
    width: "100%",
    ...style
  };
  const field = {
    display: "flex",
    alignItems: "center",
    gap: 8,
    height: 48,
    padding: "0 14px",
    borderRadius: "calc(var(--cr4, 8) * 1px)",
    background: variant === "filled" ? "var(--neutral-light-solid-50, #F6F6F6)" : "var(--neutral-light-solid-00, #fff)",
    boxShadow: `inset 0 0 0 ${focused || errored ? 2 : 1}px ${borderColor}`,
    transition: "box-shadow .15s ease",
    opacity: disabled ? 0.55 : 1
  };
  const input = {
    flex: 1,
    border: "none",
    outline: "none",
    background: "transparent",
    fontFamily: "inherit",
    fontSize: "calc(var(--font-size-body, 14) * 1px)",
    color: "var(--text-strong-primary, #333)",
    minWidth: 0
  };
  return /*#__PURE__*/React.createElement("label", {
    style: wrap
  }, label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "calc(var(--font-size-subtext, 12) * 1px)",
      fontWeight: 600,
      color: "var(--text-strong-secondary, #555)"
    }
  }, label), /*#__PURE__*/React.createElement("span", {
    style: field
  }, prefixIcon && /*#__PURE__*/React.createElement("i", {
    className: `ph ${prefixIcon}`,
    style: {
      fontSize: 18,
      color: "var(--neutral-light-solid-600, #969595)"
    },
    "aria-hidden": "true"
  }), /*#__PURE__*/React.createElement("input", _extends({
    type: type,
    value: value,
    defaultValue: defaultValue,
    placeholder: placeholder,
    disabled: disabled,
    onChange: onChange,
    style: input,
    onFocus: () => setFocused(true),
    onBlur: () => setFocused(false)
  }, rest)), suffixIcon && /*#__PURE__*/React.createElement("i", {
    className: `ph ${suffixIcon}`,
    style: {
      fontSize: 18,
      color: "var(--neutral-light-solid-600, #969595)"
    },
    "aria-hidden": "true"
  })), (error || helperText) && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "calc(var(--font-size-footnote, 11) * 1px)",
      color: errored ? "var(--red-600, #E3122E)" : "var(--text-strong-tertiary, #707070)"
    }
  }, error || helperText));
}
Object.assign(__ds_scope, { TextField });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/TextField.jsx", error: String((e && e.message) || e) }); }

// components/navigation/BottomNav.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Flipkart DLS mobile bottom navigation bar. Active item turns brand blue. */
function BottomNav({
  items = [],
  value,
  defaultValue,
  onChange,
  style,
  ...rest
}) {
  const [internal, setInternal] = React.useState(defaultValue ?? items[0]?.value);
  const active = value !== undefined ? value : internal;
  const select = v => {
    if (value === undefined) setInternal(v);
    onChange && onChange(v);
  };
  return /*#__PURE__*/React.createElement("nav", _extends({
    style: {
      display: "flex",
      justifyContent: "space-around",
      alignItems: "stretch",
      background: "var(--neutral-light-solid-00, #fff)",
      boxShadow: "inset 0 1px 0 var(--neutral-light-solid-200, #E0E0E0)",
      fontFamily: "var(--font-sans, Inter, sans-serif)",
      padding: "6px 4px 8px",
      ...style
    }
  }, rest), items.map(it => {
    const on = it.value === active;
    return /*#__PURE__*/React.createElement("button", {
      key: it.value,
      onClick: () => select(it.value),
      style: {
        appearance: "none",
        border: "none",
        background: "transparent",
        cursor: "pointer",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        gap: 3,
        flex: 1,
        padding: "2px 0",
        color: on ? "var(--blue-600, #1162F2)" : "var(--text-strong-secondary, #555)"
      }
    }, /*#__PURE__*/React.createElement("i", {
      className: `${on ? "ph-fill" : "ph"} ${it.icon}`,
      style: {
        fontSize: 22
      },
      "aria-hidden": "true"
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: "calc(var(--font-size-fineprint, 10) * 1px)",
        fontWeight: on ? 700 : 500
      }
    }, it.label));
  }));
}
Object.assign(__ds_scope, { BottomNav });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/BottomNav.jsx", error: String((e && e.message) || e) }); }

// components/navigation/SearchBar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Flipkart DLS search bar — the rounded white field with the iconic placeholder. */
function SearchBar({
  placeholder = "Search for Products, Brands and More",
  value,
  onChange,
  onSubmit,
  showCamera = true,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("form", _extends({
    onSubmit: e => {
      e.preventDefault();
      onSubmit && onSubmit(value);
    },
    style: {
      display: "flex",
      alignItems: "center",
      gap: 10,
      width: "100%",
      background: "var(--neutral-light-solid-50, #F0F5FF)",
      borderRadius: "calc(var(--cr3, 6) * 1px)",
      padding: "0 12px",
      height: 40,
      boxSizing: "border-box",
      fontFamily: "var(--font-sans, Inter, sans-serif)",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("i", {
    className: "ph ph-magnifying-glass",
    style: {
      fontSize: 18,
      color: "var(--blue-600, #1162F2)"
    },
    "aria-hidden": "true"
  }), /*#__PURE__*/React.createElement("input", {
    value: value,
    onChange: onChange,
    placeholder: placeholder,
    style: {
      flex: 1,
      border: "none",
      outline: "none",
      background: "transparent",
      minWidth: 0,
      fontFamily: "inherit",
      fontSize: "calc(var(--font-size-body, 14) * 1px)",
      color: "var(--text-strong-primary, #333)"
    }
  }), showCamera && /*#__PURE__*/React.createElement("i", {
    className: "ph ph-camera",
    style: {
      fontSize: 18,
      color: "var(--blue-600, #1162F2)"
    },
    "aria-hidden": "true"
  }));
}
Object.assign(__ds_scope, { SearchBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/SearchBar.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Tabs.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Flipkart DLS tabs — underline style, brand-blue active indicator. */
function Tabs({
  items = [],
  value,
  defaultValue,
  onChange,
  style,
  ...rest
}) {
  const [internal, setInternal] = React.useState(defaultValue ?? items[0]?.value);
  const active = value !== undefined ? value : internal;
  const select = v => {
    if (value === undefined) setInternal(v);
    onChange && onChange(v);
  };
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "tablist",
    style: {
      display: "flex",
      gap: 4,
      fontFamily: "var(--font-sans, Inter, sans-serif)",
      boxShadow: "inset 0 -1px 0 var(--neutral-light-solid-200, #E0E0E0)",
      ...style
    }
  }, rest), items.map(it => {
    const on = it.value === active;
    return /*#__PURE__*/React.createElement("button", {
      key: it.value,
      role: "tab",
      "aria-selected": on,
      onClick: () => select(it.value),
      style: {
        appearance: "none",
        border: "none",
        background: "transparent",
        cursor: "pointer",
        padding: "12px 16px",
        fontFamily: "inherit",
        fontSize: "calc(var(--font-size-body, 14) * 1px)",
        fontWeight: on ? 700 : 500,
        color: on ? "var(--blue-600, #1162F2)" : "var(--text-strong-secondary, #555)",
        boxShadow: on ? "inset 0 -2px 0 var(--blue-600, #1162F2)" : "none",
        display: "inline-flex",
        alignItems: "center",
        gap: 6,
        transition: "color .12s ease"
      }
    }, it.icon && /*#__PURE__*/React.createElement("i", {
      className: `ph ${it.icon}`,
      style: {
        fontSize: 18
      },
      "aria-hidden": "true"
    }), it.label, it.count != null && /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 11,
        fontWeight: 700,
        color: on ? "var(--blue-600,#1162F2)" : "var(--neutral-light-solid-600,#969595)"
      }
    }, "(", it.count, ")"));
  }));
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Tabs.jsx", error: String((e && e.message) || e) }); }

// ui_kits/flipkart-app/data.js
try { (() => {
// Flipkart app UI kit — sample catalogue data.
// Images are represented as a Phosphor icon + tint so the kit needs no external assets.
window.FK_DATA = {
  categories: [{
    label: "Minutes",
    icon: "ph-timer",
    tint: "#FFE9F3",
    fg: "#B0006A"
  }, {
    label: "Mobiles",
    icon: "ph-device-mobile",
    tint: "#EEF7FF",
    fg: "#1162F2"
  }, {
    label: "Fashion",
    icon: "ph-t-shirt",
    tint: "#FFF2E5",
    fg: "#B25600"
  }, {
    label: "Electronics",
    icon: "ph-television-simple",
    tint: "#EAF7F0",
    fg: "#008042"
  }, {
    label: "Home",
    icon: "ph-armchair",
    tint: "#F2EEFF",
    fg: "#6B2BD6"
  }, {
    label: "Beauty",
    icon: "ph-sparkle",
    tint: "#FFEDF0",
    fg: "#C60424"
  }, {
    label: "Grocery",
    icon: "ph-shopping-bag",
    tint: "#EAF7F0",
    fg: "#008042"
  }, {
    label: "Travel",
    icon: "ph-airplane-tilt",
    tint: "#EEF7FF",
    fg: "#1152E0"
  }],
  products: [{
    id: "p1",
    title: "Noise ColorFit Pro 5 Smartwatch · 1.96\" AMOLED",
    brand: "Noise",
    price: 2499,
    mrp: 7999,
    rating: 4.2,
    ratingCount: "18,204",
    assured: true,
    icon: "ph-watch",
    tint: "#EEF7FF",
    fg: "#1162F2"
  }, {
    id: "p2",
    title: "boAt Airdopes 161 Bluetooth TWS Earbuds",
    brand: "boAt",
    price: 1299,
    mrp: 4490,
    rating: 4.1,
    ratingCount: "2.6k",
    assured: true,
    sponsored: true,
    icon: "ph-headphones",
    tint: "#FFF2E5",
    fg: "#B25600"
  }, {
    id: "p3",
    title: "Samsung Galaxy M14 5G (Smoky Teal, 128 GB)",
    brand: "Samsung",
    price: 12490,
    mrp: 16999,
    rating: 4.3,
    ratingCount: "44,981",
    assured: true,
    icon: "ph-device-mobile",
    tint: "#EAF7F0",
    fg: "#008042"
  }, {
    id: "p4",
    title: "AmazonBasics 1.5 Ton 3 Star Inverter AC",
    brand: "Lloyd",
    price: 31990,
    mrp: 58990,
    rating: 4.0,
    ratingCount: "1,204",
    icon: "ph-wind",
    tint: "#F2EEFF",
    fg: "#6B2BD6"
  }, {
    id: "p5",
    title: "Allen Solly Men's Slim Fit Casual Shirt",
    brand: "Allen Solly",
    price: 899,
    mrp: 2199,
    rating: 4.4,
    ratingCount: "9,330",
    icon: "ph-t-shirt",
    tint: "#FFEDF0",
    fg: "#C60424"
  }, {
    id: "p6",
    title: "Prestige Induction Cooktop 1900W",
    brand: "Prestige",
    price: 1799,
    mrp: 3495,
    rating: 4.2,
    ratingCount: "6,712",
    assured: true,
    icon: "ph-cooking-pot",
    tint: "#FFF2E5",
    fg: "#B25600"
  }]
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/flipkart-app/data.js", error: String((e && e.message) || e) }); }

// ui_kits/flipkart-app/screens.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* global React */
const {
  useState
} = React;
const NS = window.FlipkartDesignSystem_4c6aae;
const {
  SearchBar,
  ProductCard,
  Rating,
  Tag,
  PriceBlock,
  Button,
  QuantityStepper,
  BottomNav,
  Divider,
  Tabs,
  Badge,
  Snackbar
} = NS;
const inr = n => "₹" + n.toLocaleString("en-IN");

/* Tinted icon tile standing in for a product/category image. */
function Tile({
  icon,
  tint,
  fg,
  size = "100%",
  radius = 0,
  pad = "24%"
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      width: size,
      height: size,
      background: tint,
      borderRadius: radius,
      display: "flex",
      alignItems: "center",
      justifyContent: "center"
    }
  }, /*#__PURE__*/React.createElement("i", {
    className: `ph-fill ${icon}`,
    style: {
      fontSize: 0,
      color: fg
    }
  }), /*#__PURE__*/React.createElement("i", {
    className: `ph ${icon}`,
    style: {
      fontSize: `min(64px, ${pad === "24%" ? "56px" : "44px"})`,
      color: fg
    }
  }));
}

/* ─────────────── Header (blue bar) ─────────────── */
function AppHeader({
  cartCount,
  onCart
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--blue-600,#1162F2)",
      padding: "10px 12px 12px",
      position: "sticky",
      top: 0,
      zIndex: 5
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12,
      marginBottom: 10
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/brand/flipkart-wordmark.svg",
    alt: "Flipkart",
    style: {
      height: 22,
      filter: "brightness(0) invert(1)"
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }), /*#__PURE__*/React.createElement(Badge, {
    count: cartCount,
    tone: "error"
  }, /*#__PURE__*/React.createElement("i", {
    className: "ph ph-shopping-cart-simple",
    onClick: onCart,
    style: {
      fontSize: 24,
      color: "#fff",
      cursor: "pointer"
    }
  }))), /*#__PURE__*/React.createElement(SearchBar, {
    style: {
      background: "#fff"
    }
  }));
}

/* ─────────────── Home ─────────────── */
function HomeScreen({
  onOpen,
  cartCount,
  onCart
}) {
  const {
    categories,
    products
  } = window.FK_DATA;
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(AppHeader, {
    cartCount: cartCount,
    onCart: onCart
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      background: "#fff",
      padding: "14px 0",
      display: "flex",
      gap: 4,
      overflowX: "auto"
    }
  }, categories.map(c => /*#__PURE__*/React.createElement("div", {
    key: c.label,
    style: {
      flex: "0 0 auto",
      width: 72,
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 52,
      height: 52,
      borderRadius: "50%",
      background: c.tint,
      display: "flex",
      alignItems: "center",
      justifyContent: "center"
    }
  }, /*#__PURE__*/React.createElement("i", {
    className: `ph-fill ${c.icon}`,
    style: {
      fontSize: 26,
      color: c.fg
    }
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 11,
      color: "var(--text-strong-primary,#333)",
      textAlign: "center"
    }
  }, c.label)))), /*#__PURE__*/React.createElement("div", {
    style: {
      margin: "10px 12px",
      borderRadius: 12,
      padding: "18px 20px",
      color: "#fff",
      background: "linear-gradient(120deg,#1162F2,#6B2BD6)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      fontWeight: 700,
      letterSpacing: ".08em",
      opacity: .9
    }
  }, "THE BIG BILLION DAYS"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 24,
      fontWeight: 800,
      lineHeight: 1.1,
      margin: "4px 0 10px"
    }
  }, "Up to 80% off", /*#__PURE__*/React.createElement("br", null), "across categories"), /*#__PURE__*/React.createElement(Button, {
    hierarchy: "primary",
    size: "small"
  }, "Shop now")), /*#__PURE__*/React.createElement(SectionHeader, {
    title: "Deals of the Day",
    sub: "Ends in 06:24:15"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 12,
      overflowX: "auto",
      padding: "0 12px 8px"
    }
  }, products.slice(0, 4).map(p => /*#__PURE__*/React.createElement(ProductCard, _extends({
    key: p.id
  }, p, {
    style: {
      flex: "0 0 auto",
      width: 160
    },
    imageNode: /*#__PURE__*/React.createElement(Tile, {
      icon: p.icon,
      tint: p.tint,
      fg: p.fg
    }),
    onClick: () => onOpen(p.id)
  })))), /*#__PURE__*/React.createElement(SectionHeader, {
    title: "Recommended for you"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: 10,
      padding: "0 12px 16px"
    }
  }, products.map(p => /*#__PURE__*/React.createElement(ProductCard, _extends({
    key: p.id
  }, p, {
    style: {
      width: "100%"
    },
    imageNode: /*#__PURE__*/React.createElement(Tile, {
      icon: p.icon,
      tint: p.tint,
      fg: p.fg
    }),
    onClick: () => onOpen(p.id)
  })))));
}
function SectionHeader({
  title,
  sub
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "baseline",
      justifyContent: "space-between",
      padding: "16px 12px 10px",
      background: "#fff",
      marginTop: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 17,
      fontWeight: 700,
      color: "var(--text-strong-primary,#333)"
    }
  }, title), sub && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      fontWeight: 600,
      color: "var(--red-600,#E3122E)"
    }
  }, sub));
}

/* ─────────────── Product detail ─────────────── */
function ProductScreen({
  id,
  onBack,
  onAdd,
  onCart,
  cartCount
}) {
  const p = window.FK_DATA.products.find(x => x.id === id);
  const [tab, setTab] = useState("highlights");
  return /*#__PURE__*/React.createElement("div", {
    style: {
      paddingBottom: 72
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "sticky",
      top: 0,
      zIndex: 5,
      background: "#fff",
      display: "flex",
      alignItems: "center",
      gap: 14,
      padding: "12px 14px",
      boxShadow: "inset 0 -1px 0 #eee"
    }
  }, /*#__PURE__*/React.createElement("i", {
    className: "ph ph-arrow-left",
    onClick: onBack,
    style: {
      fontSize: 22,
      cursor: "pointer"
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      fontSize: 15,
      fontWeight: 600,
      whiteSpace: "nowrap",
      overflow: "hidden",
      textOverflow: "ellipsis"
    }
  }, p.brand), /*#__PURE__*/React.createElement(Badge, {
    count: cartCount,
    tone: "error"
  }, /*#__PURE__*/React.createElement("i", {
    className: "ph ph-shopping-cart-simple",
    onClick: onCart,
    style: {
      fontSize: 22,
      cursor: "pointer"
    }
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      height: 260,
      background: p.tint,
      display: "flex",
      alignItems: "center",
      justifyContent: "center"
    }
  }, /*#__PURE__*/React.createElement("i", {
    className: `ph ${p.icon}`,
    style: {
      fontSize: 120,
      color: p.fg
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 16,
      background: "#fff",
      display: "flex",
      flexDirection: "column",
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 16,
      color: "var(--text-strong-primary,#333)",
      lineHeight: 1.35
    }
  }, p.title), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 10,
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement(Rating, {
    value: p.rating,
    count: p.ratingCount
  }), p.assured && /*#__PURE__*/React.createElement(Tag, {
    tone: "brand",
    icon: "ph-seal-check"
  }, "Assured")), /*#__PURE__*/React.createElement(PriceBlock, {
    price: p.price,
    mrp: p.mrp,
    size: "large"
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13,
      color: "var(--green-700,#008042)",
      fontWeight: 600
    }
  }, "Free delivery by tomorrow")), /*#__PURE__*/React.createElement("div", {
    style: {
      background: "#fff",
      marginTop: 8
    }
  }, /*#__PURE__*/React.createElement(Tabs, {
    value: tab,
    onChange: setTab,
    style: {
      padding: "0 8px"
    },
    items: [{
      value: "highlights",
      label: "Highlights"
    }, {
      value: "specs",
      label: "Specifications"
    }, {
      value: "reviews",
      label: "Reviews",
      count: p.ratingCount
    }]
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 16,
      fontSize: 14,
      color: "var(--text-strong-secondary,#555)",
      lineHeight: 1.6
    }
  }, tab === "highlights" && /*#__PURE__*/React.createElement("ul", {
    style: {
      margin: 0,
      paddingLeft: 18
    }
  }, /*#__PURE__*/React.createElement("li", null, "1-year warranty"), /*#__PURE__*/React.createElement("li", null, "7-day replacement policy"), /*#__PURE__*/React.createElement("li", null, "Cash on delivery available")), tab === "specs" && /*#__PURE__*/React.createElement("div", null, "In the box: 1 unit, charging cable, user manual. Sold by RetailNet Pvt Ltd."), tab === "reviews" && /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("b", {
    style: {
      color: "#333"
    }
  }, p.rating, " \u2605"), " \xB7 ", p.ratingCount, " ratings. \"Great value for money, works as described.\""))), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      bottom: 0,
      left: 0,
      right: 0,
      display: "flex",
      background: "#fff",
      boxShadow: "0 -2px 8px rgba(0,0,0,.08)"
    }
  }, /*#__PURE__*/React.createElement(Button, {
    hierarchy: "quaternary",
    size: "large",
    icon: "ph-heart",
    style: {
      flex: "0 0 56px",
      borderRadius: 0,
      boxShadow: "none"
    }
  }), /*#__PURE__*/React.createElement(Button, {
    hierarchy: "primary",
    size: "large",
    icon: "ph-shopping-cart-simple",
    style: {
      flex: 1,
      borderRadius: 0
    },
    onClick: () => onAdd(p)
  }, "Add to Cart"), /*#__PURE__*/React.createElement(Button, {
    hierarchy: "secondary",
    size: "large",
    style: {
      flex: 1,
      borderRadius: 0
    }
  }, "Buy Now")));
}

/* ─────────────── Cart ─────────────── */
function CartScreen({
  items,
  onQty,
  onBack,
  onPlace
}) {
  const list = Object.values(items);
  const total = list.reduce((s, it) => s + it.product.price * it.qty, 0);
  const mrpTotal = list.reduce((s, it) => s + (it.product.mrp || it.product.price) * it.qty, 0);
  const saved = mrpTotal - total;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      paddingBottom: 80
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "sticky",
      top: 0,
      zIndex: 5,
      background: "#fff",
      display: "flex",
      alignItems: "center",
      gap: 14,
      padding: "12px 14px",
      boxShadow: "inset 0 -1px 0 #eee"
    }
  }, /*#__PURE__*/React.createElement("i", {
    className: "ph ph-arrow-left",
    onClick: onBack,
    style: {
      fontSize: 22,
      cursor: "pointer"
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 15,
      fontWeight: 700
    }
  }, "My Cart (", list.length, ")")), list.length === 0 && /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 48,
      textAlign: "center",
      color: "#969595"
    }
  }, /*#__PURE__*/React.createElement("i", {
    className: "ph ph-shopping-cart",
    style: {
      fontSize: 48
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 8
    }
  }, "Your cart is empty")), list.map(({
    product: p,
    qty
  }) => /*#__PURE__*/React.createElement("div", {
    key: p.id,
    style: {
      display: "flex",
      gap: 12,
      padding: 14,
      background: "#fff",
      marginBottom: 8
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 72,
      height: 72,
      background: p.tint,
      borderRadius: 8,
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement("i", {
    className: `ph ${p.icon}`,
    style: {
      fontSize: 36,
      color: p.fg
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      display: "flex",
      flexDirection: "column",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: "#333",
      lineHeight: 1.3
    }
  }, p.title), /*#__PURE__*/React.createElement(PriceBlock, {
    price: p.price,
    mrp: p.mrp,
    size: "small"
  }), /*#__PURE__*/React.createElement(QuantityStepper, {
    value: qty,
    size: "small",
    onChange: q => onQty(p.id, q)
  })))), list.length > 0 && /*#__PURE__*/React.createElement("div", {
    style: {
      background: "#fff",
      padding: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      fontWeight: 700,
      marginBottom: 10,
      color: "#333"
    }
  }, "Price Details"), /*#__PURE__*/React.createElement(Row, {
    k: `Price (${list.length} items)`,
    v: inr(mrpTotal)
  }), /*#__PURE__*/React.createElement(Row, {
    k: "Discount",
    v: "− " + inr(saved),
    green: true
  }), /*#__PURE__*/React.createElement(Row, {
    k: "Delivery",
    v: "FREE",
    green: true
  }), /*#__PURE__*/React.createElement(Divider, {
    style: {
      margin: "10px 0"
    }
  }), /*#__PURE__*/React.createElement(Row, {
    k: "Total Amount",
    v: inr(total),
    bold: true
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: "var(--green-700,#008042)",
      fontWeight: 600,
      marginTop: 8
    }
  }, "You save ", inr(saved), " on this order")), list.length > 0 && /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      bottom: 0,
      left: 0,
      right: 0,
      display: "flex",
      alignItems: "center",
      gap: 14,
      background: "#fff",
      padding: "10px 14px",
      boxShadow: "0 -2px 8px rgba(0,0,0,.08)"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 18,
      fontWeight: 700
    }
  }, inr(total))), /*#__PURE__*/React.createElement(Button, {
    hierarchy: "primary",
    size: "large",
    style: {
      flex: 1
    },
    onClick: onPlace
  }, "Place Order")));
}
function Row({
  k,
  v,
  green,
  bold
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      padding: "3px 0",
      fontSize: 14,
      fontWeight: bold ? 700 : 400,
      color: green ? "var(--green-700,#008042)" : "#333"
    }
  }, /*#__PURE__*/React.createElement("span", null, k), /*#__PURE__*/React.createElement("span", null, v));
}
window.FKScreens = {
  HomeScreen,
  ProductScreen,
  CartScreen,
  BottomNav
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/flipkart-app/screens.jsx", error: String((e && e.message) || e) }); }

__ds_ns.PriceBlock = __ds_scope.PriceBlock;

__ds_ns.ProductCard = __ds_scope.ProductCard;

__ds_ns.QuantityStepper = __ds_scope.QuantityStepper;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Divider = __ds_scope.Divider;

__ds_ns.Avatar = __ds_scope.Avatar;

__ds_ns.Chip = __ds_scope.Chip;

__ds_ns.Rating = __ds_scope.Rating;

__ds_ns.Tag = __ds_scope.Tag;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.BottomSheet = __ds_scope.BottomSheet;

__ds_ns.Snackbar = __ds_scope.Snackbar;

__ds_ns.Tooltip = __ds_scope.Tooltip;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.Radio = __ds_scope.Radio;

__ds_ns.TextField = __ds_scope.TextField;

__ds_ns.BottomNav = __ds_scope.BottomNav;

__ds_ns.SearchBar = __ds_scope.SearchBar;

__ds_ns.Tabs = __ds_scope.Tabs;

})();
