# Flipkart Design System

A design system for **Flipkart** — India's largest homegrown e-commerce marketplace — rebuilt from *The Flipkart Design System (Design Tokens 3.0)* Figma file. It covers the visual foundations, token system, reusable UI components, brand assets and a working app UI kit, so design agents can produce on-brand Flipkart interfaces and mocks.

## Product context

Flipkart is a mobile-first shopping super-app. The system spans several **marketplaces / verticals** that share one token foundation but carry their own accent themes:

- **Flipkart** — the core marketplace (brand **blue**).
- **Flipkart Minutes** — quick commerce / 10-minute delivery (**magenta**).
- **Grocery**, **Travel**, **Flipkart Pay** — additional verticals with their own theme modes.
- Sale events (**Big Billion Days**, Sale themes) are first-class theme modes in the token set.

The UI vocabulary is dense, value-led and trust-building: green rating chips, bold discount percentages, struck-through MRPs, "Assured" badges, yellow merchandising CTAs and blue transactional CTAs.

## Sources

- **Figma:** *The Flipkart Design System (Design Tokens 3.0)* — attached as a mounted file. 1,567 component sets + 1,084 standalone symbols, 1,934 Figma Variables across 9 collections, ~98-glyph Phosphor-based icon set. (No public URL was provided; recorded here in case you have access.)
- Tokens, component specs and brand context were extracted directly from that file — not from public Flipkart references.

---

## Content fundamentals

How Flipkart writes:

- **Voice:** plain, direct, value-forward. Leads with the deal — *"Up to 80% off"*, *"₹2,499  ₹7,999  68% off"*, *"Free delivery by tomorrow"*.
- **Person:** addresses the shopper as **you** ("Recommended for you", "My Cart", "You save ₹5,500 on this order"). First person only for the user's own objects ("My Cart", "My Orders").
- **Case:** Sentence case for body and section titles ("Deals of the Day", "Price Details"). UPPERCASE reserved for tiny emphasis labels and snackbar actions ("ADD", "UNDO"). Button labels are Title Case ("Add to Cart", "Buy Now", "Place Order").
- **Numbers & currency:** Indian formatting — ₹ symbol, lakh/comma grouping ("₹12,490", "44,981 ratings", "2.6k"). Discounts always as "NN% off" in green; savings called out explicitly.
- **Tone:** urgency without hype — countdowns ("Ends in 06:24:15"), stock nudges ("Few left!"), trust markers ("Assured", "7-day replacement"). No exclamation overload.
- **Emoji:** not used in product UI. Iconography carries visual meaning instead.
- **Microcopy vibe:** helpful and reassuring at decision points (delivery, returns, payment), terse everywhere else.

---

## Visual foundations

- **Colour:** Brand **blue** `--blue-600 #1162F2` (primary actions, links, headers) and brand **yellow** `--yellow-300/400` (the primary "Add to Cart" CTA, rendered as a left-to-right gradient). **Green** `--green-700 #008042` owns ratings, savings and success. **Red** `--red-600` for errors, wishlist and urgency. Neutrals run a true-grey ramp; primary text is `#333` (`--text-strong-primary`), secondary uses transparent-black tints. Marketplace verticals swap in magenta / violet / teal / pink theme palettes.
- **Type:** **Inter** across all UI (Mukta / Noto Sans families for Indic scripts via Language theme modes). Seven-step scale — title 30, heading 22, subheading 17, body 14, subtext 12, footnote 11, fineprint 10 (px on mobile; scales up on tablet/desktop modes). Weights 400/500/600/700/800. Tight negative letter-spacing on large headings.
- **Spacing:** 2px base step — S0–S13 = 0·2·4·6·8·12·16·20·24·32·40·48·56·64. Mobile layouts are tight (12–16px gutters).
- **Corner radius:** scale cr0–cr12 (0·2·4·6·8·12·16·20·24·28·32). Buttons 12 (large) / 8 (medium·small); cards 8; chips 8; rating chips 4; bottom sheets 16. A **Curv ↔ Sharp** theme mode flattens all radii to 0.
- **Backgrounds:** flat. App page background is a light grey (`#f1f3f6`), content sits on white cards. The blue header bar and sale banners are the main colour fields; sale banners use blue→violet gradients. No textures, no full-bleed photography in chrome — imagery lives inside product tiles.
- **Cards:** white, 8px radius, a **hairline** `0 0 0 1px rgba(0,0,0,.04)` plus a soft `0 1px 3px rgba(0,0,0,.08)` lift. Not heavily rounded, no coloured left-border accents.
- **Elevation:** light and tight — hairline (card border), raised (product card), overlay (dropdown), modal (bottom sheet / toast `0 8px 24px`). Avoid large diffuse glows.
- **Borders:** 1–1.2px neutral (`--neutral-light-solid-300 #D6D6D6`) for inputs/chips; inset box-shadow used as border so it never shifts layout. Focus = 2px brand-blue inset.
- **Motion:** subtle and quick. 120–150ms ease for colour/shadow; press feedback is a `scale(0.98)` + slight brightness drop. Bottom sheets / toasts rise ~200ms. No bounce, no decorative looping animation.
- **Hover / press:** hover darkens fills (`brightness(.94)`) or adds a `rgba(0,0,0,.12)` overlay on chips; press deepens to `.24` / scales down. Selected chips fill blue (single-select) or grey (multi-select).
- **Transparency / blur:** minimal. Opacity tints used for scrims (bottom-sheet backdrop `rgba(0,0,0,.5)`) and overlay states; no glassmorphism.
- **Imagery vibe:** product photography on white, centred, generous padding — clean catalogue look, neutral/bright, no heavy grain or duotone.

---

## Iconography

- **System:** **Phosphor Icons** — the file's icon set (Airplane, Arrow*, Archive, …, with Weight = regular / bold / fill) is Phosphor. Because the file's vectors don't decode cleanly and Phosphor is the genuine open-source source set, this DS loads Phosphor from CDN at full fidelity rather than shipping extracted SVGs.
  - Load: `<link rel="stylesheet" href="https://unpkg.com/@phosphor-icons/web@2.1.1/src/regular/style.css">` (also `/bold/` and `/fill/`).
  - Use: `<i class="ph ph-shopping-cart-simple"></i>`, `ph-bold ph-check`, `ph-fill ph-star`. Components accept a Phosphor class string via their `icon` prop.
  - Weights map to states: regular for rest, **fill** for selected/active (e.g. bottom-nav active, wishlisted heart, rating star), bold for emphasis inside buttons.
- **Emoji:** never used as UI icons.
- **Logos:** `assets/brand/` holds **recreated** SVGs of the Flipkart app icon and the "Flipkart · Explore Plus" wordmark (the originals are vector-composited in Figma and weren't cleanly extractable). **Replace these with official brand files for production.** A `cover-hero.png` from the Figma cover is also included.

---

## Index / manifest

**Root**
- `styles.css` — global entry point (import this one file). `@import`s fonts + tokens + type helpers.
- `tokens/` — `fig-tokens.css` (1,934 Figma Variables incl. all theme modes), `fonts.css` (Inter + Indic families), `typography.css` (`.fk-*` type-scale classes).
- `readme.md` — this guide. `SKILL.md` — Agent-Skills entry point.

**Components** (`window.FlipkartDesignSystem_4c6aae`)
- `components/core/` — **Button** (primary/secondary/tertiary/quaternary × 3 sizes), **Divider**
- `components/forms/` — **TextField**, **Checkbox**, **Radio**
- `components/data-display/` — **Rating** (green chip), **Chip**, **Tag**, **Avatar**
- `components/feedback/` — **Badge**, **Snackbar**, **Tooltip**, **BottomSheet**
- `components/navigation/` — **Tabs**, **BottomNav**, **SearchBar**
- `components/commerce/` — **ProductCard**, **PriceBlock**, **QuantityStepper**

**Guidelines** (`guidelines/`) — foundation specimen cards (Colors, Type, Spacing, Brand) shown in the Design System tab.

**UI kits** (`ui_kits/`)
- `flipkart-app/` — interactive mobile app prototype (home → product → cart).

**Assets** (`assets/brand/`) — logos + cover image.

## Caveats
- Brand **logos are recreations** — swap in official assets.
- **Icons are Phosphor via CDN** (the file's true icon set); no offline icon binaries are bundled.
- Token string font-weight names ("Bold", "Semi Bold", …) are weight aliases, not font files — they resolve through the Inter fallback stack.
